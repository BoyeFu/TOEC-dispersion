%%
clear
%Two group of data
%All the unit of the stiffness is GPa, and the unit of pressure is 
%%
I = sqrt(-1);
Kf =2.25;%bulk modulus of water
yita = 1e-03;%viscosity
a=1;%the radius of the crack
%Quartz
KdQ = 37;%Bulk modulus
mudQ = 44;%Shear modulus
eQ = 0.01;%Crack density
asp = 0.01;
phic = 4/3.*pi.*asp.*eQ;
KdrQ = 26;%The bulk modulus of dry rock
mudrQ = 31;%The shear modulus of dry rock
kappa = 1e-15;%Permeability
phi = 0.1;%Porosity
arf =(KdQ-KdrQ)./KdQ;
%MQ1 = ((arf-phi)./KdQ+phi./Kf).^(-1);
MQ1 = KdQ/((1-KdrQ/KdQ)-phi*(1-KdQ/Kf));
%MQ = ((-KdrQ.*Kf+KdQ.*(Kf-Kf.*phi+KdQ.*phi))./(Kf.*KdQ.^2)).^(-1);
%MQ = Kf.*KdQ.^2./(-KdrQ.*Kf.*KdQ.*(Kf-phi.*Kf+KdQ.*phi)); 
MQ = ((arf-phi)./KdQ+phi./Kf).^(-1);
C1 = KdrQ+4/3.*mudrQ+arf.^2.*MQ1;
EXP = (-15:0.05:-5);
OMI = 10.^(EXP);
gQ = mudrQ./(KdrQ+4/3.*mudrQ);
CdrQ = KdrQ+4./3.*mudrQ;
KQBH = KdrQ+arf.^2.^MQ1;
CQBH = KQBH+4./3.*mudrQ;
CQ = KdQ+4./3.*mudQ;
k2 = sqrt((sqrt(-1).*OMI.*yita.*CQBH./kappa./MQ./CdrQ));
k2a = real((k2.*a));
HHB = CQBH.*ones(1,121);
rhoQ = 2.65/1000000;
rhof = 1.09/1000000;
rhoR = (1-phi).*rhoQ+phi.*rhof;
RAD001 = [0 pi/4 pi/2];
RAD010 = [0 pi/4 pi/2];
RAD020 = [0 pi/4 pi/2];
RAD050 = [0 pi/4 pi/2];
RAD100 = [0 pi/4 pi/2];
%%
%Autocorrelation length = 1 um
STCRACK001 = [0.00194654	0.002524904	0.0097129	0.023632348	0.039384788	0.061323593	0.085052097	0.1107779];
STPRE001 = [0	0.298864741	0.640456532	1.619032668	3.826361745	6.568469671	9.666908213	13.93762938];
C22001 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK001+4.*mudQ.*eQ./STCRACK001);
CC22001 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK001))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK001);
ZCRACK001 = eQ./STCRACK001; 
C44001 = mudQ./(1+mudQ.*ZCRACK001);%The shear modulus
deltaN001 = CdrQ.*ZCRACK001./(1+CdrQ.*ZCRACK001);
ZCRACK001S = ZCRACK001./(1+Kf.*deltaN001./(CQ.*phic.*(1-deltaN001)).*(1-Kf./KdQ).^(-1));
C11001H = (4.*mudrQ.*(1+mudrQ.*ZCRACK001S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK001S))./(3+3.*KQBH.*ZCRACK001S+4.*mudrQ.*ZCRACK001S);
%C11001H = CQBH.*ones(1,8);
C1100101 = (4.*mudrQ.*(1+mudrQ.*ZCRACK001)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK001))./(3+3.*KdrQ.*ZCRACK001+4.*mudrQ.*ZCRACK001);
C22001H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK001S+4.*mudrQ.*ZCRACK001S);
%C22001H = CQBH.*ones(1,8);
C2200101 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK001+4.*mudrQ.*ZCRACK001);
C12001H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK001S+4.*mudrQ.*ZCRACK001S);
%C12001H = (CQBH-2.*mudrQ).*ones(1,8);
C1200101 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK001+4.*mudrQ.*ZCRACK001);
C66001H = mudrQ./(1+mudrQ.*ZCRACK001);
KX001 = KdrQ.*(3+4.*mudrQ.*ZCRACK001)./(3+3.*KdrQ.*ZCRACK001+4.*mudrQ.*ZCRACK001);
MX001 = ((1-KX001./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1001 = 1-KX001./KdQ-(2.*mudrQ.*ZCRACK001)./(3+4.*mudrQ.*ZCRACK001).*KX001./KdQ;
a2001 = 1-KX001./KdQ+(6.*mudrQ.*ZCRACK001)./(3+4.*mudrQ.*ZCRACK001).*KX001./KdQ;
%C110010 = C1100101+a1001.^2.*MX001;
%C110010 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK001) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK001) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK001)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK001) + Kf .*(3 .*KdQ.^2.* ZCRACK001 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK001) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK001))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK001 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK001) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK001 + 3.* KdQ.* (-1 + phi).* ZCRACK001));
C110010 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK001)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK001 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK001) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK001 + 3.* KdQ.* (-1 + phi).* ZCRACK001))));
C220010 = C2200101+a2001.^2.*MX001;
C120010 = C1200101+a1001.*a2001.*MX001;
C660010 = mudrQ./(1+mudrQ.*ZCRACK001);
%%
MPX00102H = ((C11001H-C66001H).*sin(RAD001(2)).^2-(C22001H-C66001H).*cos(RAD001(2)).^2).^2+(C12001H+C66001H).^2.*sin(2.*RAD001(2));
MPX001020 = ((C110010-C660010).*sin(RAD001(2)).^2-(C220010-C660010).*cos(RAD001(2)).^2).^2+(C120010+C660010).^2.*sin(2.*RAD001(2));
C45001H = (C11001H.*sin(RAD001(2)).^2+C22001H.*cos(RAD001(2)).^2+C66001H+sqrt(MPX00102H));
C450010 = (C110010.*sin(RAD001(2)).^2+C220010.*cos(RAD001(2)).^2+C660010+sqrt(MPX001020));
C45001SH = (C11001H.*sin(RAD001(2)).^2+C22001H.*cos(RAD001(2)).^2+C66001H-sqrt(MPX00102H));
C45001S0 = (C110010.*sin(RAD001(2)).^2+C220010.*cos(RAD001(2)).^2+C660010-sqrt(MPX001020));
%%
G001 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T001 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita001L = (C22001H(1)-C220010(1)).^3./(2.*C22001H(1).*C220010(1).^2.*T001.*G001.^2);
tao001L = ((C22001H(1)-C220010(1))./C220010(1)./G001).^2;
fw001L = (1-cita001L+cita001L.*sqrt(1-sqrt(-1).*OMI.*tao001L./cita001L.^2));
%%
%C11
%CCZ11001L = 1./C11001H(1).*(1+((C11001H(1)-C110010(1))./C110010(1))./fw001L);
CCC11001L = C11001H(1)./(1+((C11001H(1)-C110010(1))./C110010(1))./fw001L);
Q1C11001L = abs(imag(CCC11001L)./real(CCC11001L));
%%
%C22
%CCZ22001L = 1./C22001H(1).*(1+((C22001H(1)-C220010(1))./C220010(1))./fw001L);
CCC22001L = C22001H(1)./(1+((C22001H(1)-C220010(1))./C220010(1))./fw001L);
Q1C22001L = abs(imag(CCC22001L)./real(CCC22001L));
%%
%C12
%CCZ12001L = 1./C12001H(1).*(1+((C12001H(1)-C120010(1))./C120010(1))./fw001L);
CCC12001L = C12001H(1)./(1+((C12001H(1)-C120010(1))./C120010(1))./fw001L);
Q1C12001L = abs(imag(CCC12001L)./real(CCC12001L));
%%
%C66
%CCZ66001L = 1./C66001H(1).*(1+((C66001H(1)-C660010(1))./C660010(1))./fw001L);
CCC66001L = C66001H(1)./(1+((C66001H(1)-C660010(1))./C660010(1))./fw001L);
Q1C66001L = abs(imag(CCC66001L)./real(CCC66001L));
%%
%C45
CCC45001L = C45001H(1)./(1+((C45001H(1)-C450010(1))./C450010(1))./fw001L);
Q1C45001L = abs(imag(CCC45001L)./real(CCC45001L));
%%
%C45S
CCC45001SL = C45001SH(1)./(1+((C45001SH(1)-C45001S0(1))./C45001S0(1))./fw001L);
Q1C45001SL = abs(imag(CCC45001SL)./real(CCC45001SL));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX00101L = ((CCC11001L-CCC66001L).*sin(RAD001(1)).^2-(CCC22001L-CCC66001L).*cos(RAD001(1)).^2).^2+(CCC12001L+CCC66001L).^2.*sin(2.*RAD001(1));
MPX00102L = ((CCC11001L-CCC66001L).*sin(RAD001(2)).^2-(CCC22001L-CCC66001L).*cos(RAD001(2)).^2).^2+(CCC12001L+CCC66001L).^2.*sin(2.*RAD001(2));
MPX00103L = ((CCC11001L-CCC66001L).*sin(RAD001(3)).^2-(CCC22001L-CCC66001L).*cos(RAD001(3)).^2).^2+(CCC12001L+CCC66001L).^2.*sin(2.*RAD001(3));

%P-wave velocity
VpX00101L = (CCC11001L.*sin(RAD001(1)).^2+CCC22001L.*cos(RAD001(1)).^2+CCC66001L+sqrt(MPX00101L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX00102L = (CCC11001L.*sin(RAD001(2)).^2+CCC22001L.*cos(RAD001(2)).^2+CCC66001L+sqrt(MPX00102L)).^(1/2).*(2.*rhoR).^(-1/2);
VpX00102L = sqrt(CCC45001L./2./rhoR);
VpX00103L = (CCC11001L.*sin(RAD001(3)).^2+CCC22001L.*cos(RAD001(3)).^2+CCC66001L+sqrt(MPX00103L)).^(1/2).*(2.*rhoR).^(-1/2);
Vp00101L = real(1./VpX00101L).^(-1);
Qp00101L = abs(imag(VpX00101L.^2)./real(VpX00101L.^2));
Vp00102L = real(1./VpX00102L).^(-1);
Qp00102L = abs(imag(VpX00102L.^2)./real(VpX00102L.^2));
Vp00103L = real(1./VpX00103L).^(-1);
Qp00103L = abs(imag(VpX00103L.^2)./real(VpX00103L.^2));
%%
%Anisotropy
epxl001L = (VpX00103L.^2-VpX00101L.^2)./(2.*VpX00101L.^2);
deltaV001L = 4.*(VpX00102L./VpX00101L-1)-(VpX00103L./VpX00101L-1);
%S-wave velocity
VsX00101L = (CCC11001L.*sin(RAD001(1)).^2+CCC22001L.*cos(RAD001(1)).^2+CCC66001L-sqrt(MPX00101L)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX00102L = (CCC11001L.*sin(RAD001(2)).^2+CCC22001L.*cos(RAD001(2)).^2+CCC66001L-sqrt(MPX00102L)).^(1/2).*(2.*rhoR).^(-1/2);
VsX00102L = sqrt(CCC45001SL./2./rhoR);
VsX00103L = (CCC11001L.*sin(RAD001(3)).^2+CCC22001L.*cos(RAD001(3)).^2+CCC66001L-sqrt(MPX00103L)).^(1/2).*(2.*rhoR).^(-1/2);
Vs00101L = real(1./VsX00101L).^(-1);
Qs00101L = abs(imag(VsX00101L.^2)./real(VsX00101L.^2));
Vs00102L = real(1./VsX00102L).^(-1);
Qs00102L = abs(imag(VsX00102L.^2)./real(VsX00102L.^2));
Vs00103L = real(1./VsX00103L).^(-1);
Qs00103L = abs(imag(VsX00103L.^2)./real(VsX00103L.^2));
%%
%Medial Pressure
cita001M = (C22001H(4)-C220010(4)).^3./(2.*C22001H(4).*C220010(4).^2.*T001.*G001.^2);
tao001M = ((C22001H(4)-C220010(4))./C220010(4)./G001).^2;
%%
fw001M = (1-cita001M+cita001M.*sqrt(1-sqrt(-1).*OMI.*tao001M./cita001M.^2));
%C11
CCZ11001M = 1./C11001H(4).*(1+((C11001H(4)-C110010(4))./C110010(4))./fw001M);
CCC11001M = 1./CCZ11001M;
Q1C11001M = abs(imag(CCC11001M)./real(CCC11001M));
%%
%C22
CCZ22001M = 1./C22001H(4).*(1+((C22001H(4)-C220010(4))./C220010(4))./fw001M);
CCC22001M = 1./CCZ22001M;
Q1C22001M = abs(imag(CCC22001M)./real(CCC22001M));
%%
%C12
CCZ12001M = 1./C12001H(4).*(1+((C12001H(4)-C120010(4))./C120010(4))./fw001M);
CCC12001M = 1./CCZ12001M;
Q1C12001M = abs(imag(CCC12001M)./real(CCC12001M));
%%
%C66
CCZ66001M = 1./C66001H(4).*(1+((C66001H(4)-C660010(4))./C660010(4))./fw001M);
CCC66001M = 1./CCZ66001M;
Q1C66001M = abs(imag(CCC66001M)./real(CCC66001M));
%%
%C45
CCC45001M = C45001H(4)./(1+((C45001H(4)-C450010(4))./C450010(4))./fw001M);
Q1C45001M = abs(imag(CCC45001M)./real(CCC45001M));
%%
%C45S
CCC45001SM = C45001SH(4)./(1+((C45001SH(4)-C45001S0(4))./C45001S0(4))./fw001M);
Q1C45001SM = abs(imag(CCC45001SM)./real(CCC45001SM));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX00101M = ((CCC11001M-CCC66001M).*sin(RAD001(1)).^2-(CCC22001M-CCC66001M).*cos(RAD001(1)).^2).^2+(CCC12001M+CCC66001M).^2.*sin(2.*RAD001(1));
MPX00102M = ((CCC11001M-CCC66001M).*sin(RAD001(2)).^2-(CCC22001M-CCC66001M).*cos(RAD001(2)).^2).^2+(CCC12001M+CCC66001M).^2.*sin(2.*RAD001(2));
MPX00103M = ((CCC11001M-CCC66001M).*sin(RAD001(3)).^2-(CCC22001M-CCC66001M).*cos(RAD001(3)).^2).^2+(CCC12001M+CCC66001M).^2.*sin(2.*RAD001(3));
%P-wave velocity
VpX00101M = (CCC11001M.*sin(RAD001(1)).^2+CCC22001M.*cos(RAD001(1)).^2+CCC66001M+sqrt(MPX00101M)).^(1/2).*(2.*rhoR).^(-1/2);
%VpX00102M = (CCC11001M.*sin(RAD001(2)).^2+CCC22001M.*cos(RAD001(2)).^2+CCC66001M+sqrt(MPX00102M)).^(1/2).*(2.*rhoR).^(-1/2);
VpX00102M = sqrt(CCC45001M./2./rhoR);
VpX00103M = (CCC11001M.*sin(RAD001(3)).^2+CCC22001M.*cos(RAD001(3)).^2+CCC66001M+sqrt(MPX00103M)).^(1/2).*(2.*rhoR).^(-1/2);
Vp00101M = real(1./VpX00101M).^(-1);
Qp00101M = abs(imag(VpX00101M.^2)./real(VpX00101M.^2));
Vp00102M = real(1./VpX00102M).^(-1);
Qp00102M = abs(imag(VpX00102M.^2)./real(VpX00102M.^2));
Vp00103M = real(1./VpX00103M).^(-1);
Qp00103M = abs(imag(VpX00103M.^2)./real(VpX00103M.^2));
%%
%Anisotropy
epxl001M = (Vp00103M.^2-Vp00101M.^2)./(2.*Vp00101M.^2);
deltaV001M = 4.*(Vp00102M./Vp00101M-1)-(Vp00103M./Vp00101M-1);
%S-wave velocity
VsX00101M = (CCC11001M.*sin(RAD001(1)).^2+CCC22001M.*cos(RAD001(1)).^2+CCC66001M-sqrt(MPX00101M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX00102M = (CCC11001M.*sin(RAD001(2)).^2+CCC22001M.*cos(RAD001(2)).^2+CCC66001M-sqrt(MPX00102M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX00102M = sqrt(CCC45001SM./2./rhoR);
VsX00103M = (CCC11001M.*sin(RAD001(3)).^2+CCC22001M.*cos(RAD001(3)).^2+CCC66001M-sqrt(MPX00103M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs00101M = real(1./VsX00101M).^(-1);
Qs00101M = abs(imag(VsX00101M.^2)./real(VsX00101M.^2));
Vs00102M = real(1./VsX00102M).^(-1);
Qs00102M = abs(imag(VsX00102M.^2)./real(VsX00102M.^2));
Vs00103M = real(1./VsX00103M).^(-1);
Qs00103M = abs(imag(VsX00103M.^2)./real(VsX00103M.^2));
%%
%High Pressure
cita001H = (C22001H(8)-C220010(8)).^3./(2.*C22001H(8).*C220010(8).^2.*T001.*G001.^2);
tao001H = ((C22001H(8)-C220010(8))./C220010(8)./G001).^2;
%%
fw001H = (1-cita001H+cita001H.*sqrt(1-sqrt(-1).*OMI.*tao001H./cita001H.^2));
%C11
CCZ11001H = 1./C11001H(8).*(1+((C11001H(8)-C110010(8))./C110010(8))./fw001H);
CCC11001H = 1./CCZ11001H;
Q1C11001H = abs(imag(CCC11001H)./real(CCC11001H));
%%
%C22
CCZ22001H = 1./C22001H(8).*(1+((C22001H(8)-C220010(8))./C220010(8))./fw001H);
CCC22001H = 1./CCZ22001H;
Q1C22001H = abs(imag(CCC22001H)./real(CCC22001H));
%%
%C12
CCZ12001H = 1./C12001H(8).*(1+((C12001H(8)-C120010(8))./C120010(8))./fw001H);
CCC12001H = 1./CCZ12001H;
Q1C12001H = abs(imag(CCC12001H)./real(CCC12001H));
%%
%C66
CCZ66001H = 1./C66001H(8).*(1+((C66001H(8)-C660010(8))./C660010(8))./fw001H);
CCC66001H = 1./CCZ66001H;
Q1C66001H = abs(imag(CCC66001H)./real(CCC66001H));
%%
%C45
CCC45001H = C45001H(8)./(1+((C45001H(8)-C450010(8))./C450010(8))./fw001H);
Q1C45001H = abs(imag(CCC45001H)./real(CCC45001H));
%%
%C45S
CCC45001SH = C45001SH(8)./(1+((C45001SH(8)-C45001S0(8))./C45001S0(8))./fw001H);
Q1C45001SH = abs(imag(CCC45001SH)./real(CCC45001SH));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX00101H = ((CCC11001H-CCC66001H).*sin(RAD001(1)).^2-(CCC22001H-CCC66001H).*cos(RAD001(1)).^2).^2+(CCC12001H+CCC66001H).^2.*sin(2.*RAD001(1));
MPX00102H = ((CCC11001H-CCC66001H).*sin(RAD001(2)).^2-(CCC22001H-CCC66001H).*cos(RAD001(2)).^2).^2+(CCC12001H+CCC66001H).^2.*sin(2.*RAD001(2));
MPX00103H = ((CCC11001H-CCC66001H).*sin(RAD001(3)).^2-(CCC22001H-CCC66001H).*cos(RAD001(3)).^2).^2+(CCC12001H+CCC66001H).^2.*sin(2.*RAD001(3));
%P-wave velocity
VpX00101H = (CCC11001H.*sin(RAD001(1)).^2+CCC22001H.*cos(RAD001(1)).^2+CCC66001H+sqrt(MPX00101H)).^(1/2).*(2.*rhoR).^(-1/2);
%VpX00102H = (CCC11001H.*sin(RAD001(2)).^2+CCC22001H.*cos(RAD001(2)).^2+CCC66001H+sqrt(MPX00102H)).^(1/2).*(2.*rhoR).^(-1/2);
VpX00102H = sqrt(CCC45001H./2./rhoR);
VpX00103H = (CCC11001H.*sin(RAD001(3)).^2+CCC22001H.*cos(RAD001(3)).^2+CCC66001H+sqrt(MPX00103H)).^(1/2).*(2.*rhoR).^(-1/2);
Vp00101H = real(1./VpX00101H).^(-1);
Qp00101H = abs(imag(VpX00101H.^2)./real(VpX00101H.^2));
Vp00102H = real(1./VpX00102H).^(-1);
Qp00102H = abs(imag(VpX00102H.^2)./real(VpX00102H.^2));
Vp00103H = real(1./VpX00103H).^(-1);
Qp00103H = abs(imag(VpX00103H.^2)./real(VpX00103H.^2));
%%
%Anisotropy
epxl001H = (Vp00103H.^2-Vp00101H.^2)./(2.*Vp00101H.^2);
deltaV001H = 4.*(Vp00102H./Vp00101H-1)-(Vp00103H./Vp00101H-1);
%S-wave velocity
VsX00101H = (CCC11001H.*sin(RAD001(1)).^2+CCC22001H.*cos(RAD001(1)).^2+CCC66001M-sqrt(MPX00101M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX00102H = (CCC11001H.*sin(RAD001(2)).^2+CCC22001H.*cos(RAD001(2)).^2+CCC66001M-sqrt(MPX00102M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX00102H = sqrt(CCC45001SM./2./rhoR);
VsX00103H = (CCC11001H.*sin(RAD001(3)).^2+CCC22001H.*cos(RAD001(3)).^2+CCC66001M-sqrt(MPX00103M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs00101H = real(1./VsX00101H).^(-1);
Qs00101H = abs(imag(VsX00101H.^2)./real(VsX00101H.^2));
Vs00102H = real(1./VsX00102H).^(-1);
Qs00102H = abs(imag(VsX00102H.^2)./real(VsX00102H.^2));
Vs00103H = real(1./VsX00103H).^(-1);
Qs00103H = abs(imag(VsX00103H.^2)./real(VsX00103H.^2));
%%
%Autocorrelation length = 1um
ZCRACK001C = eQ./STCRACK001; 
deltaN001C = CdrQ.*ZCRACK001C./(1+CdrQ.*ZCRACK001C);
ZCRACK001SC = ZCRACK001C./(1+Kf.*deltaN001C./(CQ.*phic.*(1-deltaN001C)).*(1-Kf./KdQ).^(-1));
C22001HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK001SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK001SC));
C00101C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK001C))./3./(4.*pi+9.*KdrQ.*ZCRACK001C);
KX001C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK001C);
MX001C = KdQ./((1-KX001C./KdQ)-phi.*(1-KdQ./Kf));
a1001C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK001C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK001C));
C0010C = C00101C+a1001C.^2.*MX001C;
G001C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
T001C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
cita001CL = (C22001HC(1)-C0010C(1)).^3./(2.*C22001HC(1).*C0010C(1).^2.*T001C.*G001C.^2);
tao001CL = ((C22001HC(1)-C0010C(1))./C0010C(1)./G001C).^2;
CCZ001CL = 1./C22001HC(1).*(1+((C22001HC(1)-C0010C(1))./C0010C(1))./(1-cita001CL+cita001CL.*sqrt(1-sqrt(-1).*OMI.*tao001CL./cita001CL.^2)));
CCC001CL = 1./CCZ001CL;
Q1C001CL = abs(imag(CCC001CL)./real(CCC001CL));
%
cita001CM = (C22001HC(4)-C0010C(4)).^3./(2.*C22001HC(4).*C0010C(4).^2.*T001C.*G001C.^2);
tao001CM = ((C22001HC(4)-C0010C(4))./C0010C(4)./G001C).^2;
CCZ001CM = 1./C22001HC(4).*(1+((C22001HC(4)-C0010C(4))./C0010C(4))./(1-cita001CM+cita001CM.*sqrt(1-sqrt(-1).*OMI.*tao001CM./cita001CM.^2)));
CCC001CM = 1./CCZ001CM;
Q1C001CM = abs(imag(CCC001CM)./real(CCC001CM));
%
cita001CH = (C22001HC(8)-C0010C(8)).^3./(2.*C22001HC(8).*C0010C(8).^2.*T001C.*G001C.^2);
tao001CH = ((C22001HC(8)-C0010C(8))./C0010C(8)./G001C).^2;
CCZ001CH = 1./C22001HC(8).*(1+((C22001HC(8)-C0010C(8))./C0010C(8))./(1-cita001CH+cita001CH.*sqrt(1-sqrt(-1).*OMI.*tao001CH./cita001CH.^2)));
CCC001CH = 1./CCZ001CH;
Q1C001CH = abs(imag(CCC001CH)./real(CCC001CH));
%%
%Autocorrelation length = 10 um
STCRACK010 = [0.006649454	0.024009535	0.048241941	0.080398298	0.100339718	0.119570148	0.13183099	0.144246096];
STPRE010 = [0	0.41320598	1.582759274	3.935769798	6.929583433	10.6573809	13.61830548	16.86163904];
C22010 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK010+4.*mudQ.*eQ./STCRACK010);
CC22010 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK010))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK010);
ZCRACK010 = eQ./STCRACK010; 
C44010 = mudQ./(1+mudQ.*ZCRACK010);
deltaN010 = CdrQ.*ZCRACK010./(1+CdrQ.*ZCRACK010);
ZCRACK010S = ZCRACK010./(1+Kf.*deltaN010./(CQ.*phic.*(1-deltaN010)).*(1-Kf./KdQ).^(-1));
C11010H = (4.*mudrQ.*(1+mudrQ.*ZCRACK010S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK010S))./(3+3.*KQBH.*ZCRACK010S+4.*mudrQ.*ZCRACK010S);
C1101001 = (4.*mudrQ.*(1+mudrQ.*ZCRACK010)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK010))./(3+3.*KdrQ.*ZCRACK010+4.*mudrQ.*ZCRACK010);
C22010H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK010S+4.*mudrQ.*ZCRACK010S);
C2201001 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK010+4.*mudrQ.*ZCRACK010);
C12010H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK010S+4.*mudrQ.*ZCRACK010S);
C1201001 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK010+4.*mudrQ.*ZCRACK010);
C66010H = mudrQ./(1+mudrQ.*ZCRACK010);
KX010 = KdrQ.*(3+4.*mudrQ.*ZCRACK010)./(3+3.*KdrQ.*ZCRACK010+4.*mudrQ.*ZCRACK010);
MX010 = ((1-KX010./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1010 = 1-KX010./KdQ-(2.*mudrQ.*ZCRACK010)./(3+4.*mudrQ.*ZCRACK010).*KX010./KdQ;
a2010 = 1-KX010./KdQ+(6.*mudrQ.*ZCRACK010)./(3+4.*mudrQ.*ZCRACK010).*KX010./KdQ;
%C110100 = C1101001+a1010.^2.*MX010;
%C110100 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK010) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK010) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK010)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK010) + Kf .*(3 .*KdQ.^2.* ZCRACK010 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK010) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK010))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK010 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK010) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK010 + 3.* KdQ.* (-1 + phi).* ZCRACK010));
C110100 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK010)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK010 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK010) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK010 + 3.* KdQ.* (-1 + phi).* ZCRACK010))));
C220100 = C2201001+a2010.^2.*MX010;
C120100 = C1201001+a1010.*a2010.*MX010;
C660100 = mudrQ./(1+mudrQ.*ZCRACK010);
%%
MPX01002H = ((C11010H-C66010H).*sin(RAD010(2)).^2-(C22010H-C66010H).*cos(RAD010(2)).^2).^2+(C12010H+C66010H).^2.*sin(2.*RAD010(2));
MPX010020 = ((C110100-C660100).*sin(RAD010(2)).^2-(C220100-C660100).*cos(RAD010(2)).^2).^2+(C120100+C660100).^2.*sin(2.*RAD010(2));
C45010H = (C11010H.*sin(RAD010(2)).^2+C22010H.*cos(RAD010(2)).^2+C66010H+sqrt(MPX01002H));
C450100 = (C110100.*sin(RAD010(2)).^2+C220100.*cos(RAD010(2)).^2+C660100+sqrt(MPX010020));
C45010SH = (C11010H.*sin(RAD010(2)).^2+C22010H.*cos(RAD010(2)).^2+C66010H-sqrt(MPX01002H));
C45010S0 = (C110100.*sin(RAD010(2)).^2+C220100.*cos(RAD010(2)).^2+C660100-sqrt(MPX010020));
G010 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T010 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita010L = (C22010H(1)-C220100(1)).^3./(2.*C22010H(1).*C220100(1).^2.*T010.*G010.^2);
tao010L = ((C22010H(1)-C220100(1))./C220100(1)./G010).^2;
%%
fw010L = (1-cita010L+cita010L.*sqrt(1-sqrt(-1).*OMI.*tao010L./cita010L.^2));
%C11
CCZ11010L = 1./C11010H(1).*(1+((C11010H(1)-C110100(1))./C110100(1))./fw010L);
CCC11010L = 1./CCZ11010L;
Q1C11010L = abs(imag(CCC11010L)./real(CCC11010L));
%%
%C22
CCZ22010L = 1./C22010H(1).*(1+((C22010H(1)-C220100(1))./C220100(1))./fw010L);
CCC22010L = 1./CCZ22010L;
Q1C22010L = abs(imag(CCC22010L)./real(CCC22010L));
%%
%C12
CCZ12010L = 1./C12010H(1).*(1+((C12010H(1)-C120100(1))./C120100(1))./fw010L);
CCC12010L = 1./CCZ12010L;
Q1C12010L = abs(imag(CCC12010L)./real(CCC12010L));
%%
%C66
CCZ66010L = 1./C66010H(1).*(1+((C66010H(1)-C660100(1))./C660100(1))./fw010L);
CCC66010L = 1./CCZ66010L;
Q1C66010L = abs(imag(CCC66010L)./real(CCC66010L));
%%
%C45
CCC45010L = C45010H(1)./(1+((C45010H(1)-C450100(1))./C450100(1))./fw010L);
Q1C45010L = abs(imag(CCC45010L)./real(CCC45010L));
%%
%C45S
CCC45010SL = C45010SH(1)./(1+((C45010SH(1)-C45010S0(1))./C45010S0(1))./fw010L);
Q1C45010SL = abs(imag(CCC45010SL)./real(CCC45010SL));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01001L = ((CCC11010L-CCC66010L).*sin(RAD010(1)).^2-(CCC22010L-CCC66010L).*cos(RAD010(1)).^2).^2+(CCC12010L+CCC66010L).^2.*sin(2.*RAD010(1));
MPX01002L = ((CCC11010L-CCC66010L).*sin(RAD010(2)).^2-(CCC22010L-CCC66010L).*cos(RAD010(2)).^2).^2+(CCC12010L+CCC66010L).^2.*sin(2.*RAD010(2));
MPX01003L = ((CCC11010L-CCC66010L).*sin(RAD010(3)).^2-(CCC22010L-CCC66010L).*cos(RAD010(3)).^2).^2+(CCC12010L+CCC66010L).^2.*sin(2.*RAD010(3));

%P-wave velocity
VpX01001L = (CCC11010L.*sin(RAD010(1)).^2+CCC22010L.*cos(RAD010(1)).^2+CCC66010L+sqrt(MPX01001L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX01002L = (CCC11010L.*sin(RAD010(2)).^2+CCC22010L.*cos(RAD010(2)).^2+CCC66010L+sqrt(MPX01002L)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01002L = sqrt(CCC45010L./2./rhoR);
VpX01003L = (CCC11010L.*sin(RAD010(3)).^2+CCC22010L.*cos(RAD010(3)).^2+CCC66010L+sqrt(MPX01003L)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01001L = real(1./VpX01001L).^(-1);
Qp01001L = abs(imag(VpX01001L.^2)./real(VpX01001L.^2));
Vp01002L = real(1./VpX01002L).^(-1);
Qp01002L = abs(imag(VpX01002L.^2)./real(VpX01002L.^2));
Vp01003L = real(1./VpX01003L).^(-1);
Qp01003L = abs(imag(VpX01003L.^2)./real(VpX01003L.^2));
%%
%Anisotropy
epxl010L = (Vp01003L.^2-Vp01001L.^2)./(2.*Vp01001L.^2);
deltaV010L = 4.*(Vp01002L./Vp01001L-1)-(Vp01003L./Vp01001L-1);
%S-wave velocity
VsX01001L = (CCC11010L.*sin(RAD010(1)).^2+CCC22010L.*cos(RAD010(1)).^2+CCC66010L-sqrt(MPX01001L)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002L = (CCC11010L.*sin(RAD010(2)).^2+CCC22010L.*cos(RAD010(2)).^2+CCC66010L-sqrt(MPX01002L)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01002L = sqrt(CCC45010SL./2./rhoR);
VsX01003L = (CCC11010L.*sin(RAD010(3)).^2+CCC22010L.*cos(RAD010(3)).^2+CCC66010L-sqrt(MPX01003L)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01001L = real(1./VsX01001L).^(-1);
Qs01001L = abs(imag(VsX01001L.^2)./real(VsX01001L.^2));
Vs01002L = real(1./VsX01002L).^(-1);
Qs01002L = abs(imag(VsX01002L.^2)./real(VsX01002L.^2));
Vs01003L = real(1./VsX01003L).^(-1);
Qs01003L = abs(imag(VsX01003L.^2)./real(VsX01003L.^2));
%%
%Medial Pressure
cita010M = (C22010H(4)-C220100(4)).^3./(2.*C22010H(4).*C220100(4).^2.*T010.*G010.^2);
tao010M = ((C22010H(4)-C220100(4))./C220100(4)./G010).^2;
%%
fw010M = (1-cita010M+cita010M.*sqrt(1-sqrt(-1).*OMI.*tao010M./cita010M.^2));
%C11
CCZ11010M = 1./C11010H(4).*(1+((C11010H(4)-C110100(4))./C110100(4))./fw010M);
CCC11010M = 1./CCZ11010M;
Q1C11010M = abs(imag(CCC11010M)./real(CCC11010M));
%%
%C22
CCZ22010M = 1./C22010H(4).*(1+((C22010H(4)-C220100(4))./C220100(4))./fw010M);
CCC22010M = 1./CCZ22010M;
Q1C22010M = abs(imag(CCC22010M)./real(CCC22010M));
%%
%C12
CCZ12010M = 1./C12010H(4).*(1+((C12010H(4)-C120100(4))./C120100(4))./fw010M);
CCC12010M = 1./CCZ12010M;
Q1C12010M = abs(imag(CCC12010M)./real(CCC12010M));
%%
%C66
CCZ66010M = 1./C66010H(4).*(1+((C66010H(4)-C660100(4))./C660100(4))./fw010M);
CCC66010M = 1./CCZ66010M;
Q1C66010M = abs(imag(CCC66010M)./real(CCC66010M));
%%
%C45
CCC45010M = C45010H(4)./(1+((C45010H(4)-C450100(4))./C450100(4))./fw010M);
Q1C45010M = abs(imag(CCC45010M)./real(CCC45010M));
%%
%C45S
CCC45010SM = C45010SH(4)./(1+((C45010SH(4)-C45010S0(4))./C45010S0(4))./fw010M);
Q1C45010SM = abs(imag(CCC45010SM)./real(CCC45010SM));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01001M = ((CCC11010M-CCC66010M).*sin(RAD010(1)).^2-(CCC22010M-CCC66010M).*cos(RAD010(1)).^2).^2+(CCC12010M+CCC66010M).^2.*sin(2.*RAD010(1));
MPX01002M = ((CCC11010M-CCC66010M).*sin(RAD010(2)).^2-(CCC22010M-CCC66010M).*cos(RAD010(2)).^2).^2+(CCC12010M+CCC66010M).^2.*sin(2.*RAD010(2));
MPX01003M = ((CCC11010M-CCC66010M).*sin(RAD010(3)).^2-(CCC22010M-CCC66010M).*cos(RAD010(3)).^2).^2+(CCC12010M+CCC66010M).^2.*sin(2.*RAD010(3));

%P-wave velocity
VpX01001M = (CCC11010M.*sin(RAD010(1)).^2+CCC22010M.*cos(RAD010(1)).^2+CCC66010M+sqrt(MPX01001M)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX01002M = (CCC11010M.*sin(RAD010(2)).^2+CCC22010M.*cos(RAD010(2)).^2+CCC66010M+sqrt(MPX01002M)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01002M = sqrt(CCC45010M./2./rhoR);
VpX01003M = (CCC11010M.*sin(RAD010(3)).^2+CCC22010M.*cos(RAD010(3)).^2+CCC66010M+sqrt(MPX01003M)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01001M = real(1./VpX01001M).^(-1);
Qp01001M = abs(imag(VpX01001M.^2)./real(VpX01001M.^2));
Vp01002M = real(1./VpX01002M).^(-1);
Qp01002M = abs(imag(VpX01002M.^2)./real(VpX01002M.^2));
Vp01003M = real(1./VpX01003M).^(-1);
Qp01003M = abs(imag(VpX01003M.^2)./real(VpX01003M.^2));
%%
%Anisotropy
epxl010M = (Vp01003M.^2-Vp01001M.^2)./(2.*Vp01001M.^2);
deltaV010M = 4.*(Vp01002M./Vp01001M-1)-(Vp01003M./Vp01001M-1);
%S-wave velocity
VsX01001M = (CCC11010M.*sin(RAD010(1)).^2+CCC22010M.*cos(RAD010(1)).^2+CCC66010M-sqrt(MPX01001M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002M = (CCC11010M.*sin(RAD010(2)).^2+CCC22010M.*cos(RAD010(2)).^2+CCC66010M-sqrt(MPX01002M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01002M = sqrt(CCC45010SM./2./rhoR);
VsX01003M = (CCC11010M.*sin(RAD010(3)).^2+CCC22010M.*cos(RAD010(3)).^2+CCC66010M-sqrt(MPX01003M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01001M = real(1./VsX01001M).^(-1);
Qs01001M = abs(imag(VsX01001M.^2)./real(VsX01001M.^2));
Vs01002M = real(1./VsX01002M).^(-1);
Qs01002M = abs(imag(VsX01002M.^2)./real(VsX01002M.^2));
Vs01003M = real(1./VsX01003M).^(-1);
Qs01003M = abs(imag(VsX01003M.^2)./real(VsX01003M.^2));
%%
%High Pressure
cita010H = (C22010H(8)-C220100(8)).^3./(2.*C22010H(8).*C220100(8).^2.*T010.*G010.^2);
tao010H = ((C22010H(8)-C220100(8))./C220100(8)./G010).^2;
%%
fw010H = (1-cita010H+cita010H.*sqrt(1-sqrt(-1).*OMI.*tao010H./cita010H.^2));
%C11
CCZ11010H = 1./C11010H(8).*(1+((C11010H(8)-C110100(8))./C110100(8))./fw010H);
CCC11010H = 1./CCZ11010H;
Q1C11010H = abs(imag(CCC11010H)./real(CCC11010H));
%%
%C22
CCZ22010H = 1./C22010H(8).*(1+((C22010H(8)-C220100(8))./C220100(8))./fw010H);
CCC22010H = 1./CCZ22010H;
Q1C22010H = abs(imag(CCC22010H)./real(CCC22010H));
%%
%C12
CCZ12010H = 1./C12010H(8).*(1+((C12010H(8)-C120100(8))./C120100(8))./fw010H);
CCC12010H = 1./CCZ12010H;
Q1C12010H = abs(imag(CCC12010H)./real(CCC12010H));
%%
%C66
CCZ66010H = 1./C66010H(8).*(1+((C66010H(8)-C660100(8))./C660100(8))./fw010H);
CCC66010H = 1./CCZ66010H;
Q1C66010H = abs(imag(CCC66010H)./real(CCC66010H));
%%
%C45
CCC45010H = C45010H(8)./(1+((C45010H(8)-C450100(8))./C450100(8))./fw010H);
Q1C45010H = abs(imag(CCC45010H)./real(CCC45010H));
%%
%C45S
CCC45010SH = C45010SH(8)./(1+((C45010SH(8)-C45010S0(8))./C45010S0(8))./fw010H);
Q1C45010SH = abs(imag(CCC45010SH)./real(CCC45010SH));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX01001H = ((CCC11010H-CCC66010H).*sin(RAD010(1)).^2-(CCC22010H-CCC66010H).*cos(RAD010(1)).^2).^2+(CCC12010H+CCC66010H).^2.*sin(2.*RAD010(1));
MPX01002H = ((CCC11010H-CCC66010H).*sin(RAD010(2)).^2-(CCC22010H-CCC66010H).*cos(RAD010(2)).^2).^2+(CCC12010H+CCC66010H).^2.*sin(2.*RAD010(2));
MPX01003H = ((CCC11010H-CCC66010H).*sin(RAD010(3)).^2-(CCC22010H-CCC66010H).*cos(RAD010(3)).^2).^2+(CCC12010H+CCC66010H).^2.*sin(2.*RAD010(3));

%P-wave velocity
VpX01001H = (CCC11010H.*sin(RAD010(1)).^2+CCC22010H.*cos(RAD010(1)).^2+CCC66010H+sqrt(MPX01001H)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX01002H = (CCC11010H.*sin(RAD010(2)).^2+CCC22010H.*cos(RAD010(2)).^2+CCC66010H+sqrt(MPX01002H)).^(1/2).*(2.*rhoR).^(-1/2);
VpX01002H = sqrt(CCC45010H./2./rhoR);
VpX01003H = (CCC11010H.*sin(RAD010(3)).^2+CCC22010H.*cos(RAD010(3)).^2+CCC66010H+sqrt(MPX01003H)).^(1/2).*(2.*rhoR).^(-1/2);
Vp01001H = real(1./VpX01001H).^(-1);
Qp01001H = abs(imag(VpX01001H.^2)./real(VpX01001H.^2));
Vp01002H = real(1./VpX01002H).^(-1);
Qp01002H = abs(imag(VpX01002H.^2)./real(VpX01002H.^2));
Vp01003H = real(1./VpX01003H).^(-1);
Qp01003H = abs(imag(VpX01003H.^2)./real(VpX01003H.^2));
%%
%Anisotropy
epxl010H = (Vp01003H.^2-Vp01001H.^2)./(2.*Vp01001H.^2);
deltaV010H = 4.*(Vp01002H./Vp01001H-1)-(Vp01003H./Vp01001H-1);
%S-wave velocity
VsX01001H = (CCC11010H.*sin(RAD010(1)).^2+CCC22010H.*cos(RAD010(1)).^2+CCC66010H-sqrt(MPX01001H)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002H = (CCC11010H.*sin(RAD010(2)).^2+CCC22010H.*cos(RAD010(2)).^2+CCC66010H-sqrt(MPX01002H)).^(1/2).*(2.*rhoR).^(-1/2);
VsX01002H = sqrt(CCC45010SH./2./rhoR);
VsX01003H = (CCC11010H.*sin(RAD010(3)).^2+CCC22010H.*cos(RAD010(3)).^2+CCC66010H-sqrt(MPX01003H)).^(1/2).*(2.*rhoR).^(-1/2);
Vs01001H = real(1./VsX01001H).^(-1);
Qs01001H = abs(imag(VsX01001H.^2)./real(VsX01001H.^2));
Vs01002H = real(1./VsX01002H).^(-1);
Qs01002H = abs(imag(VsX01002H.^2)./real(VsX01002H.^2));
Vs01003H = real(1./VsX01003H).^(-1);
Qs01003H = abs(imag(VsX01003H.^2)./real(VsX01003H.^2));
%%
%Autocorrelation length = 10um
ZCRACK010C = eQ./STCRACK010; 
deltaN010C = CdrQ.*ZCRACK010C./(1+CdrQ.*ZCRACK010C);
ZCRACK010SC = ZCRACK010C./(1+Kf.*deltaN010C./(CQ.*phic.*(1-deltaN010C)).*(1-Kf./KdQ).^(-1));
C22010HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK010SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK010SC));
C01001C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK010C))./3./(4.*pi+9.*KdrQ.*ZCRACK010C);
KX010C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK010C);
MX010C = KdQ./((1-KX010C./KdQ)-phi.*(1-KdQ./Kf));
a1010C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK010C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK010C));
C0100C = C01001C+a1010C.^2.*MX010C;
G010C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
T010C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
cita010CL = (C22010HC(1)-C0100C(1)).^3./(2.*C22010HC(1).*C0100C(1).^2.*T010C.*G010C.^2);
tao010CL = ((C22010HC(1)-C0100C(1))./C0100C(1)./G010C).^2;
CCZ010CL = 1./C22010HC(1).*(1+((C22010HC(1)-C0100C(1))./C0100C(1))./(1-cita010CL+cita010CL.*sqrt(1-sqrt(-1).*OMI.*tao010CL./cita010CL.^2)));
CCC010CL = 1./CCZ010CL;
Q1C010CL = abs(imag(CCC010CL)./real(CCC010CL));
%
cita010CM = (C22010HC(4)-C0100C(4)).^3./(2.*C22010HC(4).*C0100C(4).^2.*T010C.*G010C.^2);
tao010CM = ((C22010HC(4)-C0100C(4))./C0100C(4)./G010C).^2;
CCZ010CM = 1./C22010HC(4).*(1+((C22010HC(4)-C0100C(4))./C0100C(4))./(1-cita010CM+cita010CM.*sqrt(1-sqrt(-1).*OMI.*tao010CM./cita010CM.^2)));
CCC010CM = 1./CCZ010CM;
Q1C010CM = abs(imag(CCC010CM)./real(CCC010CM));
%
cita010CH = (C22010HC(8)-C0100C(8)).^3./(2.*C22010HC(8).*C0100C(8).^2.*T010C.*G010C.^2);
tao010CH = ((C22010HC(8)-C0100C(8))./C0100C(8)./G010C).^2;
CCZ010CH = 1./C22010HC(8).*(1+((C22010HC(8)-C0100C(8))./C0100C(8))./(1-cita010CH+cita010CH.*sqrt(1-sqrt(-1).*OMI.*tao010CH./cita010CH.^2)));
CCC010CH = 1./CCZ010CH;
Q1C010CH = abs(imag(CCC010CH)./real(CCC010CH));
%%
%Autocorrelation length = 20 um
STCRACK020 =[0.02024708	0.048424123	0.067460905	0.086305806	0.098503016	0.110998472	0.118798324	0.134210732];
STPRE020 = [0	0.797387213	2.329036606	4.444630464	6.45711128	8.720523106	10.40659621	12.19239437];
C22020 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK020+4.*mudQ.*eQ./STCRACK020);
CC22020 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK020))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK020);
ZCRACK020 = eQ./STCRACK020; 
C44020 = mudQ./(1+mudQ.*ZCRACK020);
deltaN020 = CdrQ.*ZCRACK020./(1+CdrQ.*ZCRACK020);
ZCRACK020S = ZCRACK020./(1+Kf.*deltaN020./(CQ.*phic.*(1-deltaN020)).*(1-Kf./KdQ).^(-1));
C11020H = (4.*mudrQ.*(1+mudrQ.*ZCRACK020S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK020S))./(3+3.*KQBH.*ZCRACK020S+4.*mudrQ.*ZCRACK020S);
C1102001 = (4.*mudrQ.*(1+mudrQ.*ZCRACK020)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK020))./(3+3.*KdrQ.*ZCRACK020+4.*mudrQ.*ZCRACK020);
C22020H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK020S+4.*mudrQ.*ZCRACK020S);
C2202001 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK020+4.*mudrQ.*ZCRACK020);
C12020H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK020S+4.*mudrQ.*ZCRACK020S);
C1202001 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK020+4.*mudrQ.*ZCRACK020);
C66020H = mudrQ./(1+mudrQ.*ZCRACK020);
KX020 = KdrQ.*(3+4.*mudrQ.*ZCRACK020)./(3+3.*KdrQ.*ZCRACK020+4.*mudrQ.*ZCRACK020);
MX020 = ((1-KX020./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1020 = 1-KX020./KdQ-(2.*mudrQ.*ZCRACK020)./(3+4.*mudrQ.*ZCRACK020).*KX020./KdQ;
a2020 = 1-KX020./KdQ+(6.*mudrQ.*ZCRACK020)./(3+4.*mudrQ.*ZCRACK020).*KX020./KdQ;
%C110200 = C1102001+a1020.^2.*MX020;
%C110200 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK020) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK020) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK020)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK020) + Kf .*(3 .*KdQ.^2.* ZCRACK020 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK020) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK020))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK020 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK020) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK020 + 3.* KdQ.* (-1 + phi).* ZCRACK020));
C110200 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK020)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK020 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK020) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK020 + 3.* KdQ.* (-1 + phi).* ZCRACK020))));
C220200 = C2202001+a2020.^2.*MX020;
C120200 = C1202001+a1020.*a2020.*MX020;
C660200 = mudrQ./(1+mudrQ.*ZCRACK020);
%%
MPX02002H = ((C11020H-C66020H).*sin(RAD020(2)).^2-(C22020H-C66020H).*cos(RAD020(2)).^2).^2+(C12020H+C66020H).^2.*sin(2.*RAD020(2));
MPX020020 = ((C110200-C660200).*sin(RAD020(2)).^2-(C220200-C660200).*cos(RAD020(2)).^2).^2+(C120200+C660200).^2.*sin(2.*RAD020(2));
C45020H = (C11020H.*sin(RAD020(2)).^2+C22020H.*cos(RAD020(2)).^2+C66020H+sqrt(MPX02002H));
C450200 = (C110200.*sin(RAD020(2)).^2+C220200.*cos(RAD020(2)).^2+C660200+sqrt(MPX020020));
C45020SH = (C11020H.*sin(RAD020(2)).^2+C22020H.*cos(RAD020(2)).^2+C66020H-sqrt(MPX02002H));
C45020S0 = (C110200.*sin(RAD020(2)).^2+C220200.*cos(RAD020(2)).^2+C660200-sqrt(MPX020020));
%%
G020 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T020 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita020L = (C22020H(1)-C220200(1)).^3./(2.*C22020H(1).*C220200(1).^2.*T020.*G020.^2);
tao020L = ((C22020H(1)-C220200(1))./C220200(1)./G020).^2;
%%
fw020L = (1-cita020L+cita020L.*sqrt(1-sqrt(-1).*OMI.*tao020L./cita020L.^2));
%C11
CCZ11020L = 1./C11020H(1).*(1+((C11020H(1)-C110200(1))./C110200(1))./fw020L);
CCC11020L = 1./CCZ11020L;
Q1C11020L = abs(imag(CCC11020L)./real(CCC11020L));
%%
%C22
CCZ22020L = 1./C22020H(1).*(1+((C22020H(1)-C220200(1))./C220200(1))./fw020L);
CCC22020L = 1./CCZ22020L;
Q1C22020L = abs(imag(CCC22020L)./real(CCC22020L));
%%
%C12
CCZ12020L = 1./C12020H(1).*(1+((C12020H(1)-C120200(1))./C120200(1))./fw020L);
CCC12020L = 1./CCZ12020L;
Q1C12020L = abs(imag(CCC12020L)./real(CCC12020L));
%%
%C66
CCZ66020L = 1./C66020H(1).*(1+((C66020H(1)-C660200(1))./C660200(1))./fw020L);
CCC66020L = 1./CCZ66020L;
Q1C66020L = abs(imag(CCC66020L)./real(CCC66020L));
%%
%C45
CCC45020L = C45020H(1)./(1+((C45020H(1)-C450200(1))./C450200(1))./fw020L);
Q1C45020L = abs(imag(CCC45020L)./real(CCC45020L));
%%
%C45S
CCC45020SL = C45020SH(1)./(1+((C45020SH(1)-C45020S0(1))./C45020S0(1))./fw020L);
Q1C45020SL = abs(imag(CCC45020SL)./real(CCC45020SL));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX02001L = ((CCC11020L-CCC66020L).*sin(RAD020(1)).^2-(CCC22020L-CCC66020L).*cos(RAD020(1)).^2).^2+(CCC12020L+CCC66020L).^2.*sin(2.*RAD020(1));
MPX02002L = ((CCC11020L-CCC66020L).*sin(RAD020(2)).^2-(CCC22020L-CCC66020L).*cos(RAD020(2)).^2).^2+(CCC12020L+CCC66020L).^2.*sin(2.*RAD020(2));
MPX02003L = ((CCC11020L-CCC66020L).*sin(RAD020(3)).^2-(CCC22020L-CCC66020L).*cos(RAD020(3)).^2).^2+(CCC12020L+CCC66020L).^2.*sin(2.*RAD020(3));

%P-wave velocity
VpX02001L = (CCC11020L.*sin(RAD020(1)).^2+CCC22020L.*cos(RAD020(1)).^2+CCC66020L+sqrt(MPX02001L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX02002L = (CCC11020L.*sin(RAD020(2)).^2+CCC22020L.*cos(RAD020(2)).^2+CCC66020L+sqrt(MPX02002L)).^(1/2).*(2.*rhoR).^(-1/2);
VpX02002L = sqrt(CCC45020L./2./rhoR);
VpX02003L = (CCC11020L.*sin(RAD020(3)).^2+CCC22020L.*cos(RAD020(3)).^2+CCC66020L+sqrt(MPX02003L)).^(1/2).*(2.*rhoR).^(-1/2);
Vp02001L = real(1./VpX02001L).^(-1);
Qp02001L = abs(imag(VpX02001L.^2)./real(VpX02001L.^2));
Vp02002L = real(1./VpX02002L).^(-1);
Qp02002L = abs(imag(VpX02002L.^2)./real(VpX02002L.^2));
Vp02003L = real(1./VpX02003L).^(-1);
Qp02003L = abs(imag(VpX02003L.^2)./real(VpX02003L.^2));
%%
%Anisotropy
epxl020L = (Vp02003L.^2-Vp02001L.^2)./(2.*Vp02001L.^2);
deltaV020L = 4.*(Vp02002L./Vp02001L-1)-(Vp02003L./Vp02001L-1);
%S-wave velocity
VsX02001L = (CCC11020L.*sin(RAD020(1)).^2+CCC22020L.*cos(RAD020(1)).^2+CCC66020L-sqrt(MPX02001L)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002L = (CCC11020L.*sin(RAD020(2)).^2+CCC22020L.*cos(RAD020(2)).^2+CCC66020L-sqrt(MPX02002L)).^(1/2).*(2.*rhoR).^(-1/2);
VsX02002L = sqrt(CCC45020SL./2./rhoR);
VsX02003L = (CCC11020L.*sin(RAD020(3)).^2+CCC22020L.*cos(RAD020(3)).^2+CCC66020L-sqrt(MPX02003L)).^(1/2).*(2.*rhoR).^(-1/2);
Vs02001L = real(1./VsX02001L).^(-1);
Qs02001L = abs(imag(VsX02001L.^2)./real(VsX02001L.^2));
Vs02002L = real(1./VsX02002L).^(-1);
Qs02002L = abs(imag(VsX02002L.^2)./real(VsX02002L.^2));
Vs02003L = real(1./VsX02003L).^(-1);
Qs02003L = abs(imag(VsX02003L.^2)./real(VsX02003L.^2));
%%
%Medial Pressure
cita020M = (C22020H(4)-C220200(4)).^3./(2.*C22020H(4).*C220200(4).^2.*T020.*G020.^2);
tao020M = ((C22020H(4)-C220200(4))./C220200(4)./G020).^2;
%%
fw020M = (1-cita020M+cita020M.*sqrt(1-sqrt(-1).*OMI.*tao020M./cita020M.^2));
%C11
CCZ11020M = 1./C11020H(4).*(1+((C11020H(4)-C110200(4))./C110200(4))./fw020M);
CCC11020M = 1./CCZ11020M;
Q1C11020M = abs(imag(CCC11020M)./real(CCC11020M));
%%
%C22
CCZ22020M = 1./C22020H(4).*(1+((C22020H(4)-C220200(4))./C220200(4))./fw020M);
CCC22020M = 1./CCZ22020M;
Q1C22020M = abs(imag(CCC22020M)./real(CCC22020M));
%%
%C12
CCZ12020M = 1./C12020H(4).*(1+((C12020H(4)-C120200(4))./C120200(4))./fw020M);
CCC12020M = 1./CCZ12020M;
Q1C12020M = abs(imag(CCC12020M)./real(CCC12020M));
%%
%C66
CCZ66020M = 1./C66020H(4).*(1+((C66020H(4)-C660200(4))./C660200(4))./fw020M);
CCC66020M = 1./CCZ66020M;
Q1C66020M = abs(imag(CCC66020M)./real(CCC66020M));
%%
%C45
CCC45020M = C45020H(4)./(1+((C45020H(4)-C450200(4))./C450200(4))./fw020M);
Q1C45020M = abs(imag(CCC45020M)./real(CCC45020M));
%%
%C45S
CCC45020SM = C45020SH(4)./(1+((C45020SH(4)-C45020S0(4))./C45020S0(4))./fw020M);
Q1C45020SM = abs(imag(CCC45020SM)./real(CCC45020SM));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX02001M = ((CCC11020M-CCC66020M).*sin(RAD020(1)).^2-(CCC22020M-CCC66020M).*cos(RAD020(1)).^2).^2+(CCC12020M+CCC66020M).^2.*sin(2.*RAD020(1));
MPX02002M = ((CCC11020M-CCC66020M).*sin(RAD020(2)).^2-(CCC22020M-CCC66020M).*cos(RAD020(2)).^2).^2+(CCC12020M+CCC66020M).^2.*sin(2.*RAD020(2));
MPX02003M = ((CCC11020M-CCC66020M).*sin(RAD020(3)).^2-(CCC22020M-CCC66020M).*cos(RAD020(3)).^2).^2+(CCC12020M+CCC66020M).^2.*sin(2.*RAD020(3));
%P-wave velocity
VpX02001M = (CCC11020M.*sin(RAD020(1)).^2+CCC22020M.*cos(RAD020(1)).^2+CCC66020M+sqrt(MPX02001M)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX02002M = (CCC11020M.*sin(RAD020(2)).^2+CCC22020M.*cos(RAD020(2)).^2+CCC66020M+sqrt(MPX02002M)).^(1/2).*(2.*rhoR).^(-1/2);
VpX02002M = sqrt(CCC45020M./2./rhoR);
VpX02003M = (CCC11020M.*sin(RAD020(3)).^2+CCC22020M.*cos(RAD020(3)).^2+CCC66020M+sqrt(MPX02003M)).^(1/2).*(2.*rhoR).^(-1/2);
Vp02001M = real(1./VpX02001M).^(-1);
Qp02001M = abs(imag(VpX02001M.^2)./real(VpX02001M.^2));
Vp02002M = real(1./VpX02002M).^(-1);
Qp02002M = abs(imag(VpX02002M.^2)./real(VpX02002M.^2));
Vp02003M = real(1./VpX02003M).^(-1);
Qp02003M = abs(imag(VpX02003M.^2)./real(VpX02003M.^2));
%%
%Anisotropy
epxl020M = (Vp02003M.^2-Vp02001M.^2)./(2.*Vp02001M.^2);
deltaV020M = 4.*(Vp02002M./Vp02001M-1)-(Vp02003M./Vp02001M-1);
%S-wave velocity
VsX02001M = (CCC11020M.*sin(RAD020(1)).^2+CCC22020M.*cos(RAD020(1)).^2+CCC66020M-sqrt(MPX02001M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002M = (CCC11020M.*sin(RAD020(2)).^2+CCC22020M.*cos(RAD020(2)).^2+CCC66020M-sqrt(MPX02002M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX02002M = sqrt(CCC45020SM./2./rhoR);
VsX02003M = (CCC11020M.*sin(RAD020(3)).^2+CCC22020M.*cos(RAD020(3)).^2+CCC66020M-sqrt(MPX02003M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs02001M = real(1./VsX02001M).^(-1);
Qs02001M = abs(imag(VsX02001M.^2)./real(VsX02001M.^2));
Vs02002M = real(1./VsX02002M).^(-1);
Qs02002M = abs(imag(VsX02002M.^2)./real(VsX02002M.^2));
Vs02003M = real(1./VsX02003M).^(-1);
Qs02003M = abs(imag(VsX02003M.^2)./real(VsX02003M.^2));
%%
%High Pressure
cita020H = (C22020H(8)-C220200(8)).^3./(2.*C22020H(8).*C220200(8).^2.*T020.*G020.^2);
tao020H = ((C22020H(8)-C220200(8))./C220200(8)./G020).^2;
%%
fw020H = (1-cita020H+cita020H.*sqrt(1-sqrt(-1).*OMI.*tao020H./cita020H.^2));
%C11
CCZ11020H = 1./C11020H(8).*(1+((C11020H(8)-C110200(8))./C110200(8))./fw020H);
CCC11020H = 1./CCZ11020H;
Q1C11020H = abs(imag(CCC11020H)./real(CCC11020H));
%%
%C22
CCZ22020H = 1./C22020H(8).*(1+((C22020H(8)-C220200(8))./C220200(8))./fw020H);
CCC22020H = 1./CCZ22020H;
Q1C22020H = abs(imag(CCC22020H)./real(CCC22020H));
%%
%C12
CCZ12020H = 1./C12020H(8).*(1+((C12020H(8)-C120200(8))./C120200(8))./fw020H);
CCC12020H = 1./CCZ12020H;
Q1C12020H = abs(imag(CCC12020H)./real(CCC12020H));
%%
%C66
CCZ66020H = 1./C66020H(8).*(1+((C66020H(8)-C660200(8))./C660200(8))./fw020H);
CCC66020H = 1./CCZ66020H;
Q1C66020H = abs(imag(CCC66020H)./real(CCC66020H));
%%
%C45
CCC45020H = C45020H(8)./(1+((C45020H(8)-C450200(8))./C450200(8))./fw020H);
Q1C45020H = abs(imag(CCC45020H)./real(CCC45020H));
%%
%C45S
CCC45020SH = C45020SH(8)./(1+((C45020SH(8)-C45020S0(8))./C45020S0(8))./fw020H);
Q1C45020SH = abs(imag(CCC45020SH)./real(CCC45020SH));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX02001H = ((CCC11020H-CCC66020H).*sin(RAD020(1)).^2-(CCC22020H-CCC66020H).*cos(RAD020(1)).^2).^2+(CCC12020H+CCC66020H).^2.*sin(2.*RAD020(1));
MPX02002H = ((CCC11020H-CCC66020H).*sin(RAD020(2)).^2-(CCC22020H-CCC66020H).*cos(RAD020(2)).^2).^2+(CCC12020H+CCC66020H).^2.*sin(2.*RAD020(2));
MPX02003H = ((CCC11020H-CCC66020H).*sin(RAD020(3)).^2-(CCC22020H-CCC66020H).*cos(RAD020(3)).^2).^2+(CCC12020H+CCC66020H).^2.*sin(2.*RAD020(3));
%P-wave velocity
VpX02001H = (CCC11020H.*sin(RAD020(1)).^2+CCC22020H.*cos(RAD020(1)).^2+CCC66020H+sqrt(MPX02001H)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX02002H = (CCC11020H.*sin(RAD020(2)).^2+CCC22020H.*cos(RAD020(2)).^2+CCC66020H+sqrt(MPX02002H)).^(1/2).*(2.*rhoR).^(-1/2);
VpX02002H = sqrt(CCC45020H./2./rhoR);
VpX02003H = (CCC11020H.*sin(RAD020(3)).^2+CCC22020H.*cos(RAD020(3)).^2+CCC66020H+sqrt(MPX02003H)).^(1/2).*(2.*rhoR).^(-1/2);
Vp02001H = real(1./VpX02001H).^(-1);
Qp02001H = abs(imag(VpX02001H.^2)./real(VpX02001H.^2));
Vp02002H = real(1./VpX02002H).^(-1);
Qp02002H = abs(imag(VpX02002H.^2)./real(VpX02002H.^2));
Vp02003H = real(1./VpX02003H).^(-1);
Qp02003H = abs(imag(VpX02003H.^2)./real(VpX02003H.^2));
%%
%Anisotropy
epxl020H = (Vp02003H.^2-Vp02001H.^2)./(2.*Vp02001H.^2);
deltaV020H = 4.*(Vp02002H./Vp02001H-1)-(Vp02003H./Vp02001H-1);
%S-wave velocity
VsX02001H = (CCC11020H.*sin(RAD020(1)).^2+CCC22020H.*cos(RAD020(1)).^2+CCC66020H-sqrt(MPX02001H)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX01002H = (CCC11020H.*sin(RAD020(2)).^2+CCC22020H.*cos(RAD020(2)).^2+CCC66020H-sqrt(MPX02002H)).^(1/2).*(2.*rhoR).^(-1/2);
VsX02002H = sqrt(CCC45020SH./2./rhoR);
VsX02003H = (CCC11020H.*sin(RAD020(3)).^2+CCC22020H.*cos(RAD020(3)).^2+CCC66020H-sqrt(MPX02003H)).^(1/2).*(2.*rhoR).^(-1/2);
Vs02001H = real(1./VsX02001H).^(-1);
Qs02001H = abs(imag(VsX02001H.^2)./real(VsX02001H.^2));
Vs02002H = real(1./VsX02002H).^(-1);
Qs02002H = abs(imag(VsX02002H.^2)./real(VsX02002H.^2));
Vs02003H = real(1./VsX02003H).^(-1);
Qs02003H = abs(imag(VsX02003H.^2)./real(VsX02003H.^2));
%%
%Autocorrelation length = 20um
ZCRACK020C = eQ./STCRACK020; 
deltaN020C = CdrQ.*ZCRACK020C./(1+CdrQ.*ZCRACK020C);
ZCRACK020SC = ZCRACK020C./(1+Kf.*deltaN020C./(CQ.*phic.*(1-deltaN020C)).*(1-Kf./KdQ).^(-1));
C22020HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK020SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK020SC));
C02001C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK020C))./3./(4.*pi+9.*KdrQ.*ZCRACK020C);
KX020C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK020C);
MX020C = KdQ./((1-KX020C./KdQ)-phi.*(1-KdQ./Kf));
a1020C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK020C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK020C));
C0200C = C02001C+a1020C.^2.*MX020C;
G020C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
T020C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
cita020CL = (C22020HC(1)-C0200C(1)).^3./(2.*C22020HC(1).*C0200C(1).^2.*T020C.*G020C.^2);
tao020CL = ((C22020HC(1)-C0200C(1))./C0200C(1)./G020C).^2;
CCZ020CL = 1./C22020HC(1).*(1+((C22020HC(1)-C0200C(1))./C0200C(1))./(1-cita020CL+cita020CL.*sqrt(1-sqrt(-1).*OMI.*tao020CL./cita020CL.^2)));
CCC020CL = 1./CCZ020CL;
Q1C020CL = abs(imag(CCC020CL)./real(CCC020CL));
%%
%Autocorrelation length = 50 um
STCRACK050 = [0.025542067	0.060483652	0.085036727	0.106304137	0.120387574	0.132243078	0.141728188	0.155380237];
STPRE050 = [0	1.012214581	2.942876251	5.630486073	8.124953186	10.91421501	12.92887952	15.07051191];
C22050 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK050+4.*mudQ.*eQ./STCRACK050);
CC22050 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK050))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK050);
ZCRACK050 = eQ./STCRACK050; 
C44050 = mudQ./(1+mudQ.*ZCRACK050);
deltaN050 = CdrQ.*ZCRACK050./(1+CdrQ.*ZCRACK050);
ZCRACK050S = ZCRACK050./(1+Kf.*deltaN050./(CQ.*phic.*(1-deltaN050)).*(1-Kf./KdQ).^(-1));
C11050H = (4.*mudrQ.*(1+mudrQ.*ZCRACK050S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK050S))./(3+3.*KQBH.*ZCRACK050S+4.*mudrQ.*ZCRACK050S);
C1105001 = (4.*mudrQ.*(1+mudrQ.*ZCRACK050)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK050))./(3+3.*KdrQ.*ZCRACK050+4.*mudrQ.*ZCRACK050);
C22050H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK050S+4.*mudrQ.*ZCRACK050S);
C2205001 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK050+4.*mudrQ.*ZCRACK050);
C12050H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK050S+4.*mudrQ.*ZCRACK050S);
C1205001 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK050+4.*mudrQ.*ZCRACK050);
C66050H = mudrQ./(1+mudrQ.*ZCRACK050);
KX050 = KdrQ.*(3+4.*mudrQ.*ZCRACK050)./(3+3.*KdrQ.*ZCRACK050+4.*mudrQ.*ZCRACK050);
MX050 = ((1-KX050./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1050 = 1-KX050./KdQ-(2.*mudrQ.*ZCRACK050)./(3+4.*mudrQ.*ZCRACK050).*KX050./KdQ;
a2050 = 1-KX050./KdQ+(6.*mudrQ.*ZCRACK050)./(3+4.*mudrQ.*ZCRACK050).*KX050./KdQ;
%C110500 = C1105001+a1050.^2.*MX050;
%C110500 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK050) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK050) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK050)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK050) + Kf .*(3 .*KdQ.^2.* ZCRACK050 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK050) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK050))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK050 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK050) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK050 + 3.* KdQ.* (-1 + phi).* ZCRACK050));
C110500 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK050)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK050 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK050) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK050 + 3.* KdQ.* (-1 + phi).* ZCRACK050))));
C220500 = C2205001+a2050.^2.*MX050;
C120500 = C1205001+a1050.*a2050.*MX050;
C660500 = mudrQ./(1+mudrQ.*ZCRACK050);
%%
MPX05002H = ((C11050H-C66050H).*sin(RAD050(2)).^2-(C22050H-C66050H).*cos(RAD050(2)).^2).^2+(C12050H+C66050H).^2.*sin(2.*RAD050(2));
MPX050020 = ((C110500-C660500).*sin(RAD050(2)).^2-(C220500-C660500).*cos(RAD050(2)).^2).^2+(C120500+C660500).^2.*sin(2.*RAD050(2));
C45050H = (C11050H.*sin(RAD050(2)).^2+C22050H.*cos(RAD050(2)).^2+C66050H+sqrt(MPX05002H));
C450500 = (C110500.*sin(RAD050(2)).^2+C220500.*cos(RAD050(2)).^2+C660500+sqrt(MPX050020));
C45050SH = (C11050H.*sin(RAD050(2)).^2+C22050H.*cos(RAD050(2)).^2+C66050H-sqrt(MPX05002H));
C45050S0 = (C110500.*sin(RAD050(2)).^2+C220500.*cos(RAD050(2)).^2+C660500-sqrt(MPX050020));
%%
G050 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T050 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita050L = (C22050H(1)-C220500(1)).^3./(2.*C22050H(1).*C220500(1).^2.*T050.*G050.^2);
tao050L = ((C22050H(1)-C220500(1))./C220500(1)./G050).^2;
%%
fw050L = (1-cita050L+cita050L.*sqrt(1-sqrt(-1).*OMI.*tao050L./cita050L.^2));
%C11
CCZ11050L = 1./C11050H(1).*(1+((C11050H(1)-C110500(1))./C110500(1))./fw050L);
CCC11050L = 1./CCZ11050L;
Q1C11050L = abs(imag(CCC11050L)./real(CCC11050L));
%%
%C22
CCZ22050L = 1./C22050H(1).*(1+((C22050H(1)-C220500(1))./C220500(1))./fw050L);
CCC22050L = 1./CCZ22050L;
Q1C22050L = abs(imag(CCC22050L)./real(CCC22050L));
%%
%C12
CCZ12050L = 1./C12050H(1).*(1+((C12050H(1)-C120500(1))./C120500(1))./fw050L);
CCC12050L = 1./CCZ12050L;
Q1C12050L = abs(imag(CCC12050L)./real(CCC12050L));
%%
%C66
CCZ66050L = 1./C66050H(1).*(1+((C66050H(1)-C660500(1))./C660500(1))./fw050L);
CCC66050L = 1./CCZ66050L;
Q1C66050L = abs(imag(CCC66050L)./real(CCC66050L));
%%
%C45
CCC45050L = C45050H(1)./(1+((C45050H(1)-C450500(1))./C450500(1))./fw050L);
Q1C45050L = abs(imag(CCC45050L)./real(CCC45050L));
%%
%C45S
CCC45050SL = C45050SH(1)./(1+((C45050SH(1)-C45050S0(1))./C45050S0(1))./fw050L);
Q1C45050SL = abs(imag(CCC45050SL)./real(CCC45050SL));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX05001L = ((CCC11050L-CCC66050L).*sin(RAD050(1)).^2-(CCC22050L-CCC66050L).*cos(RAD050(1)).^2).^2+(CCC12050L+CCC66050L).^2.*sin(2.*RAD050(1));
MPX05002L = ((CCC11050L-CCC66050L).*sin(RAD050(2)).^2-(CCC22050L-CCC66050L).*cos(RAD050(2)).^2).^2+(CCC12050L+CCC66050L).^2.*sin(2.*RAD050(2));
MPX05003L = ((CCC11050L-CCC66050L).*sin(RAD050(3)).^2-(CCC22050L-CCC66050L).*cos(RAD050(3)).^2).^2+(CCC12050L+CCC66050L).^2.*sin(2.*RAD050(3));

%P-wave velocity
VpX05001L = (CCC11050L.*sin(RAD050(1)).^2+CCC22050L.*cos(RAD050(1)).^2+CCC66050L+sqrt(MPX05001L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX05002L = (CCC11050L.*sin(RAD050(2)).^2+CCC22050L.*cos(RAD050(2)).^2+CCC66050L+sqrt(MPX05002L)).^(1/2).*(2.*rhoR).^(-1/2);
VpX05002L = sqrt(CCC45050L./2./rhoR);
VpX05003L = (CCC11050L.*sin(RAD050(3)).^2+CCC22050L.*cos(RAD050(3)).^2+CCC66050L+sqrt(MPX05003L)).^(1/2).*(2.*rhoR).^(-1/2);
Vp05001L = real(1./VpX05001L).^(-1);
Qp05001L = abs(imag(VpX05001L.^2)./real(VpX05001L.^2));
Vp05002L = real(1./VpX05002L).^(-1);
Qp05002L = abs(imag(VpX05002L.^2)./real(VpX05002L.^2));
Vp05003L = real(1./VpX05003L).^(-1);
Qp05003L = abs(imag(VpX05003L.^2)./real(VpX05003L.^2));
%%
%Anisotropy
epxl050L = (Vp05003L.^2-Vp05001L.^2)./(2.*Vp05001L.^2);
deltaV050L = 4.*(Vp05002L./Vp05001L-1)-(Vp05003L./Vp05001L-1);
%S-wave velocity
VsX05001L = (CCC11050L.*sin(RAD050(1)).^2+CCC22050L.*cos(RAD050(1)).^2+CCC66050L-sqrt(MPX05001L)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX05002L = (CCC11050L.*sin(RAD050(2)).^2+CCC22050L.*cos(RAD050(2)).^2+CCC66050L-sqrt(MPX05002L)).^(1/2).*(2.*rhoR).^(-1/2);
VsX05002L = sqrt(CCC45050SL./2./rhoR);
VsX05003L = (CCC11050L.*sin(RAD050(3)).^2+CCC22050L.*cos(RAD050(3)).^2+CCC66050L-sqrt(MPX05003L)).^(1/2).*(2.*rhoR).^(-1/2);
Vs05001L = real(1./VsX05001L).^(-1);
Qs05001L = abs(imag(VsX05001L.^2)./real(VsX05001L.^2));
Vs05002L = real(1./VsX05002L).^(-1);
Qs05002L = abs(imag(VsX05002L.^2)./real(VsX05002L.^2));
Vs05003L = real(1./VsX05003L).^(-1);
Qs05003L = abs(imag(VsX05003L.^2)./real(VsX05003L.^2));
%%
%Medial Pressure
cita050M = (C22050H(4)-C220500(4)).^3./(2.*C22050H(4).*C220500(4).^2.*T050.*G050.^2);
tao050M = ((C22050H(4)-C220500(4))./C220500(4)./G050).^2;
%%
fw050M = (1-cita050M+cita050M.*sqrt(1-sqrt(-1).*OMI.*tao050M./cita050M.^2));
%C11
CCZ11050M = 1./C11050H(4).*(1+((C11050H(4)-C110500(4))./C110500(4))./fw050M);
CCC11050M = 1./CCZ11050M;
Q1C11050M = abs(imag(CCC11050M)./real(CCC11050M));
%%
%C22
CCZ22050M = 1./C22050H(4).*(1+((C22050H(4)-C220500(4))./C220500(4))./fw050M);
CCC22050M = 1./CCZ22050M;
Q1C22050M = abs(imag(CCC22050M)./real(CCC22050M));
%%
%C12
CCZ12050M = 1./C12050H(4).*(1+((C12050H(4)-C120500(4))./C120500(4))./fw050M);
CCC12050M = 1./CCZ12050M;
Q1C12050M = abs(imag(CCC12050M)./real(CCC12050M));
%%
%C66
CCZ66050M = 1./C66050H(4).*(1+((C66050H(4)-C660500(4))./C660500(4))./fw050M);
CCC66050M = 1./CCZ66050M;
Q1C66050M = abs(imag(CCC66050M)./real(CCC66050M));
%%
%C45
CCC45050M = C45050H(4)./(1+((C45050H(4)-C450500(4))./C450500(4))./fw050M);
Q1C45050M = abs(imag(CCC45050M)./real(CCC45050M));
%%
%C45S
CCC45050SM = C45050SH(4)./(1+((C45050SH(4)-C45050S0(4))./C45050S0(4))./fw050M);
Q1C45050SM = abs(imag(CCC45050SM)./real(CCC45050SM));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX05001M = ((CCC11050M-CCC66050M).*sin(RAD050(1)).^2-(CCC22050M-CCC66050M).*cos(RAD050(1)).^2).^2+(CCC12050M+CCC66050M).^2.*sin(2.*RAD050(1));
MPX05002M = ((CCC11050M-CCC66050M).*sin(RAD050(2)).^2-(CCC22050M-CCC66050M).*cos(RAD050(2)).^2).^2+(CCC12050M+CCC66050M).^2.*sin(2.*RAD050(2));
MPX05003M = ((CCC11050M-CCC66050M).*sin(RAD050(3)).^2-(CCC22050M-CCC66050M).*cos(RAD050(3)).^2).^2+(CCC12050M+CCC66050M).^2.*sin(2.*RAD050(3));

%P-wave velocity
VpX05001M = (CCC11050M.*sin(RAD050(1)).^2+CCC22050M.*cos(RAD050(1)).^2+CCC66050M+sqrt(MPX05001M)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX05002M = (CCC11050M.*sin(RAD050(2)).^2+CCC22050M.*cos(RAD050(2)).^2+CCC66050M+sqrt(MPX05002M)).^(1/2).*(2.*rhoR).^(-1/2);
VpX05002M = sqrt(CCC45050M./2./rhoR);
VpX05003M = (CCC11050M.*sin(RAD050(3)).^2+CCC22050M.*cos(RAD050(3)).^2+CCC66050M+sqrt(MPX05003M)).^(1/2).*(2.*rhoR).^(-1/2);
Vp05001M = real(1./VpX05001M).^(-1);
Qp05001M = abs(imag(VpX05001M.^2)./real(VpX05001M.^2));
Vp05002M = real(1./VpX05002M).^(-1);
Qp05002M = abs(imag(VpX05002M.^2)./real(VpX05002M.^2));
Vp05003M = real(1./VpX05003M).^(-1);
Qp05003M = abs(imag(VpX05003M.^2)./real(VpX05003M.^2));
%%
%Anisotropy
epxl050M = (Vp05003M.^2-Vp05001M.^2)./(2.*Vp05001M.^2);
deltaV050M = 4.*(Vp05002M./Vp05001M-1)-(Vp05003M./Vp05001M-1);
%S-wave velocity
VsX05001M = (CCC11050M.*sin(RAD050(1)).^2+CCC22050M.*cos(RAD050(1)).^2+CCC66050M-sqrt(MPX05001M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX05002M = (CCC11050M.*sin(RAD050(2)).^2+CCC22050M.*cos(RAD050(2)).^2+CCC66050M-sqrt(MPX05002M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX05002M = sqrt(CCC45050SM./2./rhoR);
VsX05003M = (CCC11050M.*sin(RAD050(3)).^2+CCC22050M.*cos(RAD050(3)).^2+CCC66050M-sqrt(MPX05003M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs05001M = real(1./VsX05001M).^(-1);
Qs05001M = abs(imag(VsX05001M.^2)./real(VsX05001M.^2));
Vs05002M = real(1./VsX05002M).^(-1);
Qs05002M = abs(imag(VsX05002M.^2)./real(VsX05002M.^2));
Vs05003M = real(1./VsX05003M).^(-1);
Qs05003M = abs(imag(VsX05003M.^2)./real(VsX05003M.^2));
%%
%High Pressure
cita050H = (C22050H(8)-C220500(8)).^3./(2.*C22050H(8).*C220500(8).^2.*T050.*G050.^2);
tao050H = ((C22050H(8)-C220500(8))./C220500(8)./G050).^2;
%%
fw050H = (1-cita050H+cita050H.*sqrt(1-sqrt(-1).*OMI.*tao050H./cita050H.^2));
%C11
CCZ11050H = 1./C11050H(8).*(1+((C11050H(8)-C110500(8))./C110500(8))./fw050H);
CCC11050H = 1./CCZ11050H;
Q1C11050H = abs(imag(CCC11050H)./real(CCC11050H));
%%
%C22
CCZ22050H = 1./C22050H(8).*(1+((C22050H(8)-C220500(8))./C220500(8))./fw050H);
CCC22050H = 1./CCZ22050H;
Q1C22050H = abs(imag(CCC22050H)./real(CCC22050H));
%%
%C12
CCZ12050H = 1./C12050H(8).*(1+((C12050H(8)-C120500(8))./C120500(8))./fw050H);
CCC12050H = 1./CCZ12050H;
Q1C12050H = abs(imag(CCC12050H)./real(CCC12050H));
%%
%C66
CCZ66050H = 1./C66050H(8).*(1+((C66050H(8)-C660500(8))./C660500(8))./fw050H);
CCC66050H = 1./CCZ66050H;
Q1C66050H = abs(imag(CCC66050H)./real(CCC66050H));
%%
%C45
CCC45050H = C45050H(8)./(1+((C45050H(8)-C450500(8))./C450500(8))./fw050H);
Q1C45050H = abs(imag(CCC45050H)./real(CCC45050H));
%%
%C45S
CCC45050SH = C45050SH(8)./(1+((C45050SH(8)-C45050S0(8))./C45050S0(8))./fw050H);
Q1C45050SH = abs(imag(CCC45050SH)./real(CCC45050SH));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX05001H = ((CCC11050H-CCC66050H).*sin(RAD050(1)).^2-(CCC22050H-CCC66050H).*cos(RAD050(1)).^2).^2+(CCC12050H+CCC66050H).^2.*sin(2.*RAD050(1));
MPX05002H = ((CCC11050H-CCC66050H).*sin(RAD050(2)).^2-(CCC22050H-CCC66050H).*cos(RAD050(2)).^2).^2+(CCC12050H+CCC66050H).^2.*sin(2.*RAD050(2));
MPX05003H = ((CCC11050H-CCC66050H).*sin(RAD050(3)).^2-(CCC22050H-CCC66050H).*cos(RAD050(3)).^2).^2+(CCC12050H+CCC66050H).^2.*sin(2.*RAD050(3));

%P-wave velocity
VpX05001H = (CCC11050H.*sin(RAD050(1)).^2+CCC22050H.*cos(RAD050(1)).^2+CCC66050H+sqrt(MPX05001H)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX05002H = (CCC11050H.*sin(RAD050(2)).^2+CCC22050H.*cos(RAD050(2)).^2+CCC66050H+sqrt(MPX05002H)).^(1/2).*(2.*rhoR).^(-1/2);
VpX05002H = sqrt(CCC45050H./2./rhoR);
VpX05003H = (CCC11050H.*sin(RAD050(3)).^2+CCC22050H.*cos(RAD050(3)).^2+CCC66050H+sqrt(MPX05003H)).^(1/2).*(2.*rhoR).^(-1/2);
Vp05001H = real(1./VpX05001H).^(-1);
Qp05001H = abs(imag(VpX05001H.^2)./real(VpX05001H.^2));
Vp05002H = real(1./VpX05002H).^(-1);
Qp05002H = abs(imag(VpX05002H.^2)./real(VpX05002H.^2));
Vp05003H = real(1./VpX05003H).^(-1);
Qp05003H = abs(imag(VpX05003H.^2)./real(VpX05003H.^2));
%%
%Anisotropy
epxl050H = (Vp05003H.^2-Vp05001H.^2)./(2.*Vp05001H.^2);
deltaV050H = 4.*(Vp05002H./Vp05001H-1)-(Vp05003H./Vp05001H-1);
%S-wave velocity
VsX05001H = (CCC11050H.*sin(RAD050(1)).^2+CCC22050H.*cos(RAD050(1)).^2+CCC66050H-sqrt(MPX05001H)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX05002H = (CCC11050H.*sin(RAD050(2)).^2+CCC22050H.*cos(RAD050(2)).^2+CCC66050H-sqrt(MPX05002H)).^(1/2).*(2.*rhoR).^(-1/2);
VsX05002H = sqrt(CCC45050SH./2./rhoR);
VsX05003H = (CCC11050H.*sin(RAD050(3)).^2+CCC22050H.*cos(RAD050(3)).^2+CCC66050H-sqrt(MPX05003H)).^(1/2).*(2.*rhoR).^(-1/2);
Vs05001H = real(1./VsX05001H).^(-1);
Qs05001H = abs(imag(VsX05001H.^2)./real(VsX05001H.^2));
Vs05002H = real(1./VsX05002H).^(-1);
Qs05002H = abs(imag(VsX05002H.^2)./real(VsX05002H.^2));
Vs05003H = real(1./VsX05003H).^(-1);
Qs05003H = abs(imag(VsX05003H.^2)./real(VsX05003H.^2));
%%
%Autocorrelation length = 50um
ZCRACK050C = eQ./STCRACK050; 
deltaN050C = CdrQ.*ZCRACK050C./(1+CdrQ.*ZCRACK050C);
ZCRACK050SC = ZCRACK050C./(1+Kf.*deltaN050C./(CQ.*phic.*(1-deltaN050C)).*(1-Kf./KdQ).^(-1));
C22050HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK050SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK050SC));
C05001C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK050C))./3./(4.*pi+9.*KdrQ.*ZCRACK050C);
KX050C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK050C);
MX050C = KdQ./((1-KX050C./KdQ)-phi.*(1-KdQ./Kf));
a1050C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK050C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK050C));
C0500C = C05001C+a1050C.^2.*MX050C;
G050C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
T050C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
cita050CL = (C22050HC(1)-C0500C(1)).^3./(2.*C22050HC(1).*C0500C(1).^2.*T050C.*G050C.^2);
tao050CL = ((C22050HC(1)-C0500C(1))./C0500C(1)./G050C).^2;
CCZ050CL = 1./C22050HC(1).*(1+((C22050HC(1)-C0500C(1))./C0500C(1))./(1-cita050CL+cita050CL.*sqrt(1-sqrt(-1).*OMI.*tao050CL./cita050CL.^2)));
CCC050CL = 1./CCZ050CL;
Q1C050CL = abs(imag(CCC050CL)./real(CCC050CL));
%%
%Autocorrelation length 100 um
STCRACK100 = [0.025196418	0.057455017	0.078283414	0.097636374	0.111761283	0.125227575	0.13297916	0.143853479];
STPRE100 = [0	1.005983145	2.869487138	5.397357205	7.748816672	10.41647968	12.39357412	14.46656013];
C22100 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK100+4.*mudQ.*eQ./STCRACK100);
CC22100 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK100))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK100);
ZCRACK100 = eQ./STCRACK100; 
C44100 = mudQ./(1+mudQ.*ZCRACK100);
deltaN100 = CdrQ.*ZCRACK100./(1+CdrQ.*ZCRACK100);
ZCRACK100S = ZCRACK100./(1+Kf.*deltaN100./(CQ.*phic.*(1-deltaN100)).*(1-Kf./KdQ).^(-1));
C11100H = (4.*mudrQ.*(1+mudrQ.*ZCRACK100S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK100S))./(3+3.*KQBH.*ZCRACK100S+4.*mudrQ.*ZCRACK100S);
C1110001 = (4.*mudrQ.*(1+mudrQ.*ZCRACK100)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK100))./(3+3.*KdrQ.*ZCRACK100+4.*mudrQ.*ZCRACK100);
C22100H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK100S+4.*mudrQ.*ZCRACK100S);
C2210001 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK100+4.*mudrQ.*ZCRACK100);
C12100H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK100S+4.*mudrQ.*ZCRACK100S);
C1210001 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK100+4.*mudrQ.*ZCRACK100);
C66100H = mudrQ./(1+mudrQ.*ZCRACK100);
KX100 = KdrQ.*(3+4.*mudrQ.*ZCRACK100)./(3+3.*KdrQ.*ZCRACK100+4.*mudrQ.*ZCRACK100);
MX100 = ((1-KX100./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1100 = 1-KX100./KdQ-(2.*mudrQ.*ZCRACK100)./(3+4.*mudrQ.*ZCRACK100).*KX100./KdQ;
a2100 = 1-KX100./KdQ+(6.*mudrQ.*ZCRACK100)./(3+4.*mudrQ.*ZCRACK100).*KX100./KdQ;
%C111000 = C1110001+a1100.^2.*MX100;
%C111000 = (KdQ.* (-4.* Kf.* mudrQ.* (-1 + phi).*(1 + mudrQ.* ZCRACK100) + 4 .*KdQ .*mudrQ .*phi.* (1 + mudrQ.* ZCRACK100) + Kf.* KdQ.* (3 + 4 .*mudrQ.* ZCRACK100)) + KdrQ .*(3.* KdQ.^2.* phi.* (1 + 4.*mudrQ.* ZCRACK100) + Kf .*(3 .*KdQ.^2.* ZCRACK100 - 4.* mudrQ.* (1 + mudrQ.* ZCRACK100) - 3.* KdQ .*(1 + phi + 4.* mudrQ.* phi.* ZCRACK100))))./(3 .*KdrQ .*KdQ.^2 .*phi.* ZCRACK100 + KdQ.* (Kf - Kf .*phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK100) - KdrQ.* Kf .*(3 + 4 .*mudrQ.* ZCRACK100 + 3.* KdQ.* (-1 + phi).* ZCRACK100));
C111000 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK100)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK100 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK100) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK100 + 3.* KdQ.* (-1 + phi).* ZCRACK100))));
C221000 = C2210001+a2100.^2.*MX100;
C121000 = C1210001+a1100.*a2100.*MX100;
C661000 = mudrQ./(1+mudrQ.*ZCRACK100);
%%
MPX10002H = ((C11100H-C66100H).*sin(RAD100(2)).^2-(C22100H-C66100H).*cos(RAD100(2)).^2).^2+(C12100H+C66100H).^2.*sin(2.*RAD100(2));
MPX100020 = ((C111000-C661000).*sin(RAD100(2)).^2-(C221000-C661000).*cos(RAD100(2)).^2).^2+(C121000+C661000).^2.*sin(2.*RAD100(2));
C45100H = (C11100H.*sin(RAD100(2)).^2+C22100H.*cos(RAD100(2)).^2+C66100H+sqrt(MPX10002H));
C451000 = (C111000.*sin(RAD100(2)).^2+C221000.*cos(RAD100(2)).^2+C661000+sqrt(MPX100020));
C45100SH = (C11100H.*sin(RAD100(2)).^2+C22100H.*cos(RAD100(2)).^2+C66100H-sqrt(MPX10002H));
C45100S0 = (C111000.*sin(RAD100(2)).^2+C221000.*cos(RAD100(2)).^2+C661000-sqrt(MPX100020));
%
G100 = 2.*pi.*eQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T100 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita100L = (C22100H(1)-C221000(1)).^3./(2.*C22100H(1).*C221000(1).^2.*T100.*G100.^2);
tao100L = ((C22100H(1)-C221000(1))./C221000(1)./G100).^2;
%%
fw100L = (1-cita100L+cita100L.*sqrt(1-sqrt(-1).*OMI.*tao100L./cita100L.^2));
%C11
CCZ11100L = 1./C11100H(1).*(1+((C11100H(1)-C111000(1))./C111000(1))./fw100L);
CCC11100L = 1./CCZ11100L;
Q1C11100L = abs(imag(CCC11100L)./real(CCC11100L));
%%
%C22
CCZ22100L = 1./C22100H(1).*(1+((C22100H(1)-C221000(1))./C221000(1))./fw100L);
CCC22100L = 1./CCZ22100L;
Q1C22100L = abs(imag(CCC22100L)./real(CCC22100L));
%%
%C12
CCZ12100L = 1./C12100H(1).*(1+((C12100H(1)-C121000(1))./C121000(1))./fw100L);
CCC12100L = 1./CCZ12100L;
Q1C12100L = abs(imag(CCC12100L)./real(CCC12100L));
%%
%C66
CCZ66100L = 1./C66100H(1).*(1+((C66100H(1)-C661000(1))./C661000(1))./fw100L);
CCC66100L = 1./CCZ66100L;
Q1C66100L = abs(imag(CCC66100L)./real(CCC66100L));
%%
%C45
CCC45100L = C45100H(1)./(1+((C45100H(1)-C451000(1))./C451000(1))./fw100L);
Q1C45100L = abs(imag(CCC45100L)./real(CCC45100L));
%%
%C45S
CCC45100SL = C45100SH(1)./(1+((C45100SH(1)-C45100S0(1))./C45100S0(1))./fw100L);
Q1C45100SL = abs(imag(CCC45100SL)./real(CCC45100SL));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX10001L = ((CCC11100L-CCC66100L).*sin(RAD100(1)).^2-(CCC22100L-CCC66100L).*cos(RAD100(1)).^2).^2+(CCC12100L+CCC66100L).^2.*sin(2.*RAD100(1));
MPX10002L = ((CCC11100L-CCC66100L).*sin(RAD100(2)).^2-(CCC22100L-CCC66100L).*cos(RAD100(2)).^2).^2+(CCC12100L+CCC66100L).^2.*sin(2.*RAD100(2));
MPX10003L = ((CCC11100L-CCC66100L).*sin(RAD100(3)).^2-(CCC22100L-CCC66100L).*cos(RAD100(3)).^2).^2+(CCC12100L+CCC66100L).^2.*sin(2.*RAD100(3));

%P-wave velocity
VpX10001L = (CCC11100L.*sin(RAD100(1)).^2+CCC22100L.*cos(RAD100(1)).^2+CCC66100L+sqrt(MPX10001L)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX10002L = (CCC11100L.*sin(RAD100(2)).^2+CCC22100L.*cos(RAD100(2)).^2+CCC66100L+sqrt(MPX10002L)).^(1/2).*(2.*rhoR).^(-1/2);
VpX10002L = sqrt(CCC45100L./2./rhoR);
VpX10003L = (CCC11100L.*sin(RAD100(3)).^2+CCC22100L.*cos(RAD100(3)).^2+CCC66100L+sqrt(MPX10003L)).^(1/2).*(2.*rhoR).^(-1/2);
Vp10001L = real(1./VpX10001L).^(-1);
Qp10001L = abs(imag(VpX10001L.^2)./real(VpX10001L.^2));
Vp10002L = real(1./VpX10002L).^(-1);
Qp10002L = abs(imag(VpX10002L.^2)./real(VpX10002L.^2));
Vp10003L = real(1./VpX10003L).^(-1);
Qp10003L = abs(imag(VpX10003L.^2)./real(VpX10003L.^2));
%%
%Anisotropy
epxl100L = (Vp10003L.^2-Vp10001L.^2)./(2.*Vp10001L.^2);
deltaV100L = 4.*(Vp10002L./Vp10001L-1)-(Vp10003L./Vp10001L-1);
%S-wave velocity
VsX10001L = (CCC11100L.*sin(RAD100(1)).^2+CCC22100L.*cos(RAD100(1)).^2+CCC66100L-sqrt(MPX10001L)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX10002L = (CCC11100L.*sin(RAD100(2)).^2+CCC22100L.*cos(RAD100(2)).^2+CCC66100L-sqrt(MPX10002L)).^(1/2).*(2.*rhoR).^(-1/2);
VsX10002L = sqrt(CCC45100SL./2./rhoR);
VsX10003L = (CCC11100L.*sin(RAD100(3)).^2+CCC22100L.*cos(RAD100(3)).^2+CCC66100L-sqrt(MPX10003L)).^(1/2).*(2.*rhoR).^(-1/2);
Vs10001L = real(1./VsX10001L).^(-1);
Qs10001L = abs(imag(VsX10001L.^2)./real(VsX10001L.^2));
Vs10002L = real(1./VsX10002L).^(-1);
Qs10002L = abs(imag(VsX10002L.^2)./real(VsX10002L.^2));
Vs10003L = real(1./VsX10003L).^(-1);
Qs10003L = abs(imag(VsX10003L.^2)./real(VsX10003L.^2));

%%
%Medial Pressure
cita100M = (C22100H(4)-C221000(4)).^3./(2.*C22100H(4).*C221000(4).^2.*T100.*G100.^2);
tao100M = ((C22100H(4)-C221000(4))./C221000(4)./G100).^2;
%%
fw100M = (1-cita100M+cita100M.*sqrt(1-sqrt(-1).*OMI.*tao100M./cita100M.^2));
%C11
CCZ11100M = 1./C11100H(4).*(1+((C11100H(4)-C111000(4))./C111000(4))./fw100M);
CCC11100M = 1./CCZ11100M;
Q1C11100M = abs(imag(CCC11100M)./real(CCC11100M));
%%
%C22
CCZ22100M = 1./C22100H(4).*(1+((C22100H(4)-C221000(4))./C221000(4))./fw100M);
CCC22100M = 1./CCZ22100M;
Q1C22100M = abs(imag(CCC22100M)./real(CCC22100M));
%%
%C12
CCZ12100M = 1./C12100H(4).*(1+((C12100H(4)-C121000(4))./C121000(4))./fw100M);
CCC12100M = 1./CCZ12100M;
Q1C12100M = abs(imag(CCC12100M)./real(CCC12100M));
%%
%C66
CCZ66100M = 1./C66100H(4).*(1+((C66100H(4)-C661000(4))./C661000(4))./fw100M);
CCC66100M = 1./CCZ66100M;
Q1C66100M = abs(imag(CCC66100M)./real(CCC66100M));
%%
%C45
CCC45100M = C45100H(4)./(1+((C45100H(4)-C451000(4))./C451000(4))./fw100M);
Q1C45100M = abs(imag(CCC45100M)./real(CCC45100M));
%%
%C45S
CCC45100SM = C45100SH(4)./(1+((C45100SH(4)-C45100S0(4))./C45100S0(4))./fw100M);
Q1C45100SM = abs(imag(CCC45100SM)./real(CCC45100SM));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX10001M = ((CCC11100M-CCC66100M).*sin(RAD100(1)).^2-(CCC22100M-CCC66100M).*cos(RAD100(1)).^2).^2+(CCC12100M+CCC66100M).^2.*sin(2.*RAD100(1));
MPX10002M = ((CCC11100M-CCC66100M).*sin(RAD100(2)).^2-(CCC22100M-CCC66100M).*cos(RAD100(2)).^2).^2+(CCC12100M+CCC66100M).^2.*sin(2.*RAD100(2));
MPX10003M = ((CCC11100M-CCC66100M).*sin(RAD100(3)).^2-(CCC22100M-CCC66100M).*cos(RAD100(3)).^2).^2+(CCC12100M+CCC66100M).^2.*sin(2.*RAD100(3));

%P-wave velocity
VpX10001M = (CCC11100M.*sin(RAD100(1)).^2+CCC22100M.*cos(RAD100(1)).^2+CCC66100M+sqrt(MPX10001M)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX10002M = (CCC11100M.*sin(RAD100(2)).^2+CCC22100M.*cos(RAD100(2)).^2+CCC66100M+sqrt(MPX10002M)).^(1/2).*(2.*rhoR).^(-1/2);
VpX10002M = sqrt(CCC45100M./2./rhoR);
VpX10003M = (CCC11100M.*sin(RAD100(3)).^2+CCC22100M.*cos(RAD100(3)).^2+CCC66100M+sqrt(MPX10003M)).^(1/2).*(2.*rhoR).^(-1/2);
Vp10001M = real(1./VpX10001M).^(-1);
Qp10001M = abs(imag(VpX10001M.^2)./real(VpX10001M.^2));
Vp10002M = real(1./VpX10002M).^(-1);
Qp10002M = abs(imag(VpX10002M.^2)./real(VpX10002M.^2));
Vp10003M = real(1./VpX10003M).^(-1);
Qp10003M = abs(imag(VpX10003M.^2)./real(VpX10003M.^2));
%%
%Anisotropy
epxl100M = (Vp10003M.^2-Vp10001M.^2)./(2.*Vp10001M.^2);
deltaV100M = 4.*(Vp10002M./Vp10001M-1)-(Vp10003M./Vp10001M-1);
%S-wave velocity
VsX10001M = (CCC11100M.*sin(RAD100(1)).^2+CCC22100M.*cos(RAD100(1)).^2+CCC66100M-sqrt(MPX10001M)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX10002M = (CCC11100M.*sin(RAD100(2)).^2+CCC22100M.*cos(RAD100(2)).^2+CCC66100M-sqrt(MPX10002M)).^(1/2).*(2.*rhoR).^(-1/2);
VsX10002M = sqrt(CCC45100SM./2./rhoR);
VsX10003M = (CCC11100M.*sin(RAD100(3)).^2+CCC22100M.*cos(RAD100(3)).^2+CCC66100M-sqrt(MPX10003M)).^(1/2).*(2.*rhoR).^(-1/2);
Vs10001M = real(1./VsX10001M).^(-1);
Qs10001M = abs(imag(VsX10001M.^2)./real(VsX10001M.^2));
Vs10002M = real(1./VsX10002M).^(-1);
Qs10002M = abs(imag(VsX10002M.^2)./real(VsX10002M.^2));
Vs10003M = real(1./VsX10003M).^(-1);
Qs10003M = abs(imag(VsX10003M.^2)./real(VsX10003M.^2));
%%
%High Pressure
cita100H = (C22100H(8)-C221000(8)).^3./(2.*C22100H(8).*C221000(8).^2.*T100.*G100.^2);
tao100H = ((C22100H(8)-C221000(8))./C221000(8)./G100).^2;
%%
fw100H = (1-cita100H+cita100H.*sqrt(1-sqrt(-1).*OMI.*tao100H./cita100H.^2));
%C11
CCZ11100H = 1./C11100H(8).*(1+((C11100H(8)-C111000(8))./C111000(8))./fw100H);
CCC11100H = 1./CCZ11100H;
Q1C11100H = abs(imag(CCC11100H)./real(CCC11100H));
%%
%C22
CCZ22100H = 1./C22100H(8).*(1+((C22100H(8)-C221000(8))./C221000(8))./fw100H);
CCC22100H = 1./CCZ22100H;
Q1C22100H = abs(imag(CCC22100H)./real(CCC22100H));
%%
%C12
CCZ12100H = 1./C12100H(8).*(1+((C12100H(8)-C121000(8))./C121000(8))./fw100H);
CCC12100H = 1./CCZ12100H;
Q1C12100H = abs(imag(CCC12100H)./real(CCC12100H));
%%
%C66
CCZ66100H = 1./C66100H(8).*(1+((C66100H(8)-C661000(8))./C661000(8))./fw100H);
CCC66100H = 1./CCZ66100H;
Q1C66100H = abs(imag(CCC66100H)./real(CCC66100H));
%%
%C45
CCC45100H = C45100H(8)./(1+((C45100H(8)-C451000(8))./C451000(8))./fw100H);
Q1C45100H = abs(imag(CCC45100H)./real(CCC45100H));
%%
%C45S
CCC45100SH = C45100SH(8)./(1+((C45100SH(8)-C45100S0(8))./C45100S0(8))./fw100H);
Q1C45100SH = abs(imag(CCC45100SH)./real(CCC45100SH));
%%
%Calculate the P-wave and S-wave velocity in low pressure
MPX10001H = ((CCC11100H-CCC66100H).*sin(RAD100(1)).^2-(CCC22100H-CCC66100H).*cos(RAD100(1)).^2).^2+(CCC12100H+CCC66100H).^2.*sin(2.*RAD100(1));
MPX10002H = ((CCC11100H-CCC66100H).*sin(RAD100(2)).^2-(CCC22100H-CCC66100H).*cos(RAD100(2)).^2).^2+(CCC12100H+CCC66100H).^2.*sin(2.*RAD100(2));
MPX10003H = ((CCC11100H-CCC66100H).*sin(RAD100(3)).^2-(CCC22100H-CCC66100H).*cos(RAD100(3)).^2).^2+(CCC12100H+CCC66100H).^2.*sin(2.*RAD100(3));

%P-wave velocity
VpX10001H = (CCC11100H.*sin(RAD100(1)).^2+CCC22100H.*cos(RAD100(1)).^2+CCC66100H+sqrt(MPX10001H)).^(1/2).*(2.*rhoR).^(-1/2);
% VpX10002H = (CCC11100H.*sin(RAD100(2)).^2+CCC22100H.*cos(RAD100(2)).^2+CCC66100H+sqrt(MPX10002H)).^(1/2).*(2.*rhoR).^(-1/2);
VpX10002H = sqrt(CCC45100H./2./rhoR);
VpX10003H = (CCC11100H.*sin(RAD100(3)).^2+CCC22100H.*cos(RAD100(3)).^2+CCC66100H+sqrt(MPX10003H)).^(1/2).*(2.*rhoR).^(-1/2);
Vp10001H = real(1./VpX10001H).^(-1);
Qp10001H = abs(imag(VpX10001H.^2)./real(VpX10001H.^2));
Vp10002H = real(1./VpX10002H).^(-1);
Qp10002H = abs(imag(VpX10002H.^2)./real(VpX10002H.^2));
Vp10003H = real(1./VpX10003H).^(-1);
Qp10003H = abs(imag(VpX10003H.^2)./real(VpX10003H.^2));
%%
%Anisotropy
epxl100H = (Vp10003H.^2-Vp10001H.^2)./(2.*Vp10001H.^2);
deltaV100H = 4.*(Vp10002H./Vp10001H-1)-(Vp10003H./Vp10001H-1);
%S-wave velocity
VsX10001H = (CCC11100H.*sin(RAD100(1)).^2+CCC22100H.*cos(RAD100(1)).^2+CCC66100H-sqrt(MPX10001H)).^(1/2).*(2.*rhoR).^(-1/2);
%VsX10002H = (CCC11100H.*sin(RAD100(2)).^2+CCC22100H.*cos(RAD100(2)).^2+CCC66100H-sqrt(MPX10002H)).^(1/2).*(2.*rhoR).^(-1/2);
VsX10002H = sqrt(CCC45100SH./2./rhoR);
VsX10003H = (CCC11100H.*sin(RAD100(3)).^2+CCC22100H.*cos(RAD100(3)).^2+CCC66100H-sqrt(MPX10003H)).^(1/2).*(2.*rhoR).^(-1/2);
Vs10001H = real(1./VsX10001H).^(-1);
Qs10001H = abs(imag(VsX10001H.^2)./real(VsX10001H.^2));
Vs10002H = real(1./VsX10002H).^(-1);
Qs10002H = abs(imag(VsX10002H.^2)./real(VsX10002H.^2));
Vs10003H = real(1./VsX10003H).^(-1);
Qs10003H = abs(imag(VsX10003H.^2)./real(VsX10003H.^2));
%%
%Autocorrelation length = 100um
ZCRACK100C = eQ./STCRACK100; 
deltaN100C = CdrQ.*ZCRACK100C./(1+CdrQ.*ZCRACK100C);
ZCRACK100SC = ZCRACK100C./(1+Kf.*deltaN100C./(CQ.*phic.*(1-deltaN100C)).*(1-Kf./KdQ).^(-1));
C22100HC = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK100SC))./(3.*(4.*pi+9.*KQBH.*ZCRACK100SC));
C10001C = 4.*(4.*mudrQ.*pi+3.*KdrQ.*(pi+3.*mudrQ.*ZCRACK100C))./3./(4.*pi+9.*KdrQ.*ZCRACK100C);
KX100C = 4.*KdrQ.*pi./(4.*pi+9.*KdrQ.*ZCRACK100C);
MX100C = KdQ./((1-KX100C./KdQ)-phi.*(1-KdQ./Kf));
a1100C = (4.*pi.*KdQ-4.*pi.*KdrQ+9.*KdrQ.*KdQ.*ZCRACK100C)./(KdQ.*(4.*pi+9.*KdrQ.*ZCRACK100C));
C1000C = C10001C+a1100C.^2.*MX100C;
G100C = 2.*pi.*eQ./a.*(C1-arf.*MQ).^2.*sqrt(kappa./(yita.*C1.*MQ.*CdrQ));
T100C = 2.*(C1-arf.*MQ).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
cita100CL = (C22100HC(1)-C1000C(1)).^3./(2.*C22100HC(1).*C1000C(1).^2.*T100C.*G100C.^2);
tao100CL = ((C22100HC(1)-C1000C(1))./C1000C(1)./G100C).^2;
CCZ100CL = 1./C22100HC(1).*(1+((C22100HC(1)-C1000C(1))./C1000C(1))./(1-cita100CL+cita100CL.*sqrt(1-sqrt(-1).*OMI.*tao100CL./cita100CL.^2)));
CCC100CL = 1./CCZ100CL;
Q1C100CL = abs(imag(CCC100CL)./real(CCC100CL));
%%
%Plot the figure
figure(1)
plot(STPRE001,C22001)
hold on
plot(STPRE010,C22010)
hold on
plot(STPRE020,C22020)
hold on
plot(STPRE050,C22050)
hold on
plot(STPRE100,C22100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
figure(11)
plot(STPRE001,CC22001)
hold on
plot(STPRE010,CC22010)
hold on
plot(STPRE020,CC22020)
hold on
plot(STPRE050,CC22050)
hold on
plot(STPRE100,CC22100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
figure(201)
plot(STPRE001,C44001)
hold on
plot(STPRE010,C44010)
hold on
plot(STPRE020,C44020)
hold on
plot(STPRE050,C44050)
hold on
plot(STPRE100,C44100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%Caculate the third-order elastic constant
%Do linear fitting
PREEX = (1:0.1:15);%The Pressure for simulation
%Autocorrelation length = 1 um
TOE001 = polyfit(STPRE001,C22001,1);
C22001TO = polyval(TOE001,PREEX);
%Autocorrelation length = 10 um
TOE010 = polyfit(STPRE010,C22010,1);
C22010TO = polyval(TOE010,PREEX);
%Autocorrelation length = 20 um
TOE020 = polyfit(STPRE020,C22020,1);
C22020TO = polyval(TOE020,PREEX);
%Autocorrelation length = 50 um
TOE050 = polyfit(STPRE050,C22050,1);
C22050TO = polyval(TOE050,PREEX);
%Autocorrelation length = 100 um
TOE100 = polyfit(STPRE100,C22100,1);
C22100TO = polyval(TOE100,PREEX);
%%
%S-wave-Axial
%Autocorrelation length = 1 um
TOES001 = polyfit(STPRE001,C44001,1);
C44001TO = polyval(TOES001,PREEX);
%Autocorrelation length = 10 um
TOES010 = polyfit(STPRE010,C44010,1);
C44010TO = polyval(TOES010,PREEX);
%Autocorrelation length = 20 um
TOES020 = polyfit(STPRE020,C44020,1);
C44020TO = polyval(TOES020,PREEX);
%Autocorrelation length = 50 um
TOES050 = polyfit(STPRE050,C44050,1);
C44050TO = polyval(TOES050,PREEX);
%Autocorrelation length = 100 um
TOES100 = polyfit(STPRE100,C44100,1);
C44100TO = polyval(TOES100,PREEX);
%%
%Confining pressure
%Do linear fitting
%Autocorrelation length = 1 um
TOE001C = polyfit(STPRE001,CC22001,1);
C22001TOC = polyval(TOE001C,PREEX);
%Autocorrelation length = 10 um
TOE010C = polyfit(STPRE010,CC22010,1);
C22010TOC = polyval(TOE010C,PREEX);
%Autocorrelation length = 20 um
TOE020C = polyfit(STPRE020,CC22020,1);
C22020TOC = polyval(TOE020C,PREEX);
%Autocorrelation length = 50 um
TOE050C = polyfit(STPRE050,CC22050,1);
C22050TOC = polyval(TOE050C,PREEX);
%Autocorrelation length = 100 um
TOE100C = polyfit(STPRE100,CC22100,1);
C22100TOC = polyval(TOE100C,PREEX);
%%
%plot the Figure
figure(2)
plot(PREEX,C22001TO)
hold on
plot(PREEX,C22010TO)
hold on
plot(PREEX,C22020TO)
hold on
plot(PREEX,C22050TO)
hold on
plot(PREEX,C22100TO)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%plot the Figure
figure(21)
plot(PREEX,C22001TOC)
hold on
plot(PREEX,C22010TOC)
hold on
plot(PREEX,C22020TOC)
hold on
plot(PREEX,C22050TOC)
hold on
plot(PREEX,C22100TOC)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
figure(202)
plot(PREEX,C44001TO)
hold on
plot(PREEX,C44010TO)
hold on
plot(PREEX,C44020TO)
hold on
plot(PREEX,C44050TO)
hold on
plot(PREEX,C44100TO)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%Halite
KdH = 24.8;%Bulk modulus
mudH = 14.9;%Shear modulus
eH = 0.001;%Crack density
%Autocorrelation length = 01 um
STCRACKYY001 = [0.00079251	0.000931332	0.004120363	0.007793148	0.020579987	0.038499424	0.051049309	0.06419595];
STPREYY001 = [0	0.202737285	0.355327594	0.931704087	1.630869606	3.365054813	5.46356364	8.213693503];
C22YY001 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY001+4.*mudH.*eH./STCRACKYY001);
CC22YY001 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY001))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY001));
ZCRACKYY001 = eH./STCRACKYY001;
C44YY001 = mudH./(1+mudH.*ZCRACKYY001);%The shear modulus
%Autocorrelation length = 10 um
STCRACKYY010 = [0.005469845	0.015377379	0.02303006	0.031004413	0.041231686	0.055593398	0.062841233	0.072040536];
STPREYY010 = [0	0.356415558	1.151989885	2.333955441	3.515672137	5.096625839	6.552226966	8.187464377];
C22YY010 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY010+4.*mudH.*eH./STCRACKYY010);
CC22YY010 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY010))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY010));
ZCRACKYY010 = eH./STCRACKYY010;
C44YY010 = mudH./(1+mudH.*ZCRACKYY010);%The shear modulus
%Autocorrelation length = 20 um
STCRACKYY020 =[0.00846169	0.0200158	0.027861821	0.035602755	0.041007088	0.046395757	0.051646188	0.057789789];
STPREYY020 = [0	0.556028013	1.590818916	2.995307749	4.307608278	5.780010667	6.870309792	8.073653803];
C22YY020 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY020+4.*mudH.*eH./STCRACKYY020);
CC22YY020 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY020))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY020));
ZCRACKYY020 = eH./STCRACKYY020;
C44YY020 = mudH./(1+mudH.*ZCRACKYY020);%The shear modulus
%Autocorrelation length = 50 um
STCRACKYY050 = [0.011195278	0.023972153	0.032299883	0.039735595	0.044594887	0.050018095	0.053076109	0.056905667];
STPREYY050 = [0	0.739579318	1.984545642	3.621491968	5.092293829	6.698810821	7.876329835	9.102209186];
C22YY050 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY050+4.*mudH.*eH./STCRACKYY050);
CC22YY050 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY050))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY050));
ZCRACKYY050 = eH./STCRACKYY050;
C44YY050 = mudH./(1+mudH.*ZCRACKYY050);%The shear modulus
%Autocorrelation length 100 um
STCRACKYY100 = [0.012098863	0.028967392	0.03912266	0.04728462	0.052366583	0.058368551	0.063901518	0.069749457];
STPREYY100 = [0	0.641507466	1.870219591	3.501215296	4.951223978	6.520227688	7.669820925	8.920581553];
C22YY100 = (3.*KdH+4.*mudH)./(3+3.*KdH.*eH./STCRACKYY100+4.*mudH.*eH./STCRACKYY100);
CC22YY100 = (4.*mudH+3.*KdH.*(1+3./pi.*eH.*mudH./STCRACKYY100))./3./(1+9./4./pi.*(eH.*KdH./STCRACKYY100));
ZCRACKYY100 = eH./STCRACKYY100;
C44YY100 = mudH./(1+mudH.*ZCRACKYY100);%The shear modulus
%%
%Plot stiffness
figure(3)
plot(STPREYY001,C22YY001)
hold on
plot(STPREYY010,C22YY010)
hold on
plot(STPREYY020,C22YY020)
hold on
plot(STPREYY050,C22YY050)
hold on
plot(STPREYY100,C22YY100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%Plot stiffness
figure(31)
plot(STPREYY001,CC22YY001)
hold on
plot(STPREYY010,CC22YY010)
hold on
plot(STPREYY020,CC22YY020)
hold on
plot(STPREYY050,CC22YY050)
hold on
plot(STPREYY100,CC22YY100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
figure(203)
plot(STPREYY001,C44YY001)
hold on
plot(STPREYY010,C44YY010)
hold on
plot(STPREYY020,C44YY020)
hold on
plot(STPREYY050,C44YY050)
hold on
plot(STPREYY100,C44YY100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%Caculate the third-order elastic constant
%Do linear fitting Yanyan
PREEXYY = (1:0.1:8);%The Pressure for simulation
%Autocorrelation length = 1 um
TOEYY001 = polyfit(STPREYY001,C22YY001,1);
STFYY001TO = polyval(TOEYY001,PREEXYY);
%Autocorrelation length = 10 um
TOEYY010 = polyfit(STPREYY010,C22YY010,1);
STFYY010TO = polyval(TOEYY010,PREEXYY);
%Autocorrelation length = 20 um
TOEYY020 = polyfit(STPREYY020,C22YY020,1);
STFYY020TO = polyval(TOEYY020,PREEXYY);
%Autocorrelation length = 50 um
TOEYY050 = polyfit(STPREYY050,C22YY050,1);
STFYY050TO = polyval(TOEYY050,PREEXYY);
%Autocorrelation length = 100 um
TOEYY100 = polyfit(STPREYY100,C22YY100,1);
STFYY100TO = polyval(TOEYY100,PREEXYY);
%%
%Shear
%Autocorrelation length = 1 um
TOEYYS001 = polyfit(STPREYY001,C44YY001,1);
STFYYS001TO = polyval(TOEYYS001,PREEXYY);
%Autocorrelation length = 10 um
TOEYYS010 = polyfit(STPREYY010,C44YY010,1);
STFYYS010TO = polyval(TOEYYS010,PREEXYY);
%Autocorrelation length = 20 um
TOEYYS020 = polyfit(STPREYY020,C44YY020,1);
STFYYS020TO = polyval(TOEYYS020,PREEXYY);
%Autocorrelation length = 50 um
TOEYYS050 = polyfit(STPREYY050,C44YY050,1);
STFYYS050TO = polyval(TOEYYS050,PREEXYY);
%Autocorrelation length = 100 um
TOEYYS100 = polyfit(STPREYY100,C44YY100,1);
STFYYS100TO = polyval(TOEYYS100,PREEXYY);
%%
%Confining pressure
%Autocorrelation length = 1 um
TOEYY001C = polyfit(STPREYY001,CC22YY001,1);
STFYY001TOC = polyval(TOEYY001C,PREEXYY);
%Autocorrelation length = 10 um
TOEYY010C = polyfit(STPREYY010,CC22YY010,1);
STFYY010TOC = polyval(TOEYY010C,PREEXYY);
%Autocorrelation length = 20 um
TOEYY020C = polyfit(STPREYY020,CC22YY020,1);
STFYY020TOC = polyval(TOEYY020C,PREEXYY);
%Autocorrelation length = 50 um
TOEYY050C = polyfit(STPREYY050,CC22YY050,1);
STFYY050TOC = polyval(TOEYY050C,PREEXYY);
%Autocorrelation length = 100 um
TOEYY100C = polyfit(STPREYY100,CC22YY100,1);
STFYY100TOC = polyval(TOEYY100C,PREEXYY);
%%
%plot the Figure
figure(4)
plot(PREEXYY,STFYY001TO)
hold on
plot(PREEXYY,STFYY010TO)
hold on
plot(PREEXYY,STFYY020TO)
hold on
plot(PREEXYY,STFYY050TO)
hold on
plot(PREEXYY,STFYY100TO)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%plot the Figure
figure(41)
plot(PREEXYY,STFYY001TOC)
hold on
plot(PREEXYY,STFYY010TOC)
hold on
plot(PREEXYY,STFYY020TOC)
hold on
plot(PREEXYY,STFYY050TOC)
hold on
plot(PREEXYY,STFYY100TOC)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
figure(204)
plot(PREEXYY,STFYYS001TO)
hold on
plot(PREEXYY,STFYYS010TO)
hold on
plot(PREEXYY,STFYYS020TO)
hold on
plot(PREEXYY,STFYYS050TO)
hold on
plot(PREEXYY,STFYYS100TO)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%deal with the third-order elastic constant
AUTOL = [1 10 20 50 100];%Autocorrelation length
TOEQA = 1000.*[TOE001(1) TOE010(1) TOE020(1) TOE050(1) TOE100(1)];%Third-order elastic constant for quartz for axial stress
TOEQC = 1000.*[TOE001C(1) TOE010C(1) TOE020C(1) TOE050C(1) TOE100C(1)];%Third-order elastic constant for quartz for confining stress
TOEYYA = 1000.*[TOEYY001(1) TOEYY010(1) TOEYY020(1) TOEYY050(1) TOEYY100(1)];%Third-order elastic constant for Yanyan for axial stress
TOEYYC = 1000.*[TOEYY001C(1) TOEYY010C(1) TOEYY020C(1) TOEYY050C(1) TOEYY100C(1)];%Third-order elastic constant for Yanyan for confining stress
%%
TOEQAS = 1000.*[TOES001(1) TOES010(1) TOES020(1) TOES050(1) TOES100(1)];%Third-order elastic constant for quartz for axial stres
TOEYYAS = 1000.*[TOEYYS001(1) TOEYYS010(1) TOEYYS020(1) TOEYYS050(1) TOEYYS100(1)];%Third-order elastic constant for Yanyan for axial stress
%%
figure(5)
plot(AUTOL,TOEQA)
hold on
plot(AUTOL,TOEYYA)
legend('Quartz','Yanyan')
xlabel('Autocorrelation length (um)')
ylabel('Third-order elastic constant')
figure(6)
plot(AUTOL,TOEQC)
hold on
plot(AUTOL,TOEYYC)
legend('Quartz','Yanyan')
xlabel('Autocorrelation length (um)')
ylabel('Third-order elastic constant')
%%
figure(205)
plot(AUTOL,TOEQAS)
hold on
plot(AUTOL,TOEYYAS)
legend('Quartz','Yanyan')
xlabel('Autocorrelation length (um)')
ylabel('Third-order elastic constant')
%%
%All the things will be modified
% %%
% %to deal with dissipation
% figure(100)
% plot(log10(k2a),CCC22001L)
% hold on
% plot(log10(k2a),CCC010L)
% hold on
% plot(log10(k2a),CCC020L)
% hold on
% plot(log10(k2a),CCC050L)
% hold on
% plot(log10(k2a),CCC100L)
% legend('Auto lngth = 1um','Auto lngth = 10um','Auto lngth = 20um','Auto lngth = 50um','Auto lngth = 100um')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %%
% %to deal with dissipation
% figure(101)
% plot(log10(k2a),CCC001CL)
% hold on
% plot(log10(k2a),CCC010CL)
% hold on
% plot(log10(k2a),CCC020CL)
% hold on
% plot(log10(k2a),CCC050CL)
% hold on
% plot(log10(k2a),CCC100CL)
% legend('Auto lngth = 1um','Auto lngth = 10um','Auto lngth = 20um','Auto lngth = 50um','Auto lngth = 100um')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %%
% %to deal with attenuation
% figure(102)
% plot(log10(k2a),log10(Q1C22001L))
% hold on
% plot(log10(k2a),log10(Q1C010L))
% hold on
% plot(log10(k2a),log10(Q1C020L))
% hold on
% plot(log10(k2a),log10(Q1C050L))
% hold on
% plot(log10(k2a),log10(Q1C100L))
% legend('Auto lngth = 1um','Auto lngth = 10um','Auto lngth = 20um','Auto lngth = 50um','Auto lngth = 100um')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %%
% %to deal with attenuation
% figure(103)
% plot(log10(k2a),log10(Q1C001CL))
% hold on
% plot(log10(k2a),log10(Q1C010CL))
% hold on
% plot(log10(k2a),log10(Q1C020CL))
% hold on
% plot(log10(k2a),log10(Q1C050CL))
% hold on
% plot(log10(k2a),log10(Q1C100CL))
% legend('Auto lngth = 1um','Auto lngth = 10um','Auto lngth = 20um','Auto lngth = 50um','Auto lngth = 100um')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %
% figure(104)
% plot(log10(k2a),CCC22001L)
% hold on
% plot(log10(k2a),CCC001M)
% hold on
% plot(log10(k2a),CCC001H)
% legend('Auto lngth = 1um Low pressure','Auto lngth = 1um Medal pressure','Auto lngth = 1um High pressure')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %
% figure(105)
% plot(log10(k2a),log10(Q1C22001L))
% hold on
% plot(log10(k2a),log10(Q1C001M))
% hold on
% plot(log10(k2a),log10(Q1C001H))
% legend('Auto lngth = 1um Low pressure','Auto lngth = 1um Medal pressure','Auto lngth = 1um High pressure')
% xlabel('Frequency (Log(k2a))')
% ylabel('Attenuation')
% %
% figure(106)
% plot(log10(k2a),CCC001CL)
% hold on
% plot(log10(k2a),CCC001CM)
% hold on
% plot(log10(k2a),CCC001CH)
% legend('Auto lngth = 1um Low pressure','Auto lngth = 1um Medal pressure','Auto lngth = 1um High pressure')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
% %
% figure(107)
% plot(log10(k2a),log10(Q1C001CL))
% hold on
% plot(log10(k2a),log10(Q1C001CM))
% hold on
% plot(log10(k2a),log10(Q1C001CH))
% legend('Auto lngth = 1um Low pressure','Auto lngth = 1um Medal pressure','Auto lngth = 1um High pressure')
% xlabel('Frequency (Log(k2a))')
% ylabel('Attenuation')
% %%
% %
% figure(301)
% plot(log10(k2a),CCC11001L)
% hold on
% plot(log10(k2a),CCC22001L)
% hold on
% plot(log10(k2a),CCC66001L)
% hold on
% plot(log10(k2a),HHB)
% legend('C11','C22','C66')
% xlabel('Frequency (Log(k2a))')
% ylabel('Elastic Modulus (GPa)')
%%
figure(101)
plot(log10(k2a),real(CCC11001L))
hold on
plot(log10(k2a),real(CCC22001L))
hold on
plot(log10(k2a),real(CCC66001L))
legend('C11','C22','C66')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
figure(102)
plot(log10(k2a),real(CCC11001M))
hold on
plot(log10(k2a),real(CCC22001M))
hold on
plot(log10(k2a),real(CCC66001M))
legend('C11','C22','C66')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
figure(103)
plot(log10(k2a),real(CCC11001H))
hold on
plot(log10(k2a),real(CCC22001H))
hold on
plot(log10(k2a),real(CCC66001H))
legend('C11','C22','C66')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
figure(104)
plot(log10(k2a),real(CCC11001L))
hold on
plot(log10(k2a),real(CCC11001M))
hold on
plot(log10(k2a),real(CCC11001H))
legend('C11L','C11M','C11H')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
figure(105)
plot(log10(k2a),real(CCC22001L))
hold on
plot(log10(k2a),real(CCC22001M))
hold on
plot(log10(k2a),real(CCC22001H))
legend('C22L','C22M','C22H')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
figure(106)
plot(log10(k2a),real(CCC66001L))
hold on
plot(log10(k2a),real(CCC66001M))
hold on
plot(log10(k2a),real(CCC66001H))
legend('C22L','C22M','C22H')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
%%
%Attenuation
figure(107)
plot(log10(k2a),log10(Q1C11001L))
hold on
plot(log10(k2a),log10(Q1C22001L))
hold on
plot(log10(k2a),log10(Q1C66001L))
legend('C11','C22','C66')
xlabel('Frequency (Log(k2a))')
ylabel('Attenuation')
%
figure(108)
plot(log10(k2a),log10(Q1C11001M))
hold on
plot(log10(k2a),log10(Q1C22001M))
hold on
plot(log10(k2a),log10(Q1C66001M))
legend('C11','C22','C66')
xlabel('Frequency (Log(k2a))')
ylabel('Attenuation')
%
figure(109)
plot(log10(k2a),log10(Q1C11001H))
hold on
plot(log10(k2a),log10(Q1C22001H))
hold on
plot(log10(k2a),log10(Q1C66001H))
legend('C11','C22','C66')
xlabel('Frequency (Log(k2a))')
ylabel('Attenuation')
%%
%plot Velocity
figure(110)
plot(log10(k2a),Vp10001L)
hold on
plot(log10(k2a),Vp10002L)
hold on
plot(log10(k2a),Vp10003L)
legend('0','pi/4','pi/2')
xlabel('Frequency (Log(k2a))')
ylabel('Velocity')
figure(111)
plot(log10(k2a),log10(Qp10001H))
hold on
plot(log10(k2a),log10(Qp10002H))
hold on
plot(log10(k2a),log10(Qp10003H))
legend('0','pi/4','pi/2')
xlabel('Frequency (Log(k2a))')
ylabel('Attenuation')
%%
%Plot the variation of compliance  of the fracture
figure(112)
plot(STPRE001,ZCRACK001)
hold on
plot(STPRE010,ZCRACK010)
hold on
plot(STPRE020,ZCRACK020)
hold on
plot(STPRE050,ZCRACK050)
hold on
plot(STPRE100,ZCRACK100)
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('Pressure (MPa)')
ylabel('Compliance (GPa^-1)')
figure(113)
plot(STPRE001,C220010)
hold on
plot(STPRE010,C220100)
hold on
plot(STPRE020,C220200)
hold on
plot(STPRE050,C220500)
hold on
plot(STPRE100,C221000)
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('Pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(114)
plot(STPRE001,C660010)
hold on
plot(STPRE010,C660100)
hold on
plot(STPRE020,C660200)
hold on
plot(STPRE050,C660500)
hold on
plot(STPRE100,C661000)
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('Pressure (MPa)')
ylabel('S-wave modulus (GPa)')
figure(115)
plot(STPRE001,C22001H)
hold on
plot(STPRE010,C22010H)
hold on
plot(STPRE020,C22020H)
hold on
plot(STPRE050,C22050H)
hold on
plot(STPRE100,C22100H)
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('Pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(116)
plot(STPRE001,C66001H)
hold on
plot(STPRE010,C66010H)
hold on
plot(STPRE020,C66020H)
hold on
plot(STPRE050,C66050H)
hold on
plot(STPRE100,C66100H)
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('Pressure (MPa)')
ylabel('S-wave modulus (GPa)')
%%
%Caculate the third-order elastic constant
%Do linear fitting
%PREEX = (1:0.1:15);%The Pressure for simulation
%low frequency
%P-wave
%Autocorrelation length = 1 um
TOE0010 = polyfit(STPRE001,C220010,1);
C220010TO = polyval(TOE0010,STPRE001);
COC22001 = min(min(corrcoef(C220010, C220010TO)));
%Autocorrelation length = 10 um
TOE0100 = polyfit(STPRE010,C220100,1);
C220100TO = polyval(TOE0100,STPRE010);
COC22010 = min(min(corrcoef(C220100, C220100TO)));
%Autocorrelation length = 20 um
TOE0200 = polyfit(STPRE020,C220200,1);
C220200TO = polyval(TOE0200,STPRE020);
COC22020 = min(min(corrcoef(C220200, C220200TO)));
%Autocorrelation length = 50 um
TOE0500 = polyfit(STPRE050,C220500,1);
C220500TO = polyval(TOE0500,STPRE050);
COC22050 = min(min(corrcoef(C220500, C220500TO)));
%Autocorrelation length = 100 um
TOE1000 = polyfit(STPRE100,C221000,1);
C221000TO = polyval(TOE1000,STPRE100);
COC22100 = min(min(corrcoef(C221000, C221000TO)));
%%
%S-wave-Axial
%low frequency
%Autocorrelation length = 1 um
TOES0010 = polyfit(STPRE001,C660010,1);
C660010TO = polyval(TOES0010,STPRE001);
COC66001 = min(min(corrcoef(C660010, C660010TO)));
%Autocorrelation length = 10 um
TOES0100 = polyfit(STPRE010,C660100,1);
C660100TO = polyval(TOES0100,STPRE010);
COC66010 = min(min(corrcoef(C660100, C660100TO)));
%Autocorrelation length = 20 um
TOES0200 = polyfit(STPRE020,C660200,1);
C660200TO = polyval(TOES0200,STPRE020);
COC66020 = min(min(corrcoef(C660200, C660200TO)));
%Autocorrelation length = 50 um
TOES0500 = polyfit(STPRE050,C660500,1);
C660500TO = polyval(TOES0500,STPRE050);
COC66050 = min(min(corrcoef(C660500, C660500TO)));
%Autocorrelation length = 100 um
TOES1000 = polyfit(STPRE100,C661000,1);
C661000TO = polyval(TOES1000,STPRE100);
COC66100 = min(min(corrcoef(C661000, C661000TO)));
%%
%High frequency
%P-wave
%Autocorrelation length = 1 um
TOE001H = polyfit(STPRE001,C22001H,1);
C22001HTO = polyval(TOE001H,STPRE001);
COC22001H = min(min(corrcoef(C22001H, C22001HTO)));
%Autocorrelation length = 10 um
TOE010H = polyfit(STPRE010,C22010H,1);
C22010HTO = polyval(TOE010H,STPRE010);
COC22010H = min(min(corrcoef(C22010H, C22010HTO)));
%Autocorrelation length = 20 um
TOE020H = polyfit(STPRE020,C22020H,1);
C22020HTO = polyval(TOE020H,STPRE020);
COC22020H = min(min(corrcoef(C22020H, C22020HTO)));
%Autocorrelation length = 50 um
TOE050H = polyfit(STPRE050,C22050H,1);
C22050HTO = polyval(TOE050H,STPRE050);
COC22050H = min(min(corrcoef(C22050H, C22050HTO)));
%Autocorrelation length = 100 um
TOE100H = polyfit(STPRE100,C22100H,1);
C22100HTO = polyval(TOE100H,STPRE100);
COC22100H = min(min(corrcoef(C22100H, C22100HTO)));
%%
%S-wave-Axial
%low frequency
%Autocorrelation length = 1 um
TOES001H = polyfit(STPRE001,C66001H,1);
C66001HTO = polyval(TOES001H,STPRE001);
COC66001H = min(min(corrcoef(C66001H, C66001HTO)));
%Autocorrelation length = 10 um
TOES010H = polyfit(STPRE010,C66010H,1);
C66010HTO = polyval(TOES010H,STPRE010);
COC66010H = min(min(corrcoef(C66010H, C66010HTO)));
%Autocorrelation length = 20 um
TOES020H = polyfit(STPRE020,C66020H,1);
C66020HTO = polyval(TOES020H,STPRE020);
COC66020H = min(min(corrcoef(C66020H, C66020HTO)));
%Autocorrelation length = 50 um
TOES050H = polyfit(STPRE050,C66050H,1);
C66050HTO = polyval(TOES050H,STPRE050);
COC66050H = min(min(corrcoef(C66050H, C66050HTO)));
%Autocorrelation length = 100 um
TOES100H = polyfit(STPRE100,C66100H,1);
C66100HTO = polyval(TOES100H,STPRE100);
COC66100H = min(min(corrcoef(C66100H, C66100HTO)));
%%
AUTO = [1 10 20 50 100];%Autocorrelation length
TOELF = 1000.*[TOE0010(1) TOE0100(1) TOE0200(1) TOE0500(1) TOE1000(1)];
TOEHF = 1000.*[TOE001H(1) TOE010H(1) TOE020H(1) TOE050H(1) TOE100H(1)];
TOESLF = 1000.*[TOES0010(1) TOES0100(1) TOES0200(1) TOES0500(1) TOES1000(1)];
TOESHF = 1000.*[TOES001H(1) TOES010H(1) TOES020H(1) TOES050H(1) TOES100H(1)];
figure(117)
plot(AUTO,TOELF)
hold on
plot(AUTO,TOEHF)
legend('Low-frequency','High-frequency')
xlabel('Autocorrelation length (um)')
ylabel('Third-order elastic constants')
figure(118)
plot(AUTO,TOESLF)
hold on
plot(AUTO,TOESHF)
legend('Low-frequency','High-frequency')
xlabel('Autocorrelation length (um)')
ylabel('Third-order elastic constants')
%%
%deal with the dispersion and attenuation
figure(119)
plot(log10(k2a),real(CCC22001L))
hold on
plot(log10(k2a),real(CCC22010L))
hold on
plot(log10(k2a),real(CCC22020L))
hold on
plot(log10(k2a),real(CCC22050L))
hold on
plot(log10(k2a),real(CCC22100L))
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(120)
plot(log10(k2a),log10(Q1C22001L))
hold on
plot(log10(k2a),log10(Q1C22010L))
hold on
plot(log10(k2a),log10(Q1C22020L))
hold on
plot(log10(k2a),log10(Q1C22050L))
hold on
plot(log10(k2a),log10(Q1C22100L))
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%deal with the dispersion and attenuation
figure(121)
plot(log10(k2a),real(CCC11001L))
hold on
plot(log10(k2a),real(CCC11010L))
hold on
plot(log10(k2a),real(CCC11020L))
hold on
plot(log10(k2a),real(CCC11050L))
hold on
plot(log10(k2a),real(CCC11100L))
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(122)
plot(log10(k2a),log10(Q1C11001L))
hold on
plot(log10(k2a),log10(Q1C11010L))
hold on
plot(log10(k2a),log10(Q1C11020L))
hold on
plot(log10(k2a),log10(Q1C11050L))
hold on
plot(log10(k2a),log10(Q1C11100L))
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%deal with the dispersion and attenuation
figure(123)
plot(log10(k2a),real(CCC45001L./2))
hold on
plot(log10(k2a),real(CCC45010L./2))
hold on
plot(log10(k2a),real(CCC45020L./2))
hold on
plot(log10(k2a),real(CCC45050L./2))
hold on
plot(log10(k2a),real(CCC45100L./2))
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(124)
plot(log10(k2a),log10(Q1C45001L))
hold on
plot(log10(k2a),log10(Q1C45010L))
hold on
plot(log10(k2a),log10(Q1C45020L))
hold on
plot(log10(k2a),log10(Q1C45050L))
hold on
plot(log10(k2a),log10(Q1C45100L))
legend('Autocorrelation length = 1um','Autocorrelation length = 10um','Autocorrelation length = 20um','Autocorrelation length = 50um','Autocorrelation length = 100um')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%the attenuation and dispersion for different surface
figure(125)
plot(log10(k2a),real(CCC22001L))
hold on
plot(log10(k2a),real(CCC22001M))
hold on
plot(log10(k2a),real(CCC22001H))
legend('Low pressure','Middle pressure','High pressure')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(126)
plot(log10(k2a),log10(Q1C22001L))
hold on
plot(log10(k2a),log10(Q1C22001M))
hold on
plot(log10(k2a),log10(Q1C22001H))
legend('Low pressure','Middle pressure','High pressure')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%the attenuation and dispersion for different surface
figure(127)
plot(log10(k2a),real(CCC22050L))
hold on
plot(log10(k2a),real(CCC22050M))
hold on
plot(log10(k2a),real(CCC22050H))
legend('Low pressure','Middle pressure','High pressure')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(128)
plot(log10(k2a),log10(Q1C22050L))
hold on
plot(log10(k2a),log10(Q1C22050M))
hold on
plot(log10(k2a),log10(Q1C22050H))
legend('Low pressure','Middle pressure','High pressure')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%Anisotropy
figure(129)
plot(log10(k2a),real(epxl001L))
hold on
plot(log10(k2a),real(deltaV001L))
% hold on
% plot(log10(k2a),real(epxl020L))
% hold on
% plot(log10(k2a),real(deltaV020L))
% hold on
% plot(log10(k2a),real(epxl050L))
% hold on
% plot(log10(k2a),real(deltaV050L))
legend('eee','ddd')
xlabel('log10(k2a)')
ylabel('Anisotropy')
%%
close all
%%
%the dispersion of third-order elastic constant
%low Aut L = 1um
cita001 = (C22001H-C220010).^3./(2.*C22001H.*(C220010.^2).*T001.*(G001.^2));
tao001 = ((C22001H-C220010)./(C220010.*G001)).^2;
fw001 = zeros(length(STCRACK001),length(OMI));
CCC22001 = zeros(length(STCRACK001),length(OMI));
for i = 1:length(STCRACK001)
fw001(i,:) = (1-cita001(i)+cita001(i).*sqrt(1-I.*OMI.*tao001(i)./cita001(i).^2));
end
for i = 1:length(STCRACK001)
CCC22001(i,:) = C22001H(i)./(1+((C22001H(i)-C220010(i))./C220010(i))./fw001(i,:));
end
Q1C22001 = abs(imag(CCC22001)./real(CCC22001));
CC22001 = real(CCC22001);
TOE22001 = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22001M = polyfit(STPRE001,CC22001(:,i),1);
TOE22001(i) = 1000.*TOE22001M(1);
end
%%
%the dispersion of third-order elastic constant
%low Aut L = 10um
cita010 = (C22010H-C220100).^3./(2.*C22010H.*C220100.^2.*T010.*G010.^2);
tao010 = ((C22010H-C220100)./C220100./G010).^2;
fw010 = zeros(length(STCRACK010),length(OMI));
CCC22010 = zeros(length(STCRACK010),length(OMI));
for i = 1:length(STCRACK010)
fw010(i,:) = (1-cita010(i)+cita010(i).*sqrt(1-sqrt(-1).*OMI.*tao010(i)./cita010(i).^2));
end
for i = 1:length(STCRACK010)
CCC22010(i,:) = C22010H(i)./(1+((C22010H(i)-C220100(i))./C220100(i))./fw010(i,:));
end
Q1C22010 = abs(imag(CCC22010)./real(CCC22010));
CC22010 = real(CCC22010);
TOE22010 = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22010M = polyfit(STPRE010,CC22010(:,i),1);
TOE22010(i) = 1000.*TOE22010M(1);
end
%%
%the dispersion of third-order elastic constant
%low Aut L = 20um
cita020 = (C22020H-C220200).^3./(2.*C22020H.*C220200.^2.*T020.*G020.^2);
tao020 = ((C22020H-C220200)./C220200./G020).^2;
fw020 = zeros(length(STCRACK020),length(OMI));
CCC22020 = zeros(length(STCRACK020),length(OMI));
for i = 1:length(STCRACK020)
fw020(i,:) = (1-cita020(i)+cita020(i).*sqrt(1-sqrt(-1).*OMI.*tao020(i)./cita020(i).^2));
end
for i = 1:length(STCRACK020)
CCC22020(i,:) = C22020H(i)./(1+((C22020H(i)-C220200(i))./C220200(i))./fw020(i,:));
end
Q1C22020 = abs(imag(CCC22020)./real(CCC22020));
CC22020 = real(CCC22020);
TOE22020 = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22020M = polyfit(STPRE020,CC22020(:,i),1);
TOE22020(i) = 1000.*TOE22020M(1);
end
%%
%the dispersion of third-order elastic constant
%low Aut L = 50um
cita050 = (C22050H-C220500).^3./(2.*C22050H.*C220500.^2.*T050.*G050.^2);
tao050 = ((C22050H-C220500)./C220500./G050).^2;
fw050 = zeros(length(STCRACK050),length(OMI));
CCC22050 = zeros(length(STCRACK050),length(OMI));
for i = 1:length(STCRACK050)
fw050(i,:) = (1-cita050(i)+cita050(i).*sqrt(1-sqrt(-1).*OMI.*tao050(i)./cita050(i).^2));
end
for i = 1:length(STCRACK050)
CCC22050(i,:) = C22050H(i)./(1+((C22050H(i)-C220500(i))./C220500(i))./fw050(i,:));
end
Q1C22050 = abs(imag(CCC22050)./real(CCC22050));
CC22050 = real(CCC22050);
TOE22050 = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22050M = polyfit(STPRE050,CC22050(:,i),1);
TOE22050(i) = 1000.*TOE22050M(1);
end
%%
%the dispersion of third-order elastic constant
%low Aut L = 100um
cita100 = (C22100H-C221000).^3./(2.*C22100H.*C221000.^2.*T100.*G100.^2);
tao100 = ((C22100H-C221000)./C221000./G100).^2;
fw100 = zeros(length(STCRACK100),length(OMI));
CCC22100 = zeros(length(STCRACK100),length(OMI));
for i = 1:length(STCRACK100)
fw100(i,:) = (1-cita100(i)+cita100(i).*sqrt(1-sqrt(-1).*OMI.*tao100(i)./cita100(i).^2));
end
for i = 1:length(STCRACK100)
CCC22100(i,:) = C22100H(i)./(1+((C22100H(i)-C221000(i))./C221000(i))./fw100(i,:));
end
Q1C22100 = abs(imag(CCC22100)./real(CCC22100));
CC22100 = real(CCC22100);
TOE22100 = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22100M = polyfit(STPRE100,CC22100(:,i),1);
TOE22100(i) = 1000.*TOE22100M(1);
end
figure(130)
plot(log10(k2a),TOE22001)
hold on
plot(log10(k2a),TOE22010)
hold on
plot(log10(k2a),TOE22020)
hold on
plot(log10(k2a),TOE22050)
hold on
plot(log10(k2a),TOE22100)
legend('Autocorrelation Length = 1um','Autocorrelation Length = 10um','Autocorrelation Length = 20um','Autocorrelation Length = 50um','Autocorrelation Length = 100um')
xlabel('log10(k2a)')
ylabel('TOE')

%
figure(131)
plot(log10(k2a),real(CCC22001L))
hold on
plot(log10(k2a),real(CCC22001M))
hold on
plot(log10(k2a),real(CCC22001H))
legend('Low pressure','Middle pressure','High pressure')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
figure(132)
plot(log10(k2a),log10(Q1C22001L))
hold on
plot(log10(k2a),log10(Q1C22001M))
hold on
plot(log10(k2a),log10(Q1C22001H))
legend('Low pressure','Middle pressure','High pressure')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
figure(133)
plot(log10(k2a),real(CCC22050L))
hold on
plot(log10(k2a),real(CCC22050M))
hold on
plot(log10(k2a),real(CCC22050H))
legend('Low pressure','Middle pressure','High pressure')
xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
figure(134)
plot(log10(k2a),log10(Q1C22050L))
hold on
plot(log10(k2a),log10(Q1C22050M))
hold on
plot(log10(k2a),log10(Q1C22050H))
legend('Low pressure','Middle pressure','High pressure')
xlabel('log10(k2a)')
ylabel('Attenuation (Log)')