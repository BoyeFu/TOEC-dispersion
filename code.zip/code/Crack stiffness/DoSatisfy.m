%%
%This code is used to calculate the fracture surface
clear
SURF = load('S2.txt');
[NY,NX] = size(SURF);
I = 1;
for IR = 1:NY
for    IX = 1:NX
    if SURF(IR,IX)>0
        DATA(I) = SURF(IR,IX);
        I = I+1;
    end
end
end
DATAA = max(max(SURF))-DATA;
STTA = std(DATA)