clear all
x = 100*1e-06;
X = 1000*1e-06;
y = 200*1e-06;
Y = 2000*1e-06;
z = 200*1e-06;
Z = 2000*1e-06;
DH = 1e-06;
F = 100;
NMAX = 10;
vvmu =0.1;
III = sqrt(-1);
x1=0;% the low limit of the integration

x2=DH/2;%the high limit of the integration, becuase the integration region is (0,infinity) in equation (A13),we use the value x2 represent infinity

m=(NMAX+1)/2;%%��
xm=(x2+x1)/2;%midpoint 
xl=(x2-x1)/2;%midpoint
for i=1:m
Z=cos(pi*(i-1/4)/(NMAX+1/2));%1>Z>0
Z1=Z-1;%0>Z1>-1
ZZ(floor(i))=Z;
ZZZ(i)=Z-Z1;
while (Z-Z1) > 3d-14
p1=1;
p2=0;
for j=1:NMAX
p3=p2;
p2=p1;%=((2*(j-1)-1)*Z*p2-(j-2)*p3)/j
p1=((2*j-1)*Z*p2-(j-1)*p3)/j;%p1=((2*j-1)*Z*((2*(j-1)-1)*Z*p2-(j-2)*p2)/j-(j-1)*p2)/j
end
pp=NMAX*(Z*p1-p2)/(Z^2-1);%z=1 pp=inf z=0, NMAX((j-1)(p2-p1)/j)
Z1=Z;
Z=Z1-p1/pp;
end
x(i)=xm-xl*Z;%x1<x<(x2+x1)/2
x(NMAX+1-i)=xm+xl*Z;%x2>x>(x2+x1)/2
w(i)=2*xl/((1-Z^2)*pp^2);%(x2-x1)/2
w(NMAX+1-i)=w(i);
end
for i=1:NMAX
u(i)=x(i);
end
for i=1:NMAX
zz = z+III.*u(i);
R = sqrt((x-X).^2+(y-Y).^2+(zz-Z).^2);
FFF = 3.*F./(DH/2).^3.*u(i);
ux1(i) = FFF.*((zz-Z)./(R+zz-Z)+log(R+zz-Z)).*(u(i));
ux2(i) = FFF.*((y-Y).^2./(R+zz-Z).^2).*u(i);
ux3(i) = FFF.*((zz-Z)./(R+zz-Z)+log(R+zz-Z)).*(u(i));
ux4(i) = FFF.*((x-X).^2./(R+zz-Z).^2).*u(i);
ux5(i) = FFF.*(z-Z)./(R+zz-Z).*u(i);
ux6(i) = FFF.*(z-Z).*(x-X).^2./(R+zz-Z).^2./R.*u(i);
end
Ux1 = imag(sum(ux1));
Ux2 = imag(sum(ux2));
Ux3 = imag(sum(ux3));
Ux4 = imag(sum(ux4));
Ux5 = imag(sum(ux5));
Ux6 = imag(sum(ux6));
Ux = (1+vvmu)./(4.*pi.*E).*(Ux1+Ux2)+2*(1-vvmu).*(1+vvmu)./(4.*pi.*E).*(Ux3-Ux4)+(1+vvmu)./(4.*pi.*E).*(Ux5-Ux6);
