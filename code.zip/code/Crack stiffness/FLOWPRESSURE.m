PRG1 = (1:1:16);%Presure gradient
FLQ1 = [1.00E+00	2.00E+00	3.00E+00	4.00E+00	5.00E+00	6.00E+00	7.00E+00	8.00E+00	9.00E+00	1.00E+01	1.10E+01	1.20E+01	1.30E+01	1.40E+01	1.50E+01	1.60E+01];%Flow normalized
PRG2 = (10:10:160);%Pressure gradient
FLQ2 = [1.00E+00	2.00E+00	3.00E+00	3.98E+00	4.95E+00	5.89E+00	6.81E+00	7.69E+00	8.53E+00	9.34E+00	1.01E+01	1.09E+01	1.17E+01	1.24E+01	1.32E+01	1.39E+01];%Flow normalized
%%
PP =polyfit(PRG2(1:5),FLQ2(1:5),1);
FLQ2L = PP(2)+PP(1).*PRG2;
%%
figure(1)
plot(PRG1,FLQ1)
xlabel('Pressure gradient (Normalized)')
ylabel('Fluid Flow (Normalzied)')
figure(2)
plot(PRG2,FLQ2)
hold on
plot(PRG2,FLQ2L)
xlabel('Pressure gradient (Normalized)')
ylabel('Fluid Flow (Normalzied)')
