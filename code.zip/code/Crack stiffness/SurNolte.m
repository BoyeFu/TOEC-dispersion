%This code is trying to do want has been described in Nolte and Pyrak-Nolte
function SS = SurNolte(Nx, Ny, EH, varH, N, n, b, SDS)
% Nx = 100; Ny = 100; %The scale of the surface
% N = 5;%The number of the square in each tier
% n = 6;%The tier number of the experiment
% b = 1.125;%the ratio between the length of the square in next square and the last square
%all the location of the squre satisfy the homgeous distribution
w = 1;
for I = 1:n;
A1 = zeros (N,2);
A1(:,1) = randi([1,Ny],N,1);
A1(:,2) = randi([1,Nx],N,1);
% A3 = ones(N,1);
% A = sparse(A1(:,1),A1(:,2),A3,Nx,Ny);
AA = zeros(N.^I,2);
for i = 1: floor(N.^(I-1));
    if i == 1
    AA(floor(N.*(i-1)+1):floor(N.*i),1) = randi([ceil(A1(i,1)-Ny/b/2),ceil(A1(i,1)+Ny/b/2)],N,1);
    AA(floor(N.*(i-1)+1):floor(N.*i),2) = randi([ceil(A1(i,2)-Nx/b/2),ceil(A1(i,2)+Nx/b/2)],N,1);
    else
        AA(floor(N.*(i-1)+1):floor(N.*i),1) = randi([ceil(AA1(i,1)-Ny/b^I/2),ceil(AA1(i,1)+Ny/b^I/2)],N,1);
        AA(floor(N.*(i-1)+1):floor(N.*i),2) = randi([ceil(AA1(i,2)-Nx/b^I/2),ceil(AA1(i,2)+Nx/b^I/2)],N,1);
    end
end
AA1 = AA;
end
S = zeros(Ny,Nx);
for J = 1:floor(N.^n);
if AA1(J,1)>0 && AA1(J,1)<=Ny && AA1(J,2)>0 && AA1(J,2)<=Nx;
   S(AA1(J,1),AA1(J,2)) = 1;
end
if AA1(J,1)+1>0 && AA1(J,1)+1<=Ny && AA1(J,2)>0 && AA1(J,2)<=Nx;
   S(AA1(J,1)+1,AA1(J,2)) = 1;
end
if AA1(J,1)>0 && AA1(J,1)<=Ny && AA1(J,2)+1>0 && AA1(J,2)+1<=Nx;
   S(AA1(J,1),AA1(J,2)+1) = 1;
end
if AA1(J,1)+1>0 && AA1(J,1)+1<=Ny && AA1(J,2)+1>0 && AA1(J,2)+1<=Nx;
   S(AA1(J,1)+1,AA1(J,2)+1) = 1;
end
end
    % for J =1 : floor(N.^n)
%     S(ceil(AA(J,1)),ceil(AA(J,2))) = 1;
% end
% for J = 1:length(nx);
% AA(nx(J),ny(J))=[];
% end

%%
%To obtain the surface
if SDS == 1
MUU=log(EH)-1./2.*log(1+varH./(EH.^2));%The standrd deviation
dev2=sqrt(log(1+varH./EH.^2)); %square deviation
theta = lognrnd(MUU,dev2,Ny,Nx);
elseif SDS == 2
theta = power_law_rand(Ny,Nx,EH,varH);
elseif SDS == 3
theta = exprnd(EH,Ny,Nx);
end
SS = theta.*S;
%%
end