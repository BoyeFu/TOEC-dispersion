%%
%This function is to claculate the stress and displacement
clear all
Lx = 100;
Ly = 100;
S2 =load('S2.txt');
SS2 = S2;
EH = mean(SS2(:));
E = 14e09;%Young's modulus
vvmu = 0.25;%Poson's ratio
sigma0 = mean(SS2(:));
offset_ratio = 	5;
Disflat = offset_ratio*sigma0;%The displacement of 
D0 = max(SS2(:));
Heighflat = D0 - Disflat;
S1 = max(S2(:)) - offset_ratio*sigma0; % first contact at S2 maxima
[NX,NY] = size(SS2);
SSTOR = sparse(NX*NY,3);%To store the peak higher than flat
SSTORL = sparse(NX*NY,3);%To store the peak lower than the flat
w = 1;
DH = Lx./NX;
for I = 1:NX;
    for J = 1:NY;
    if SS2(I,J) >= Heighflat;  
        SSTOR(w,1) = I;
        SSTOR(w,2) = J;
        SSTOR(w,3) = SS2(I,J);
        w = w+1;
    end
    end
end
%%
for I = 1:NX;
    for J = 1:NY;
    if SS2(I,J) < Heighflat;  
        SSTORL(w,1) = I;
        SSTORL(w,2) = J;
        SSTORL(w,3) = SS2(I,J);
        w = w+1;
    end
    end
end
%%
if max(SSTOR) == 0
    apt = max(0, S1-S2); 
    PRE = 0;
    Disp = 0;
    return
else 
    
    NSS = sum(sum(SSTOR(:,3)~=0));
end
SNOD = zeros(NSS,3);
w = 1;
for K = 1:NX*NY;
    if SSTOR(K,3)>0 || SSTOR(K,3)<0;
        SNOD(w,:) = SSTOR(K,:);
        w = w+1;
    end
end
SSW = sparse(NSS,NSS);
for i = 1:NSS;
    SSW(i,i) = 8.*(1-vvmu.^2)./pi.^2./E./(DH./2)+SNOD(i,3)./E./(DH./2).^2;
end
for i = 1:NSS;
    for j = 1:NSS;
        if i~=j
            RR = sqrt((SNOD(i,1)-SNOD(j,1)).^2+(SNOD(i,2)-SNOD(j,2)).^2).*DH;
            SSW(i,j) = 2.*(1-vvmu.^2)./pi./E./RR;
        end
    end
end
LL = SNOD(:,3)-EH;
F = SSW\LL;
PRE = sum(F)./Lx./Ly;
DLC = F.*SNOD(:,3)./(E.*pi.*DH./2);
%
SOLC = [SNOD,F];
%%
%To store the non-zero value in SSTORL
 NSSL = sum(sum(SSTORL(:,3)~=0));
 SNODL = zeros(NSSL,3);
w = 1;
for K = 1:NX*NY;
    if SSTORL(K,3)>0 || SSTORL(K,3)<0;
        SNODL(w,:) = SSTORL(K,:);
        w = w+1;
    end
end
%%
%To calculate the displacement for the piont did not contact
DLCL = zeros(NSSL,1);
WW = zeros(NSSL,1);
for i = 1:NSSL;
    R = sqrt((SOLC(:,1)-SNODL(i,1)).^2+(SOLC(:,2)-SNODL(i,2)).^2);
    W = F.*2.*(1-vvmu.^2)./pi./E./R;
    WW(i) = sum(W);
    DLCL(i) = D0 - EH -sum(WW);
end
DLNCC = sparse(SNODL(:,1),SNODL(:,2),DLCL,NX,NY);
WAPT = sparse(SNODL(:,1),SNODL(:,2),WW,NX,NY);
apt = max(0, S1-S2-full(WAPT));
Disp = Disflat;
imagesc(apt)