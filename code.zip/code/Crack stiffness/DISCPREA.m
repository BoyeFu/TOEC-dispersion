%%
%This function is to claculate the stress and displacement
function [apt, sufa, sufanr, sufaup, PRE, Disp, S1, DJDD, DJDDJ, UXXYY, TANYZ, TANXZ] = DISCPREA(Lx, Ly, EH, varH, offset_ratio, Disp0, KKQS, Pressure, VVA, muuu, NMAX)
if KKQS == 2
S2 = load('S2.txt');
S22 = load('S2.txt');
else
    S2 = load('S21.txt');
    S22 = load('S22.txt');
end
E = load('EREAL.txt');
vvmu = load('vvmureal.txt');
%S2 = S0;
SS2 = S2;
D0 = max(SS2(:));
[NY,NX] = size(SS2);
DX = (1:NX).*Lx./NX./1e-06;
DY = (1:NY).*Ly./NY./1e-06;
[DDX, DDY] = meshgrid(DX,DY);
Disflat = offset_ratio*D0;%The displacement of 
Heighflat = D0 - Disflat;
S1 = max(S2(:)) - offset_ratio*D0; % first contact at S2 maxima
sufanr = zeros(NY,NX);
%%
while 1
SSTOR = zeros(NX*NY,5);%To store the peak higher than flat The line 3 for height line 4 for Yong's modulus line 5 for posson's ratio
SSTORL = zeros(NX*NY,5);%To store the peak lower than the flat The line 3 for height line 4 for Yong's modulus line 5 for posson's ratio
w = 1;
DHX = Lx./NX;
DHY = Ly./NY;
DH = sqrt((DHX^2+DHY^2)/2);
for I = 1:NY
    for J = 1:NX
    if SS2(I,J) >= Heighflat
        SSTOR(w,1) = I;
        SSTOR(w,2) = J;
        SSTOR(w,3) = SS2(I,J);
        SSTOR(w,4) = E(I,J);
        SSTOR(w,5) = vvmu(I,J);
        w = w+1;
    end
    end
end
%%
w = 1;
for I = 1:NY
    for J = 1:NX
    if SS2(I,J) < Heighflat
        SSTORL(w,1) = I;
        SSTORL(w,2) = J;
        SSTORL(w,3) = SS2(I,J);
        SSTORL(w,4) = E(I,J);
        SSTORL(w,5) = vvmu(I,J);
        w = w+1;
    end
    end
end
%%
if max(SSTOR) == 0
    apt = max(0, S1-S2); 
    PRE = 0;
    Disp = 0;
    return
else 
    NSS = sum(sum(SSTOR(:,1)~=0));
end
SNOD = zeros(NSS,5);%The line 3 for height line 4 for Young's modulus Line 5 for posson's ratio
w = 1;
for K = 1:NX*NY
    if SSTOR(K,1)>0
        SNOD(w,:) = SSTOR(K,:);
        w = w+1;
    end
end
SSW = zeros(NSS,NSS);
for i = 1:NSS
    SSW(i,i) = 32.*(1-SNOD(i,5).^2)./pi.^2./SNOD(i,4)./(DH./2)./3+SNOD(i,3)./SNOD(i,4)./pi./(DH./2).^2;
end
for i = 1:NSS
    for j = 1:NSS
        if i~=j
            RR = sqrt((SNOD(i,1)-SNOD(j,1)).^2+(SNOD(i,2)-SNOD(j,2)).^2).*DH;
            SSW(i,j) = 2.*(1-SNOD(i,5).^2)./pi./SNOD(i,4)./RR;
        end
    end
end
LL = SNOD(:,3)-Heighflat;
F = SSW\LL;
PRE = sum(F)./Lx.*2./Ly.*2./3.14;
DLC = F.*SNOD(:,3)./(SNOD(:,4).*pi.*(DH./2).^2);
QQQ =muuu*F;
%%
SSWXS = zeros(NSS,NSS);
SSWYS = zeros(NSS,NSS);
SSWZS = zeros(NSS,NSS);
for I = 1:NSS
   SSWXS(I,I) = 0;
   SSWYS(I,I) = 0;
   SSWZS(I,I) = 0;
end
for I = 1:NSS
    for J = 1:NSS
        if I~=J
        RRR = sqrt((sqrt((SNOD(I,1)-SNOD(J,1)).^2+(SNOD(I,2)-SNOD(J,2)).^2).*DH).^2+(SNOD(I,3)-SNOD(J,3)).^2);
        RRX = (SNOD(I,2)-SNOD(J,2))*DH;
        RRY = (SNOD(I,1)-SNOD(J,1))*DH;
        RRZ = SNOD(I,3)-SNOD(J,3);
        CC = (1+SNOD(I,5))/(8*pi*SNOD(I,4)*(1-SNOD(I,5)));
        CC1 = 3-4*SNOD(I,5);
        SSWXS(J,I) = CC./RRR.*(CC1+(RRX./RRR).^2).*QQQ(J);
        SSWYS(J,I) = CC.*RRX.*RRY./RRR.^3.*QQQ(J);
        SSWZS(J,I) = CC.*RRX.*RRZ./RRR.^3.*QQQ(J);
        end
    end
end
Uxx11 = sum(SSWXS);
Uxy11 = sum(SSWYS);
Uxz11 = sum(SSWZS); 
Uxx = Uxx11';
Uxy = Uxy11';
Uxz = Uxz11'; 
UxxSS01 = sum(Uxx);
UxySS01 = sum(Uxy);
UxzSS01 = sum(Uxz);
%%
%%
%added by Bo-Ye Fu
%DLC = min(SNOD(:,3), DLC);
%%
DLCC = DLC+D0-SNOD(:,3)+Uxz;
DLCCDS = DLC+D0-SNOD(:,3)+Uxz;
%%
%New
DLCCN = DLC+D0-SNOD(:,3);
DLCCDSN = DLC+D0-SNOD(:,3);
%%
%%
%
SOLC = [SNOD,F];
%%
%To store the non-zero value in SSTORL
 NSSL = sum(sum(SSTORL(:,1)~=0));
 SNODL = zeros(NSSL,5);
w = 1;
for K = 1:NX*NY
    if SSTORL(K,1)>0
        SNODL(w,:) = SSTORL(K,:);
        w = w+1;
    end
end
%%
%To calculate the displacement for the piont did not contact
DLCL = zeros(NSSL,1);
DLCLDS =zeros(NSSL,1);
DLCLN = zeros(NSSL,1);
DLCLDSN = zeros(NSSL,1);
UxxDD = zeros(NSSL,1);
UxyDD = zeros(NSSL,1);
UxzDD = zeros(NSSL,1);
for i = 1:NSSL
    R = sqrt((SOLC(:,1)-SNODL(i,1)).^2+(SOLC(:,2)-SNODL(i,2)).^2).*DH;
    W = F.*2.*(1-SNODL(i,5).^2)./pi./SNODL(i,4)./R;
    WW = sum(W);
    %%
 RRRR = sqrt((sqrt((SOLC(:,1)-SNODL(i,1)).^2+(SOLC(:,2)-SNODL(i,2)).^2).*DH).^2+(SOLC(:,3)-SNODL(i,3)).^2);
 RRRX = (SNODL(i,2)-SOLC(:,2)).*DH;
 RRRY = (SNODL(i,1)-SOLC(:,1)).*DH;
 RRRZ = SNODL(i,3)-SOLC(:,3);
 CCC1 = 3-4*SNODL(i,5);
 CCC = (1+SNODL(i,5))/(8*pi*SNODL(i,4)*(1-SNODL(i,5)));
 UxxD1 = CCC*(CCC1+(RRRX./RRRR).^2)./RRRR.*QQQ;
 UxyD1 = CCC.*RRRX.*RRRY./RRRR.^3.*QQQ;
 UxzD1 = CCC.*RRRX.*RRRZ./RRRR.^3.*QQQ;
 UxxDD(i) = sum(UxxD1);
 UxyDD(i) = sum(UxyD1);
 UxzDD(i) = sum(UxzD1);
 UxzD = sum(UxzD1);
%%
    %%
    DLCL(i) = D0 - Heighflat + WW + UxzD;
    DLCLDS(i) = D0 - Heighflat + WW + UxzD;
    DLCLN(i) = D0 - Heighflat + WW;
    DLCLDSN(i) = D0 - Heighflat + WW;
    %%
end
UxxSS02 = sum(UxxDD);
UxySS02 = sum(UxyDD);
UxzSS02 = sum(UxzDD);
%%
DJDD = D0 - DLCL -SNODL(:,3);
DJDDJ = min(DJDD);
%%
%This should also be deleted 
if isempty(DJDD)==1
break
elseif isnan(DJDDJ)
break
end
%%
if DJDDJ>=0 || abs(DJDDJ)<=EH/20
    break
end
Heighflat = Heighflat + 0.001*abs(DJDDJ);
end
%%
UXXYY = 0;
WAPT1 = sparse(SNODL(:,1),SNODL(:,2),DLCL,NY,NX);
WAPT2 = sparse(SNOD(:,1),SNOD(:,2),DLCC,NY,NX);
WAPT3 = WAPT1 + WAPT2;
%%
% WAPTX1 = sparse(SNODL(:,1),SNODL(:,2),UxxDD,NY,NX);
% WAPTX2 = sparse(SNOD(:,1),SNOD(:,2),Uxx,NY,NX);
% WAPTX3 = WAPTX1 + WAPTX2;
% WAPTY1 = sparse(SNODL(:,1),SNODL(:,2),UxyDD,NY,NX);
% WAPTY2 = sparse(SNOD(:,1),SNOD(:,2),Uxy,NY,NX);
% WAPTY3 = WAPTY1 + WAPTY2;
%%
%%
WAPT1N = sparse(SNODL(:,1),SNODL(:,2),DLCLN,NY,NX);
WAPT2N = sparse(SNOD(:,1),SNOD(:,2),DLCCN,NY,NX);
WAPT3N = WAPT1N + WAPT2N;
PPP = F;
% QQQ =muuu*F;
FORCELOAD = sparse(SNOD(:,1),SNOD(:,2),PPP,NY,NX);
sufa = zeros(NY,NX);
sufannr = zeros(NY,NX);
for i = 1:NY
for j = 1:NX
if  D0 - WAPT3(i,j) >= S2(i,j) && WAPT3(i,j) >= (D0-Heighflat)
sufa(i,j) = S2(i,j) + WAPT3(i,j)-(D0-Heighflat);
sufannr(i,j) = S2(i,j) + WAPT3N(i,j)-(D0-Heighflat);
else
sufa(i,j) = Heighflat;
sufannr(i,j) = Heighflat;
end
end
end
% sufare = sufa;
%%
% Uxxx = zeros(NY*NX,1);
% Uyyy = zeros(NY*NX,1);
% SURFACE = zeros(NY*NX,3);
% % SURFACE = zeros(NY*NX,3);
% w = 1;
% for i = 1:NY;
%     for j = 1:NX;
% 
%         Uxxx(w) = WAPTX3(i,j)./DH;
%         Uyyy(w) = WAPTY3(i,j)./DH;
%         SURFACE(w,:) = [i j sufa(i,j)];
%         w = w+1;
%     end
% end
% 
%      DISPLACEX = zeros(1,NX*NY);
%      DISPLACEY = zeros(1,NX*NY);
%      for i = 1:NX*NY;
% %          if round(SURFACE(i,2)+round(Uxxx(i)))>0 && round(SURFACE(i,2)+round(Uxxx(i)))<=NX ;
%           if round(SURFACE(i,2)+round(Uxxx(i)))>0;
%             DISPLACEX(i) =  round(SURFACE(i,2)+round(Uxxx(i)));
% %          elseif  (SURFACE(i,2)+round(Uxx(i)))<=0;
%          elseif round(SURFACE(i,2)+round(Uxxx(i)))<=0
% %              SURFACE(i,3) = SURFACE(i,3).*abs((1-SURFACE(i,2)))./abs(((SURFACE(i,2)+round(Uxxx(i)))-SURFACE(i,2)));
%              DISPLACEX(i) =  1;
% %          elseif round(SURFACE(i,2)+round(Uxxx(i)))>NX
% % %              SURFACE(i,3) = SURFACE(i,3).*abs((1-SURFACE(i,2)))./abs(((SURFACE(i,2)+round(Uxxx(i)))-SURFACE(i,2)));
% %              DISPLACEX(i) =  NX;
%          end
%          %%
%       
%      end
%      %%
%      for i = 1:NX*NY;
% %          if round(SURFACE(i,1)+round(Uyyy(i)))>0 && round(SURFACE(i,1)+round(Uyyy(i)))<=NY;
%          if round(SURFACE(i,1)+round(Uyyy(i)))>0;
%             DISPLACEY(i) =round(SURFACE(i,1)+round(Uyyy(i)));
% %          elseif (SURFACE(i,1)+round(Uyy(i)))<=0;
%          elseif  round(SURFACE(i,1)+round(Uyyy(i)))<=0;
% %              SURFACE(i,3) = SURFACE(i,3).*abs((1-SURFACE(i,1)))./abs(((SURFACE(i,1)+round(Uyy(i,3)))-SURFACE(i,1)));
%              DISPLACEY(i) =  1;   
% %           elseif  round(SURFACE(i,1)+round(Uyyy(i)))>NY;
% % %              SURFACE(i,3) = SURFACE(i,3).*abs((1-SURFACE(i,1)))./abs(((SURFACE(i,1)+round(Uyy(i,3)))-SURFACE(i,1)));
% %              DISPLACEY(i) =  NY;     
%          end   
%      end
%      %%
%      
%      sufa = sparse(DISPLACEY,DISPLACEX,SURFACE(:,3),max(DISPLACEY),max(DISPLACEX));
%    sufa = full(sufa);
%    sufa = sufa(1:NY,1:NX);
% %    MMM=mean(sufa(:));
% %    MUU=log(EH)-1./2.*log(1+varH./(EH.^2));%The standrd deviation
% %    dev2=sqrt(log(1+varH./EH.^2)); %square deviation
%    for I = 1: NY
%        for J = 1:NX
%            if J<=NX-1 && J>1 && sufa(I,J) <=1e-06;
% %            if J<=NX-1 && J>1;
%                sufa(I,J)=(sufa(I,J+1)+sufa(I,J-1))/2;
%            elseif sufa(I,J) <=1e-06;
% %            else 
%                sufa(I,J) = sufare(I,J);
%            end
%        end
%    end
%    sufa = min(sufa, Heighflat);
%    for I = 1:NY
%        for J = 1:NX;
%            if J<=NX-1 && J>1 && sufa(I,J)>=(sufa(I,J+1)+sufa(I,J-1))/2+1e-06;
% %            if J<=NX-1 && J>1;
%            sufa(I,J)=(sufa(I,J+1)+sufa(I,J-1))/2; 
%            end
%        end
%    end
   %%
%%
%for sufanr
for i = 1:NY
for j = 1:NX
if  Heighflat >= S22(i,j)
sufanr(i,j) = S22(i,j);
else
sufanr(i,j) = Heighflat;
end
end
end
%%
% SUFAS = min(sufa).*ones(NY,NX);
SUFAS = zeros(NY,NX);
for IR = 2:NY-1
    DSUFAS = sqrt((NY/2).^2-(NY/2-IR).^2);
    SUFAS(IR,max(1,floor(NX/2-DSUFAS)):max(1,floor(NX/2+DSUFAS))) = sufa(IR,max(1,floor(NX/2-DSUFAS)):max(1,floor(NX/2+DSUFAS)));   
end
sufa = SUFAS;
%%
save S21.txt sufa -ascii
save S22.txt sufanr -ascii
save S222.txt sufannr -ascii
%%
fname_SUFA = sprintf('SUFANumber_%d_Pressure%d_Exp%d_Var%d.txt', KKQS, Pressure, EH/1e-06, varH/1e-06);
save(fname_SUFA,'sufa','-ascii');
%%
fname_SUFANR = sprintf('SUFANRNumber_%d.txt', KKQS);
save(fname_SUFANR,'sufanr','-ascii');
%%
%Disp = Disflat-(sum(DLCL(:))+sum(DLC(:)))./NX./NY;
if Disflat>=D0
Disp = Disp0;
else
Disp = (sum(DLCLDS(:))+sum(DLCCDS(:)))./NX.*2./NY.*2./3.14;
UXX = (UxxSS02+UxxSS01)/NX/NY;
UXY = (UxySS02+UxySS01)/NX/NY;
UXZ = (UxzSS02+UxzSS01)/NX/NY;
ZZZZ = max(max(sufa));
TANXZ = UXX./EH;
TANYZ1 = UXY./Lx;
TANZY = UXZ./Ly;
TANYZ = (TANYZ1);
end
%if Disp>=D0;
    %Disp = Disp0;
%end
%if Disp<Disp0;
 %   Disp = Disp0;
%end
sufaup =  max(max(sufa)).*ones(NY,NX);
apt = max(VVA, sufaup - sufa);
% apt = sufaup - sufa;
% apt = ones(NY,NX) - ones(NY,NX);
% sufaup =  max(max(sufanr)).*ones(NY,NX);
% apt = max(VVA, sufaup - sufanr);
fig = figure('Visible','off'); 
surf(DDX,DDY,sufa./1e-06)
hold on
surf(DDX,DDY,sufaup./1e-06)
xlabel('Length (um)')
ylabel('Length (um)')
zlabel('Height (um)')
set(gca,'FontSize',10)
saveas(fig, sprintf('number2D%d_Pressure%d_Exp%d_Var%d.jpg', KKQS, Pressure+PRE/1e06, EH/1e-06, varH/1e-06));
close(fig);
sufadd=sufa(50,:);
sufadn=sufanr(50,:);
sufadnn=sufannr(50,:);
sufadup=sufaup(50,:);
fig = figure('Visible','off'); 
plot(DX,sufadd./1e-06,'linewidth',1)
hold on
plot(DX,sufadn./1e-06,'linewidth',1)
% hold on
% plot(DX,sufadnn./1e-06,'linewidth',1)
% legend('Real','Wrong','Without shear')
legend('Poisson effect','Without Poisson effect')
xlabel('Length (um)')
ylabel('Height (um)')
set(gca,'FontSize',10)
saveas(fig, sprintf('Number1D%d_Pressure%d_Exp%d_Var%d.png', KKQS, Pressure+PRE/1e06, EH/1e-06, varH/1e-06));
close(fig);
%%
% for KK = 10:10:100
% sufadd=sufa(KK,:);
% sufadn=sufanr(KK,:);
% % sufadup=sufaup(KK,:);
% fig = figure('Visible','off'); 
% plot(DY,sufadd./1e-06,'linewidth',1)
% hold on
% plot(DY,sufadn./1e-06,'linewidth',1)
% legend('Real','Wrong')
% xlabel('Length (um)')
% ylabel('Height (um)')
% set(gca,'FontSize',10)
% saveas(fig, sprintf('LineKK%d_Pressure%d.png', KK, PRE./1e06));
% close(fig);
% end
%%
fig = figure('Visible','off'); 
plot(DX,sufadd./1e-06,'linewidth',1)
hold on
plot(DX,sufadup./1e-06,'linewidth',1)
legend('Lower','Upper')
xlabel('Length (um)')
ylabel('Height (um)')
set(gca,'FontSize',10)
saveas(fig, sprintf('Numbercomparason%d_Pressure%d_Exp%d_Var%d.png', KKQS, Pressure+PRE/1e06, EH/1e-06, varH/1e-06));
close(fig);
%%
fig = figure('Visible','off'); 
imagesc(DX,DY,FORCELOAD)

xlabel('Length (um)')
ylabel('Length (um)')
zlabel('Force (N)')
set(gca,'FontSize',10)
saveas(fig, sprintf('Pressurenumber2D%d_Pressure%d_Exp%d_Var%d.png', KKQS, Pressure+PRE/1e06, EH/1e-06, varH/1e-06));
close(fig);
% SHEARM = (Pressure+PRE/1e06)*muuu/UXZ;
end