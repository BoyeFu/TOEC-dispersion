%%% This code plots breakthrough curves from transport simulation, and calculate the statistical
%%% parameter for characteristizing transport properties, 
%%% Created by Joseph Ma @ NUS, last updated 15 August 2017

function [peak_time_modeling, q01, q05, q50, q80, q95, q99, tail_slope, Rsq] = transport_stat(fname_TP, Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed, Pressure,hyd_aptn, EH, varH)

load(fname_TP);

breakthrough_sort = sort(max(TIME'));
breakthrough_sort = breakthrough_sort(breakthrough_sort~=0);
BTC_bin = 100;  % lower no. of bin for smoothing/denoising 
logbinx = logspace(log10(min(breakthrough_sort)),log10(max(breakthrough_sort)),BTC_bin+1);  % binning
logbinx2 = logspace(log10(min(breakthrough_sort)),log10(max(breakthrough_sort)),2*BTC_bin+1);   % center bin
logbinx_mid = logbinx2(2:2:end);
[n,xout] = histc(breakthrough_sort, logbinx);
spacing = diff(logbinx);
probability_density = n(1:BTC_bin)./diff(logbinx)/sum(n(1:BTC_bin));
time_pdf = logbinx_mid;
peak_time_modeling = time_pdf((probability_density==max(probability_density)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PDF = probability_density;
time_pdf(find(PDF == 0)) = [];  % remove zeros for taking log
PDF(PDF == 0) = [];
for i = 1:length(time_pdf)
    CDF(i) = sum(PDF(1:i));
end

% Normalize CDF to be 1 without tedious integration
BT = CDF(length(time_pdf));
CDF = CDF./CDF(length(time_pdf));

% finding CDF quantiles 
[~,index01] = min(abs((CDF - 0.01)));
[~,index05] = min(abs((CDF - 0.05))); % find closest index to CDF percentiles
[~,index50] = min(abs((CDF - 0.50)));
[~,index80] = min(abs((CDF - 0.80)));
[~,index95] = min(abs((CDF - 0.95)));
[~,index99] = min(abs((CDF - 0.99)));

q01 = time_pdf(index01);
q05 = time_pdf(index05);
q50 = time_pdf(index50);
q80 = time_pdf(index80);
q95 = time_pdf(index95);
q99 = time_pdf(index99);
DATATIME = time_pdf;
DATAPDF = PDF;
DATACDF =CDF;
fname_time = sprintf('Timeressure%d_hyd_aptn%d.txt', Pressure,hyd_aptn);
fid = fopen(fname_time,'wt');
fprintf(fid,'%g\n',DATATIME);
fclose(fid);
%%
fname_PDF = sprintf('PDFressure%d_hyd_aptn%d_Exp%d_Var%d.txt', Pressure, hyd_aptn, EH/1e-06, varH/1e-06);
fid = fopen(fname_PDF,'wt');
fprintf(fid,'%g\n',DATAPDF);
fclose(fid);
%%
fname_CDF = sprintf('CDFressure%d_hyd_aptn%d_Exp%d_Var%d.txt', Pressure, hyd_aptn, EH/1e-06, varH/1e-06);
fid = fopen(fname_CDF,'wt');
fprintf(fid,'%g\n',DATACDF);
fclose(fid);
%%
% save fname_PDFCDF DATAPDFCDF -ascii
fig = figure('Visible','off');
plot(time_pdf,PDF,'linewidth',1);
xlabel('Breakthrough Time (s)'); 
ylabel('Probability Density');
set(gca,'FontSize',10);
% title({'Breakthrough Curve of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']});
saveas(gcf, sprintf('BT_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d_Pressure%d_Exp%d_Var%d.png',Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed, Pressure, EH/1e-06, varH/1e-06));
close(fig);

fig = figure('Visible','off');
plot(log10(time_pdf),CDF,'r','linewidth',1);
xlabel('Breakthrough Time (Log(s))'); 
ylabel('Cumulative Probability');
set(gca,'FontSize',10);
% title({'Cumulative Breakthrough Curve of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']});
saveas(fig, sprintf('BTcdf_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d_Pressure%d_Exp%d_Var%d.png', Nx, Lx, Clx_frac, var_S,offset_ratio, dist, seed, Pressure, EH/1e-06, varH/1e-06));
close(fig);

fig = figure('Visible','off');
plot(log10(time_pdf),log10(PDF),'k','linewidth',1);
xlabel('Log(Breakthrough Time (s))'); 
ylabel('Log(Probability Density)');
set(gca,'FontSize',10);
% title({'Breakthrough Curve of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']});
saveas(fig, sprintf('BTlog_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d_Pressure%d_Exp%d_Var%d.png', Nx, Lx, Clx_frac, var_S,offset_ratio, dist, seed, Pressure, EH/1e-06, varH/1e-06));
close(fig);

% loglog breakthrough curve tail

% linear regression of tail log(PDF) = beta1 + beta2*log(time_pdf) + eps
% define first tail as from 80th-percentile to 99-th percentile
y1 = log10(PDF(index80:index99)');
x1 = log10(time_pdf(index80:index99)');   

A = [ones(length(x1),1) x1];
beta1 = A\y1;

Rsq = 1 - sum((y1-beta1(1)-beta1(2)*x1).^2)/sum((y1-mean(y1(:))).^2);
tail_slope = beta1(2);
%{
% define second tail (residual) as from 99th-percentile onwards
y2 = log10(PDF(index99:end)');
x2 = log10(time_pdf(index99:end)');   

A = [ones(length(x2),1) x2];
beta2 = A\y2;

Rsq2 = 1 - sum((y2-beta2(1)-beta2(2)*x2).^2)/sum((y2-mean(y2(:))).^2);
tail_slope2 = beta2(2);
%}
fname_TPstat = sprintf('Breakthrough_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d_Pressure%d_Exp%d_Var%d.mat', Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed, Pressure, EH/1e-06, varH/1e-06);
save(fname_TPstat, 'q01', 'q05', 'q50', 'q80', 'q95', 'q99', 'tail_slope', 'Rsq');
