% Modified from Peter K. Kang's main_flow_transport_MC_final.m
% intended to do different realizations of fracture distributions
% by Joseph H.Y. Ma @ NUS, last updated: 16 August 2017
% The crack length is 1000um, autocorrelation length 50um, crack expectation height �� are 10um
clear all; 
close all;
SCALE = 1e-06;
diary('testflow_frac_fuboye_2019_stressinfl.txt')
tic;
QQQQQ = 1; 
Nx = 128; Ny = 128;          % grid numbers ,
NNNN = 100;
Lx = NNNN.*SCALE; Ly = NNNN.*SCALE;          % domain lengths m
DX = Lx./Nx.*(1:Nx)./SCALE;
DY = Ly./Ny.*(1:Ny)./SCALE;
clx_frac = [5]';%The autocorrelation length dimensionless value
Var_S = [0.01]';%The perturbation
dist = 2;                                     % 1: Whitte-A,  2: Guassian, 3: Exponential 4 Gaussian 5 von Karman 6 Gaussian 7 exponential 8 Guassian 9 Von Kaman 10 Self-affine
distdis = 2;%2 log-normal distribution 3 power law distribution 4 exponential distribution 6 Test
RJJJ = 2;%2 Homogennous 1 heterogenenous
mss = 1;
SDS = 1;% 1 log-normal distribution, 2 power law distribution 3 exponential distribution
Nsqure = 10;%The square number of every tier
nsq = 5;%the tier number
b = 2.37;%The scale ratio
EEHH = 1*SCALE;
VarH=0.000001*SCALE;
kappa = 1/5;%The parameter used in von Karman correlation
Offset_ratio = 0.8.*[0 0.05 0.04 0.04 0.03 0.03 0.02 0.02 0.01]';    % no. of SD compression %The compression location dimensionless value
% Offset_ratio = [0 0.05];
% Offset_ratio = [0 0.12 0.12 0.10 0.10 0.08 0.06 0.06 0.02]';
Pressure = 0;
VVA = 1e-10;
DIMM = 2;
muuu = 0;
NMAX = 0;
    run_count = 0;
    Displa = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The displacement of the flat surface
    TANXZZZ = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The displacement of the flat surface
    TANYZZZ = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The displacement of the flat surface
    SHEARM = zeros(length(clx_frac),length(VarH),length(Offset_ratio));
    UXXYYZZ = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The displacement of the flat surface
    Stressstore = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space to store stress
    APTMEAN = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space to store APTmean
    S2MEAN = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space to store mean value of S2
    FLOW = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space to store mean value of flow
    EMPTVOLUM = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The space can store water
    HEIGHAVR = zeros(length(clx_frac),length(VarH),length(Offset_ratio));%The average apt
    DJD = zeros(length(Offset_ratio),1);
    DJDJ = zeros(length(Offset_ratio),1);
    for I = 1:length(clx_frac)%We have confirm the autocorrelation length
    for J = 1:length(VarH)%confirm the perturbation
	S0 = zeros(Ny,Nx);
    Disp0 = 0;
    TANYZ0 = 0;
    TANXZ0 = 0;
       for K = 1:length(Offset_ratio)%Confirm the loction of compression
                Clx_frac = clx_frac(I)%The autocorrelation length
                CLx = Lx/Clx_frac; 
                CLy = CLx;% autocorrelation length unit [m]
                var_S = Var_S%The perturbation
                offset_ratio = Offset_ratio(K);
                run_count = run_count + 1;%The time for iteration
dx = Lx/(Nx-1);              % size of each gridblock [m]
dy = Ly/(Ny-1);
E=37.24e09;                    % The Young's modulus 
vvmu = 0.25;                %Poson's ratio
EH = EEHH(1);
varH = VarH(J);
[S2, sigma0, apt, sufa, sufanr, sufaup, PRE, Disp, str, DJDD, DJDDJ, UXXYY, TANYZ, TANXZ] = gen_aperture(K, dist, distdis, Nx, Ny, Lx, Ly, CLx, CLy, var_S, offset_ratio, kappa, EH, varH, S0, Nsqure, nsq, b, E,vvmu, mss, Disp0, SDS, RJJJ, K, Pressure, VVA, DIMM, muuu, NMAX,QQQQQ);
S0 = S2;
Disp0 = Disp;
TANYZ0 = TANYZ;
TANXZ0 = TANXZ;
UXXYY0 = UXXYY;
apt_mean = mean(apt(:));%The mean aperture
apt_var = var(apt(:));%The variance of aperture
APTMEAN(I,J,K) = apt_mean;%This added by Bo-Ye Fu
S2MEAN(I,J,K) = mean(S2(:));%This is added by Bo-Ye Fu
QQ=apt.*dx.^2;
EMPTVOLUM(I,J,K) = sum(QQ(:))./1e-18;
if K == 1
Displa(I,J,K)=Disp;%This is added by Bo-Ye Fu
else
    Displa(I,J,K)=Disp+Displa(I,J,K-1);%This is added by Bo-Ye Fu
end
UXXYYZZ(I,J,K) = UXXYY;
TANXZZZ(I,J,K) = TANXZ;%This is added by Bo-Ye Fu
TANYZZZ(I,J,K) = TANYZ;%This is added by Bo-Ye Fu
SHEARM(I,J,K) = PRE.*muuu./abs(TANYZ)./1000000000;
if K ==1
Stressstore(I,J,K)=PRE./1e06;%To store the pressure
else
    Stressstore(I,J,K)=PRE./1e06+Stressstore(I,J,K-1);%To store the pressure
end
Pressure = Stressstore(I,J,K);
if offset_ratio == 0
   apt0max = max(apt(:));
end
fig = figure('Visible','off');
imagesc(DX,DY,apt);
xlabel('Length (um)')
ylabel('Length (um)')
axis square; cob=colorbar; colormap('hot'); caxis([min(apt(:)) max(apt(:))]);set(get(cob,'title'),'string','m');
saveas(fig, sprintf('Apt_N%d_L%d_Pressure%d_Autoc%d_Exp%d_Var%d.png', Nx, Lx, Pressure,CLx*1e06, EH/1e-06, varH/1e-06));
close(fig);
        end
    end
    end
%%
%Also a part for stress influence
NP = length(Stressstore(1,1,:));%To obtain the scale of pressure
ND = length(Displa(1,1,:));%To obtain the scale of displacement
NS = length(SHEARM(1,1,:));%To obtain the scale of displacement
NU = length(UXXYYZZ(1,1,:));%To obtain the scale of displacement
NFL = length(FLOW(1,1,:));%To obtain the scale of premeability
NEP = length(EMPTVOLUM(1,1,:));%To obtain the scale of empty space
NHA = length(HEIGHAVR(1,1,:));
Pressure = zeros(1,NP);
SHEARMOD = zeros(1,NS);
Displace = zeros(1,ND);
UXXYYZ1 = zeros(1,NU);
FLOWAVR = zeros(1,NFL);
EPTVO = zeros(1,NEP);
HEIGHMEA = zeros(1,NHA);
for i = 1:NP
Pressure(i) = Stressstore(1,1,i);%To store the pressure
Displace(i) = Displa(1,1,i);%To store the displacement
SHEARMOD(i) = SHEARM(1,1,i);
UXXYYZ1(i) = UXXYYZZ(1,1,i);
FLOWAVR(i) = FLOW(1,1,i);
EPTVO(i) = EMPTVOLUM(1,1,i);
HEIGHMEA(i) = HEIGHAVR(1,1,i);
end
%%
%We still need to show the displacement
Strain = Displace./EEHH;
figure(5)
plot(Pressure,Strain)
xlabel('Pressure (MPa)')
ylabel('Strain')
figure(7)
plot(Pressure,UXXYYZ1)
xlabel('Pressure (MPa)')
ylabel('Stiffness (Pa/m)')
%%
%To calculate the stiffness
PressureSTIF = (Pressure(2:end)-Pressure(1:end-1))*1e06;%The increment of the pressure
StrainSTIF = Strain(2:end)-Strain(1:end-1);%The increment of the displacement
STIFF = PressureSTIF./StrainSTIF/1e09;
figure(6)
plot(Pressure(1:end-1),STIFF)
xlabel('Pressure (MPa)')
ylabel('Stiffness (m/Pa)')
figure(7)
plot(Pressure(2:end),SHEARMOD(2:end))
xlabel('Pressure (MPa)')
ylabel('Shear modulus (GPa)')
diary off
toc;
