clear all
close all
clc
SCALE=1e-05;
%%
cy=1e-05;%����о������
% % % % % % % %%��ɫ255 ��ɫ0
% mageRGB=imread('������о1.bmp');%��ȡͼ��洢RGB����R2��red��G2��green B2 ��blue
% R2=mageRGB(:,:,1);%RGBʶ���е�R����
% G2=mageRGB(:,:,2);%RGBʶ���е�G����
% B2=mageRGB(:,:,3);%RGBʶ���е�B����
% framesolid=R2/255;%��1�ĵط�����ʯӢ
% %NN=size(R2);
% %framesolid=ones(NN(1),NN(2));%��1�ĵط�����ʯӢ
% frameclay=1-framesolid;%��1�ĵط�����ճ��
% frames=framesolid(31:280,31:280);%ѡȡ1500*1600�Ĳ���
% framec=frameclay(31:280,31:280);%ѡȡ1500*1600�Ĳ���
DATA = load('SUFANumber_10.txt');
[NX, NY] =size(DATA); 
 %�Ѱ˽���ת��ʮ����
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %fid =fopen('frames.dat','rb');
 %frames=fread(fid,[nz,nx],'real*4');
 %fclose(fid);
%  fid =fopen('framec.dat','rb');
%  framec=fread(fid,[nz,nx],'real*4');
%  fclose(fid);
Nx=(0:NX-1)*SCALE;
Ny=(0:NY-1)*SCALE;
figure(1)
imagesc(Nx/1e-06,Ny/1e-06,DATA);
xlabel('Distance(um)');
ylabel('Distance(um)');
 %���ݶ�ȡ���
% DATA=DATA./max(max(abs(DATA)));
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  fid =fopen('frames.dat','rb');
%  frames=fread(fid,[nz,nx],'real*4');
%  fclose(fid);
%  fid =fopen('framec.dat','rb');
%  framec=fread(fid,[nz,nx],'real*4');
%  fclose(fid);
%  imagesc(x,z,framec);
%  xlabel('Distance(mm)');
% ylabel('Distance(mm)');

%%%%%%%%%%%%%%�л��ʷ���
% rock2=frames;
% nx=250;
% ny=250;
% xcor=(0:nx-1)*cy;%��4��m��ͼƬ�����ʷ��ʷ�����200*200
% ycor=(0:ny-1)*cy;%��4��m��ͼƬ�����ʷ��ʷ�����200*200
% CCQ=sum(nonzeros(frames))/(nx*nz);
% figure(2)
% imagesc(xcor,ycor,rock2)
% colormap(gray)%grayɫ��
% title(['XY section:CCQ=',num2str(sum(rock2(:))/(nx*ny))])  %��϶��
% xlabel('X(um)');
% ylabel('Y(um)');
% saveas(gcf,'01 kerogen.jpg');
% xlag=1:499;
% ylag=1:499;
% xlag=xlag*cy;ylag=ylag*cy;
% tmp2=xy2-por2;   %%%por2=kero
% tmp2=rock2;   %%%û��ȥ��ֱ��������ȥֱ������������Э����
DATAFF = fft2(DATA);
DATAIFF = fftshift(ifft2(DATAFF.*conj(DATAFF)));%����غ������ź�ƽ��x�����������źŵ����ƶ�
% ��һ��
% maxc=max(cor2(:));
% minc=min(cor2(:));
% cor2=(cor2-minc)/(maxc-minc); 
DATAIFF=DATAIFF./max(max(DATAIFF));
DATAFFT=real(fft2(DATAIFF));
DATAFFTLOF=  log10(real(DATAFFT));
DATAAUT = ifft2(DATAFFT);
figure(3)
imagesc(Nx,Ny,real(DATAAUT));
colorbar
%axis([-50,50,-50,50]*cy);
axis square
Zhh=diag(DATAAUT);
%%
% mlag=100;
% % [R1,~]=fminsearch(@(x) cor_invV1(x,cor2(nx-mlag:nx+mlag,ny-mlag:ny+mlag)),5);  %��ֲ���Сֵ�㣬����ͼƬ��������س���a RΪ���ݵõ�������س���
% %title(['XY section:[a]=[',num2str(-(R*cy)),']'])
% xlabel('Xlag(um)');ylabel('Ylag(um)');
% % saveas(gcf,'02 autocorrelation.jpg');
% %R=81.4;
% a1=R1;
% x=(-(nx-1):(nx-1));t=(-(ny-1):ny-1);
% [X,T]=meshgrid(x,t);
% syms xx f;
% k=1;%ע��٤������
% f=xx^(k-1)*(exp(-xx));
% GAMk=int(f,0,inf);
% GAMk=double(GAMk);
% r=(X).^2/a1^2+(T).^2/a1^2;
% r=r.^0.5;
% rxt=2.^(1-k)./GAMk.*(r).^k.*besselk(k,r);
% rxt(nx,nx)=1;
% rxt1=rxt;
% Zh1=diag(rxt);
%%
% mlag=100;
% [R075,~]=fminsearch(@(x) cor_invV075(x,cor2(nx-mlag:nx+mlag,ny-mlag:ny+mlag)),5);  %��ֲ���Сֵ�㣬����ͼƬ��������س���a RΪ���ݵõ�������س���
% %title(['XY section:[a]=[',num2str(-(R*cy)),']'])
% xlabel('Xlag(um)');ylabel('Ylag(um)');
% % saveas(gcf,'02 autocorrelation.jpg');
% %R=81.4;
% a075=R075;
% x=(-(nx-1):(nx-1));t=(-(ny-1):ny-1);
% [X,T]=meshgrid(x,t);
% syms xx f;
% k=0.75;%ע��٤������
% f=xx^(k-1)*(exp(-xx));
% GAMk=int(f,0,inf);
% GAMk=double(GAMk);
% r=(X).^2/a075^2+(T).^2/a075^2;
% r=r.^0.5;
% rxt=2.^(1-k)./GAMk.*(r).^k.*besselk(k,r);
% rxt(nx,nx)=1;
% Zh075=diag(rxt);
%%
% mlag=100;
% [R05,~]=fminsearch(@(x) cor_invV05(x,cor2(nx-mlag:nx+mlag,ny-mlag:ny+mlag)),5);  %��ֲ���Сֵ�㣬����ͼƬ��������س���a RΪ���ݵõ�������س���
% %title(['XY section:[a]=[',num2str(-(R*cy)),']'])
% xlabel('Xlag(um)');ylabel('Ylag(um)');
% % saveas(gcf,'02 autocorrelation.jpg');
% % R=81.4;
% a05=R05;
% x=(-(nx-1):(nx-1));t=(-(ny-1):ny-1);
% [X,T]=meshgrid(x,t);
% syms xx f;
% k=0.5;%ע��٤������
% f=xx^(k-1)*(exp(-xx));
% GAMk=int(f,0,inf);
% GAMk=double(GAMk);
% r=(X).^2/a05^2+(T).^2/a05^2;
% r=r.^0.5;
% rxt=2.^(1-k)./GAMk.*(r).^k.*besselk(k,r);
% rxt(nx,nx)=1;figure(111)
% Zh05=diag(rxt);
%%
% mlag=100;
% [R025,~]=fminsearch(@(x) cor_invV025(x,cor2(nx-mlag:nx+mlag,ny-mlag:ny+mlag)),5);  %��ֲ���Сֵ�㣬����ͼƬ��������س���a RΪ���ݵõ�������س���
% %title(['XY section:[a]=[',num2str(-(R*cy)),']'])
% xlabel('Xlag(um)');ylabel('Ylag(um)');
% % saveas(gcf,'02 autocorrelation.jpg');
% %R=81.4;
% a025=R025;
% x=(-(nx-1):(nx-1));t=(-(ny-1):ny-1);
% [X,T]=meshgrid(x,t);
% syms xx f;
% k=0.25;%ע��٤������
% f=xx^(k-1)*(exp(-xx));
% GAMk=int(f,0,inf);
% GAMk=double(GAMk);
% r=(X).^2/a025^2+(T).^2/a025^2;
% r=r.^0.5;
% rxt=2.^(1-k)./GAMk.*(r).^k.*besselk(k,r);
% rxt(nx,nx)=1;
% Zh025=diag(rxt);
%%
% mlag=100;
% [R02,~]=fminsearch(@(x) cor_invV02(x,cor2(nx-mlag:nx+mlag,ny-mlag:ny+mlag)),5);  %��ֲ���Сֵ�㣬����ͼƬ��������س���a RΪ���ݵõ�������س���
% %title(['XY section:[a]=[',num2str(-(R*cy)),']'])
% xlabel('Xlag(um)');ylabel('Ylag(um)');
% % saveas(gcf,'02 autocorrelation.jpg');
% %R=81.4;
% a02=R02;
% x=(-(nx-1):(nx-1));t=(-(ny-1):ny-1);
% [X,T]=meshgrid(x,t);
% syms xx f;
% k=0.2;%ע��٤������
% f=xx^(k-1)*(exp(-xx));
% GAMk=int(f,0,inf);
% GAMk=double(GAMk);
% r=(X).^2/a02^2+(T).^2/a02^2;
% r=r.^0.5;
% rxt=2.^(1-k)./GAMk.*(r).^k.*besselk(k,r);
% rxt(nx,nx)=1;
% Zh02=diag(rxt);
%%
%����ͼ
figure(111)
% XH=xlag.*1.414;
% plot(XH,Zh1,'-r')
% hold on
% plot(XH,Zh05,'-b')
% hold on
% plot(XH,Zh025,'-y')
% hold on
% plot(XH,Zh02,'-m')
% hold on
XH = sqrt(Nx.^2+Ny.^2);
plot(XH/1e-06,Zhh,'-k')

% legend('K=1,a=81.87um,R=0.9714','K=0.5,a=137um,R=0.9856','K=0.25,a=272.90um,R=0.9939','K=0.2,a=362.12um,R=0.9949','Real sample')
xlabel('Length in the radial direction (um)');ylabel('Correlative coefficient');
%%
%Calculate the Power spectrum

%The FFT of real rock
% XHNN=(0:999);
% ZhhN=Zhh(250:end);
% ZhhNN=zeros(1,1000);
% ZhhNN(1:length(ZhhN))=ZhhN;
% ZhhNf=abs(fft2(cor2,2*nx-1,2*ny-1));
% ZhhNf01=abs(fft(cor2(nx,:)));
%%
%FFT of K=1
% Zh1N=Zh1(250:end);
% Zh1NN=zeros(1,1000);
% Zh1NN(1:length(Zh1N))=Zh1N;
% Zh1Nf=fft(Zh1NN);
%%
%FFT of K=0.75
% Zh075N=Zh075(250:end);
% Zh075NN=zeros(1,1000);
% Zh075NN(1:length(Zh075N))=Zh075N;
% Zh075Nf=fft(Zh075NN);
%%
%FFT of K=0.5
% Zh05N=Zh05(250:end);
% Zh05NN=zeros(1,1000);
% Zh05NN(1:length(Zh05N))=Zh05N;
% Zh05Nf=fft(Zh05NN);
%%
%FFT of K=0.25
% Zh025N=Zh025(250:end);
% Zh025NN=zeros(1,1000);
% Zh025NN(1:length(Zh025N))=Zh025N;
% Zh025Nf=fft(Zh025NN);
%%
%FFT of K=0.1
% DATAIFF
%%
% XHN=XH(250:end);
% dff=1/(XHNN(end));
fx = 1./(NX*SCALE).*Nx;
fy = 1./(NY*SCALE).*Ny;
ff=sqrt(fx.^2+fy.^2);
%%
% kx=(-249:249);
% ky=(-249:249);
% kx=(0:499);
% ky=(0:499);
%Use analytical result
% syms xx f;
% k1=1;
% f11=xx^(k1-1)*(exp(-xx));
% f12=xx^(k1+1/2-1)*(exp(-xx));
% GAMk11=int(f11,0,inf);
% GAMk11=double(GAMk11);
% GAMk12=int(f12,0,inf);
% GAMk12=double(GAMk12);
% [KX,KY]=meshgrid(kx,ky);
% P1=4.*pi.*GAMk12.*a1./(GAMk11.*(1+a1.^2.*(KX.^2+KY.^2).^2).^(k1+1/2));
%%
% syms xx f;
% k05=0.5;
% f051=xx^(k05-1)*(exp(-xx));
% f052=xx^(k05+1/2-1)*(exp(-xx));
% GAMk051=int(f051,0,inf);
% GAMk051=double(GAMk051);
% GAMk052=int(f052,0,inf);
% GAMk052=double(GAMk052);
% [KX,KY]=meshgrid(kx,ky);
% P05=4.*pi.*GAMk052.*a05./(GAMk051.*(1+a05.^2.*(KX.^2+KY.^2).^2).^(k05+1/2));
%%
% syms xx f;
% k025=0.25;
% f0251=xx^(k025-1)*(exp(-xx));
% f0252=xx^(k025+1/2-1)*(exp(-xx));
% GAMk0251=int(f0251,0,inf);
% GAMk0251=double(GAMk0251);
% GAMk0252=int(f0252,0,inf);
% GAMk0252=double(GAMk0252);
% [KX,KY]=meshgrid(kx,ky);
% P025=4.*pi.*GAMk0252.*a025./(GAMk0251.*(1+a025.^2.*(KX.^2+KY.^2).^2).^(k025+1/2));
%%
% syms xx f;
% k02=0.2;
% f021=xx^(k02-1)*(exp(-xx));
% f022=xx^(k02+1/2-1)*(exp(-xx));
% GAMk021=int(f021,0,inf);
% GAMk021=double(GAMk021);
% GAMk022=int(f022,0,inf);
% GAMk022=double(GAMk022);
% [KX,KY]=meshgrid(kx,ky);
% P02=4.*pi.*GAMk022.*a02./(GAMk021.*(1+a02.^2.*(KX.^2+KY.^2).^2).^(k02+1/2));
% figure(201)
% plot(diag(P1(1:250,1:250))./max(abs(diag(P1(1:250,1:250)))),'-r')
% hold on
% plot(diag(P05(1:250,1:250))./max(abs(diag(P05(1:250,1:250)))),'-g')
% hold on
% plot(diag(P025(1:250,1:250))./max(abs(diag(P025(1:250,1:250)))),'-b')
% hold on
% plot(diag(P02(1:250,1:250))./max(abs(diag(P02(1:250,1:250)))),'-m')
% hold on
% plot(diag(ZhhNf(1:250,1:250))./max(abs(diag(ZhhNf(1:250,1:250)))),'-k')
% KR=1./(XH(end).*1.414).*(1:1:250);

figure(201)
% plot(KR,diag(P1(1:250,1:250)),'-r')
% hold on
% plot(KR,diag(P05(1:250,1:250)),'-g')
% hold on
% plot(KR,diag(P025(1:250,1:250)),'-b')
% hold on
% plot(KR,diag(P02(1:250,1:250)),'-m')
% hold on
DATAFFTT=diag(DATAFFT);
plot(ff(1:NX/2),DATAFFTT(1:NX/2),'-k')
legend('Real sample')
xlabel('Wavenumber in radial direction (/um)')
ylabel('Amp.')
DATAINEXP = [ff
    DATAFFTT'];
save DATA10LN.txt -ascii DATAINEXP
% Zh1Nf=diag(P1(1:250,1:250));
% Zh05Nf=diag(P05(1:250,1:250));
% Zh025Nf=diag(P025(1:250,1:250));
% Zh02Nf=diag(P02(1:250,1:250));
% ZhhNf=diag(ZhhNf(1:250,1:250));
% hold on
% plot(ZhhNf01(1:250),'-y')
%%
% figure(201)
% plot(ff(1:500),ZhhNf(1:500),'-k')
% hold on
% plot(ff(1:500),P1(1:500),'-r')
% hold on
% plot(ff(1:500),Zh075Nf(1:500),'-g')
% hold on
% plot(ff(1:500),P05(1:500),'-b')
% hold on
% plot(ff(1:500),Zh025Nf(1:500),'-y')
% hold on
% plot(ff(1:500),Zh02Nf(1:500),'-m')
% legend('Real sample','K=1,a=81.87,R=0.9548','K=0.75,a=100.22,R=0.9641','K=0.5,a=137,R=0.9789','K=0.25,a=272.90,R=0.9928','K=0.2,a=362.12,R=0.9918')
% xlabel('k');ylabel('correlative coefficient');
%%
%Calculate the correlation length
% RR1=min(corrcoef(Zh1,Zhh));
% RR1f=min(corrcoef(Zh1Nf,ZhhNf));
% RR05=min(corrcoef(Zh05,Zhh));
% RR05f=min(corrcoef(Zh05Nf,ZhhNf));
% RR025=min(corrcoef(Zh025,Zhh));
% RR025f=min(corrcoef(Zh025Nf,ZhhNf));
% RR02=min(corrcoef(Zh02,Zhh));
% RR02f=min(corrcoef(Zh02Nf,ZhhNf));