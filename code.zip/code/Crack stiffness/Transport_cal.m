%%%% RW simulation through random network %%%%
%%%% Load velocity field & necessary data %%%%

function [TIME, NODEINDEX, BT_nodes] = Transport_cal(fluxweighted, INJ_section, nomixing, fname_TPparam, Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed)
 
load(fname_TPparam, 'node_xy', 'Nx', 'Ny', 'neighwithpositiveflux', 'PositiveFluxVector', 'link_Ttime', 'node_connectivity');

%%% General parameters %%%
%nomixing = 0;    % 0: complete mixing, 1: no mixing
Nn = Nx*Ny;       % total # of nodes except boundary nodes
%Nbin = 1000;      % # of binning for BTC

%%% Set up breakthrough nodes
%BT_nodes = [1; Nx; Nn-Nx+1; Nx; 0];     % For center injection
%BT_nodes =  [Nx; 0];                   % BT_nodes for Quarter five spot1
%BT_nodes = [Nn; 0];                   % BT_nodes for Quarter five spot2
% BT_nodes = [[Ny:Ny:Nn]'; 0];           % BT_nodes for bottom to top
BT_nodes = [[Nx:Nx:Nn]'; 0];           % BT_nodes for left to right
 % node index of breakthrough points for linear flow case
%BT_nodes = [find(truncdec(node_xy(:,1),3)==truncdec(max(node_xy(:,1)),3)); find(truncdec(node_xy(:,1),3)==truncdec(min(node_xy(:,1)),3)); find(truncdec(node_xy(:,2),3)==truncdec(min(node_xy(:,2)),3)); find(truncdec(node_xy(:,2),3)==truncdec(max(node_xy(:,2)),3)); ceil(Nn/2)+(2*N-1)*N_dipole(k)];      

%%%%% TIME is the number of particles by the time accumulated series
%%%%% NODEINDEX is the number of particles by the particle position history
TIME = [];
NODEINDEX = [];
Vhistory = [];    % matrix to save Lagrangian velocity history
Die = 0;          % when every particle breakthrough, we stop the simulation

PositiveFluxNormalizedVector = full(cumsum(PositiveFluxVector')')./(repmat(sum(PositiveFluxVector')',1,5));

%%% Initial Injection %%%
%INJ_nodes = ceil(Nn/2)-(2*N-1)*N_dipole(k);                 % injection node index
%NODEINDEX(:,1) = ones(Inj_particle,1)*INJ_nodes;            % for point injection case
%INJ_nodes = [1:N:Nn]';%find(truncdec(node_xy(:,1),3)==0);   % nodes on bottom boundary
INJ_nodes_line = [1:Nx:Nn]';%[1:N]';%find(truncdec(node_xy(:,1),3)==0);      % nodes on left boundary

if INJ_section == 0
    INJ_nodes = [1:Nx:Nn]';                                  % nodes on left boundary
elseif INJ_section == 1
    INJ_nodes = INJ_nodes_line(1:floor(Nn/3));
elseif INJ_section == 2
    INJ_nodes = INJ_nodes_line(ceil(Nn/3):floor(2*Nn/3));
elseif INJ_section == 3
    INJ_nodes = INJ_nodes_line(ceil(2*Nn/3):Nn);
elseif INJ_section == 4
    INJ_nodes = [1:Nx:Nx+1]';
end

INJ_nodes = INJ_nodes((sum(neighwithpositiveflux(INJ_nodes,:),2)>0));      % take inj nodes that has outgoing flux
Inj_particle = size(INJ_nodes,1)*5000;                                      % total number of injected particles

if fluxweighted == 0;
     % for line injection case/ Inject equal # to each node
    NODEINDEX(:,1) = repmat(INJ_nodes, Inj_particle/size(INJ_nodes,1), 1); % 2*ones(Inj_particle,1);     
else
    Qinlet = sum(PositiveFluxVector(INJ_nodes,:),2);
    ParInj = ceil(Qinlet/sum(Qinlet)*100000);
    InitialNode = [];
    for in_node = 1:size(ParInj,1)
        InitialNode = [InitialNode; ones(ParInj(in_node),1)*INJ_nodes(in_node)];
    end
    NODEINDEX(:,1) = InitialNode;   
end

TIME(:,1) = sparse(size(NODEINDEX,1), 1);                % start at time = 0

move_index = find(ismember(NODEINDEX(:,end), BT_nodes)~=1);       % index of particles that did not BT
fluxprevious = [];                                                % save previous step fluxes for nomixing case

while Die == 0 % When every particle breakthrough, stop the simulation
    
    %%%%%%%%%%%%%%%%%%%%%%%%% Mobility Model %%%%%%%%%%%%%%%%%%%%%%
    
    %%% move the particles that satifies waiting time proportional to the flux
    
    e = rand(size(move_index,1),1);                               % set of random values to choose next step link for moving particles
    neig = neighwithpositiveflux(NODEINDEX(move_index,end),:);    % neighboring nodes for moving particles
    neigg = neig';
    
    nodes2outflux = find(sum(neig~=0,2)==2);                % index of particles with two outgoing fluxes
    neighnodesdiff = diff(neighwithpositiveflux(NODEINDEX(move_index,end),:)')';   % index difference between nodes
    % uncommented on 01 Feb 2017 by Joseph
    % find particle indices where two outgoing fluxes are nearby
    neighnodesdiffA =  find(neighnodesdiff(:,1)==1 | neighnodesdiff(:,1)==2*Nx-1);      
    % find particle indices where the no mixing occurs; subset of move_index
    particlesnomixing = move_index(intersect(nodes2outflux, neighnodesdiffA));         
    
    if (size(NODEINDEX,2)>1 & nomixing==1 & size(particlesnomixing,2)~=0)  % when it is after first jump & no mixing case
        
        % incoming node indexes for moving particles that has no mixing rule
        nodesincoming = NODEINDEX(particlesnomixing,end-1);                        
        % neighboring nodes for nomixing particles
        neiggnomixing = neighwithpositiveflux(NODEINDEX(particlesnomixing,end),:);  
        
        % find indices for particlesnomixing from move_index
        [a,nomix_index,c] = intersect(move_index,particlesnomixing);    
        
        % adjacent node index for nomixing particles
        AdjacentNodes = sum(full(neiggnomixing.*(abs(repmat(nodesincoming,1,4)-neiggnomixing)==2*Nx-1 | abs(repmat(nodesincoming,1,4)-neiggnomixing)==1)),2); 
        
        PositiveFluxVectorP = PositiveFluxVector(NODEINDEX(particlesnomixing,end),2:5)';
        
        AdjacentFlux = sum( (PositiveFluxVectorP').* (neiggnomixing==repmat(AdjacentNodes,1,4)),2 ); % Flux through adjacent links
        ProbCorrected = AdjacentFlux./fluxprevious(nomix_index);
        ProbCorrected =  ProbCorrected.*(ProbCorrected<=1)+(ProbCorrected>1); % Probability of chosing adjacent node!!
        adjacentProb = ((neiggnomixing) == repmat(AdjacentNodes,1,4)) .* repmat(ProbCorrected,1,4);
        adjacentProbb = adjacentProb+repmat((1-ProbCorrected),1,4).*(ones(size(adjacentProb))-((neiggnomixing) == repmat(AdjacentNodes,1,4)));
        adjacentProbb(:,3:4) = 0;
        adjacentProbb = [ sparse(size(adjacentProbb,1),1) adjacentProbb];
        PositiveFluxNormalizedCorrected = full(cumsum(adjacentProbb')')./(repmat(sum(adjacentProbb')',1,5));
        
        FluxNomixingCorrected = PositiveFluxNormalizedVector(NODEINDEX(move_index,end), :);
        
        FluxNomixingCorrected(nomix_index, :) = PositiveFluxNormalizedCorrected;
        neigg_dest = sum([e e e e e]-FluxNomixingCorrected>0,2);
        
    else %%% For COMPLETE MIXING CASE
        FluxNomixingCorrected = PositiveFluxNormalizedVector(NODEINDEX(move_index,end), :);
        neigg_dest = sum([e e e e e]-FluxNomixingCorrected>0,2); %
    end
    
    Tneig = link_Ttime(NODEINDEX(move_index,end),:);
    Tneigg = Tneig';
    
    NODEINDEX(move_index,end+1) = neigg((0:4:4*(length(move_index)-1))'+ neigg_dest);
    deltaT = exprnd(Tneigg((0:4:4*(length(move_index)-1))'+ neigg_dest ));
    TIME(move_index, end+1) = TIME(move_index, end) + deltaT;
    Vhistory(move_index, end+1) = 1./deltaT;
    
    PositiveFluxVectorP = PositiveFluxVector(NODEINDEX(move_index,end-1),2:5)';
    fluxprevious = PositiveFluxVectorP((0:4:4*(length(move_index)-1))'+ neigg_dest);
    move_indexprevious = move_index;
    
    move_index = find(ismember(NODEINDEX(:,end), BT_nodes)~=1);     % index of particles that did not BT
    
    [a,fluxprevious_index,c] = intersect(move_indexprevious,move_index);
    fluxprevious = fluxprevious(fluxprevious_index);
    
    if size(move_index,1) == 0
        Die = 1;
    end
    %disp('All injected particles breakthroughed.') 

%{
% breakthrough curves

breakthrough_sort = sort(max(TIME'));
breakthrough_sort = breakthrough_sort(breakthrough_sort~=0);
%Inj_particle = size(TIME,1);
BTC_bin = 1000;  % number of logarithmic bins
logbinx = logspace(log10(min(breakthrough_sort)),log10(max(breakthrough_sort)),BTC_bin+1);      % binning
logbinx2 = logspace(log10(min(breakthrough_sort)),log10(max(breakthrough_sort)),2*BTC_bin+1);   % center bin
logbinx_mid = logbinx2(2:2:end);
[n,xout] = histc(breakthrough_sort, logbinx);
spacing = diff(logbinx);
probability_density = n(1:BTC_bin)./diff(logbinx)/sum(n(1:BTC_bin));
time_pdf = logbinx_mid;
peak_time_modeling = time_pdf((probability_density==max(probability_density)));

for i = 1:length(time_pdf)
    CDF(i) = sum(probability_density(1:i));
end

fig = figure('Visible','off');
plot(time_pdf,probability_density);
xlabel('Breakthrough Time'); ylabel('Probability Density');
title({'Breakthrough Curve of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']});
saveas(gcf, sprintf('BT_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png',Nx, Lx, Clx_frac, var_S, offset_ratio, dist, seed));
 close(fig);
 
fig = figure('Visible','off');
 semilogx(time_pdf,CDF,'r');
 xlabel('Breakthrough Time'); ylabel('Cumulative Probability');
title({'Cumulative Breakthrough Curve of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']});
saveas(fig, sprintf('BTcdf_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S,offset_ratio, dist, seed));
close(fig);
 
fig = figure('Visible','off');
loglog(time_pdf,probability_density,'k');
xlabel('log(Breakthrough Time)'); ylabel('log(Probability Density)');
title({'Breakthrough Curve of Fracture Surfaces with',['Var(S_{2}) = ',num2str(var_S),', \lambda = L/',num2str(Clx_frac),', d = ',num2str(offset_ratio),'\sigma']});
saveas(fig, sprintf('BTlog_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d_seed%d.png', Nx, Lx, Clx_frac, var_S,offset_ratio, dist, seed));
 close(fig);
%}
end
