% Generation of Guassian correlated surfaces from designated permeability fields
% redesigned from Peter K. Kang call_randomperm.m and Joseph H.Y. Ma gen_aperture.m
% BOYE FU @ NUS, last updated: 19 December 2019

function [S2, sigma0, apt, sufa, sufanr, sufaup, PRE, Disp, str, DJDD, DJDDJ, UXXYY, TANYZ, TANXZ] = gen_aperture(K, dist, distdis, Nx, Ny, Lx, Ly, CLx, CLy, var_S, offset_ratio, kappa, EH, varH, S0, Nsqure, nsq, b, E, vvmu, mss,Disp0, SDS, RJJJ,KKQS, Pressure, VVA, DIMM, muuu, NMAX,QQQQQ)

%%% Network Dimension
% hx = Lx/(Nx-1);             hy = Ly/(Ny-1);%This should be interval of network of the simulation area unit (m)
% x = -Lx/2:hx:(Lx/2)-hx;     y = -Ly/2:hy:(Ly/2)-hy;%The area of the sample unit (m)
% [xx,yy] = meshgrid(x,y);%Mesh in the sapec
%%% Wave Numbers
%kx = (2*pi/Lx)*[1:(Nx)]';%The interval in the wavenumber domain
%ky = (2*pi/Ly)*[1:(Ny)]';%The interval in the wavenumber domain
kx = (2*pi/Lx)*[1:(Nx/2) (-Nx/2):(-1)]';%The interval in the wavenumber domain
ky = (2*pi/Ly)*[1:(Ny/2) (-Ny/2):(-1)]';%The interval in the wavenumber domain
[KX,KY] = meshgrid(kx,ky);%The network in wavenumber domain
KX2 = KX.^2;
KY2 = KY.^2;

corr_lenx = CLx;            % x-directional correlation length
corr_leny = CLy;            % y-directional correlation length

dkx = sqrt(KX2(1,2));%The interval in wavenumber domain
dky = sqrt(KY2(2,1));%The interval in wavenumber domain

if K == 1
    sufa = zeros(Ny,Nx);
    sufanr = zeros(Ny,Nx);
%%%% Spectral density functions %%%%
if dist == 1
    % Whittle-A spectrum, isotropic medium
    % Ruan and McLaughlin, Adv Water Res. 1998, (Eq. 23)
    a = pi/(4*sqrt(corr_lenx*corr_leny));
    S = (2*var_S*a*a/pi)*((KX2+KY2)./((a*a+KX2+KY2).^3)); 
    str = 'Whittle-A';
elseif dist == 2 
    % Gaussian log conductivity spectrum, Random Field Generator, 
    % Ruan and McLaughlin, Adv Water Res. 1998, (Eq. 24)
    S = (1/2/pi)*var_S*corr_lenx*corr_leny*exp(-0.5*(corr_lenx^2)*KX2-0.5*(corr_leny^2)*KY2);
    str = 'Guassian';
elseif dist == 3
    % Spectrum of modified exponential autocovariance, 
    % Gelhar and Axness, Water Resources Res. 1983 (Eq. 7, typo),
    % S = (1/pi)*var_S*corr_lenx*corr_leny./((1+(corr_lenx^2)*KX2+(corr_leny^2)*KY2).^2);
	 S = 2.*pi.*var_S.*corr_lenx*corr_leny./((1+(corr_lenx^2)*KX2+(corr_leny^2)*KY2).^3/2);
    str = 'Exponential';
elseif  dist == 4
    % Gaussian log conductivity spectrum, Random Field Generator, 
    % Ruan and McLaughlin, Adv Water Res. 1998, (Eq. 24)
    S = (1/2/pi)*var_S*corr_lenx*corr_leny*exp(-0.5*(corr_lenx^2)*KX2-0.5*(corr_leny^2)*KY2);
    str = 'Guassian';
elseif dist == 5
    % Spectrum of von Karman autocorrelation
	% Sato Sato, H., Fehler, M. C., & Maeda, T. (2012). Seismic wave propagation and scattering in the heterogeneous earth (Vol. 496). Berlin: Springer.
	S = 4.*pi.*gamma(kappa+1).*var_S*corr_lenx*corr_leny./(gamma(kappa).*(1+(corr_lenx^2)*KX2+(corr_leny^2)*KY2).^(kappa+1/2));
	str = 'von Karman';
elseif dist == 6 
    % Gaussian log conductivity spectrum, Random Field Generator, 
    % Ruan and McLaughlin, Adv Water Res. 1998, (Eq. 24)
    S = (1/2/pi)*exp(-0.5*(corr_lenx^2)*KX2-0.5*(corr_leny^2)*KY2);
    str = 'Guassian';
elseif dist == 7
    % Spectrum of modified exponential autocovariance, 
    % Gelhar and Axness, Water Resources Res. 1983 (Eq. 7, typo),
    % S = (1/pi)*var_S*corr_lenx*corr_leny./((1+(corr_lenx^2)*KX2+(corr_leny^2)*KY2).^2);
	 S = 2.*pi./((1+(corr_lenx^2)*KX2+(corr_leny^2)*KY2).^3/2);
    str = 'Exponential';
elseif  dist == 8
    % Gaussian log conductivity spectrum, Random Field Generator, 
    % Ruan and McLaughlin, Adv Water Res. 1998, (Eq. 24)
    S = (1/2/pi)*exp(-0.5*(corr_lenx^2)*KX2-0.5*(corr_leny^2)*KY2);
    str = 'Guassian';
elseif dist == 9
    % Spectrum of von Karman autocorrelation
	% Sato Sato, H., Fehler, M. C., & Maeda, T. (2012). Seismic wave propagation and scattering in the heterogeneous earth (Vol. 496). Berlin: Springer.
	S = 4.*pi.*gamma(kappa+1)./(gamma(kappa).*(1+(corr_lenx^2)*KX2+(corr_leny^2)*KY2).^(kappa+1/2));
	str = 'von Karman';
elseif dist == 10
    ARF = 7-2*DIMM;
    S = 2.*pi.*((sqrt(KX2+KY2)).^(-ARF))./((sqrt(kx(1).^2+ky(1).^2)).^(-ARF));
	str = 'Self-affine';
end
%%
%This is modified by Fu
%H = -S.^(0.5); 
%%
%%
if distdis == 1%This sentance is added by Bo-Ye Fu
%%
H = S.^(0.5); 
%%
theta = 2*pi*rand(Ny,Nx);  % random phase angle

dZ = H.*exp(1i*theta).*sqrt(dkx*dky)*Nx*Ny;
A = ifft2(dZ);
S2 = exp(real(-A));     % for log normal
% MMEE = mean(S2(:));
MMEE = max(max(S2));
S2 = S2./MMEE.*EH.*QQQQQ;
% S2NS = min(S2)*ones(Ny,Nx);
S2NS = zeros(Ny,Nx);
for IR = 1:Ny
    DXXX = sqrt((Ny/2).^2-(Ny/2-IR).^2);
    S2NS(IR,floor(Nx/2-DXXX):floor(Nx/2+DXXX)) = S2(IR,floor(Nx/2-DXXX):floor(Nx/2+DXXX));   
end
S2 = S2NS;
if mss == 1
sigma0 = mean(S2(:));
elseif mss == 2
sigma0 = sqrt(var(S2(:)));   % standard deviation of uncompressed aperature
end
D0 =  max(S2(:));
S1 = max(S2(:)) - offset_ratio*D0; % first contact at S2 maxima
%S1 = mean(S2(:)) + (4.3-offset_ratio)*sigma0;  % first contact mean aperture = 4.3 sigma 
apt = max(VVA, S1-S2);         % simple truncation %Select the big value between 0 and s1-s2
PRE = 0;
Disp = 0;
TANYZ = 0; 
TANXZ = 0;
UXXYY = 0;
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufa(i,j) = S2(i,j);
else
sufa(i,j)=S1;
end
end
end
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufanr(i,j) = S2(i,j);
else
sufanr(i,j)=S1;
end
end
end
%%
 %This sentance is added by Bo-Ye Fu
%%
%This part is added by Bo-Ye Fu, which can be neglected
elseif distdis == 2 %The log normal distribution
MUU=log(EH)-1./2.*log(1+varH./(EH.^2));%The standrd deviation
dev2=sqrt(log(1+varH./EH.^2)); %square deviation
H = S.^(0.5);
theta = lognrnd(MUU,dev2,Ny,Nx);
thetaF = fft2(theta);
Z = thetaF.*H;
S2 = real((ifft2(Z)));
%%
% This is added by Bo-Ye Fu
% MMEE = mean(S2(:));
MMHH = max(max(S2))-min(min(S2));
S2 = (S2-min(min(S2)))./MMHH.*EH.*QQQQQ;
% S2NS = min(S2)*ones(Ny,Nx);
S2NS = zeros(Ny,Nx);
for IR = 1:Ny
    DXXX = sqrt((Ny/2).^2-(Ny/2-IR).^2);
    S2NS(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX))) = S2(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX)));   
end
S2 = S2NS;
%%
if mss == 1
sigma0 = mean(S2(:));
elseif mss == 2
sigma0 = sqrt(var(S2(:)));   % standard deviation of uncompressed aperature
end
D0 =  max(S2(:));
S1 = max(S2(:)) - offset_ratio*D0; % first contact at S2 maxima
%S1 = mean(S2(:)) + (4.3-offset_ratio)*sigma0;  % first contact mean aperture = 4.3 sigma 
apt = max(VVA, S1-S2);         % simple truncation %Select the big value between 0 and s1-s2
PRE = 0;
Disp = 0;
TANYZ = 0; 
TANXZ = 0;
UXXYY = 0;
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufa(i,j) = S2(i,j);
else
sufa(i,j)=S1;
end
end
end
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufanr(i,j) = S2(i,j);
else
sufanr(i,j)=S1;
end
end
end
elseif distdis == 3
H = S.^(0.5);
theta = power_law_rand(Ny,Nx,EH,varH);
thetaF = fft2(theta);
Z = thetaF.*H;
S2 = real(ifft2(Z));
% This is added by Bo-Ye Fu
% MMEE = mean(S2(:));
% MMEE = max(max(S2));
% S2 = S2./MMEE.*EH.*QQQQQ;
MMHH = max(max(S2))-min(min(S2));
S2 = (S2-min(min(S2)))./MMHH.*EH.*QQQQQ;
% S2NS = min(S2)*ones(Ny,Nx);
S2NS = zeros(Ny,Nx);
for IR = 1:Ny
    DXXX = sqrt((Ny/2).^2-(Ny/2-IR).^2);
    S2NS(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX))) = S2(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX)));   
end
S2 = S2NS;
%%
if mss == 1
sigma0 = mean(S2(:));
elseif mss == 2
sigma0 = sqrt(var(S2(:)));   % standard deviation of uncompressed aperature
end
D0 =  max(S2(:));
S1 = max(S2(:)) - offset_ratio*D0; % first contact at S2 maxima
%S1 = mean(S2(:)) + (4.3-offset_ratio)*sigma0;  % first contact mean aperture = 4.3 sigma 
apt = max(VVA, S1-S2);         % simple truncation %Select the big value between 0 and s1-s2
PRE = 0;
Disp = 0;
TANYZ = 0; 
TANXZ = 0;
UXXYY = 0;
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufa(i,j) = S2(i,j);
else
sufa(i,j)=S1;
end
end
end
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufanr(i,j) = S2(i,j);
else
sufanr(i,j)=S1;
end
end
end
elseif distdis == 4
H = S.^(0.5);
theta = exprnd(EH,Ny,Nx);
thetaF = fft2(theta);
Z = thetaF.*H;
S2 = real(ifft2(Z));
% This is added by Bo-Ye Fu
% MMEE = mean(S2(:));
% MMEE = max(max(S2));
% S2 = S2./MMEE.*EH.*QQQQQ;
MMHH = max(max(S2))-min(min(S2));
S2 = (S2-min(min(S2)))./MMHH.*EH.*QQQQQ;
% S2NS = min(S2)*ones(Ny,Nx);
S2NS = zeros(Ny,Nx);
for IR = 1:Ny
    DXXX = sqrt((Ny/2).^2-(Ny/2-IR).^2);
    S2NS(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX))) = S2(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX)));   
end
S2 = S2NS;
%%
if mss == 1
sigma0 = mean(S2(:));
elseif mss == 2
sigma0 = sqrt(var(S2(:)));   % standard deviation of uncompressed aperature
end
D0 =  max(S2(:));
S1 = max(S2(:)) - offset_ratio*D0; % first contact at S2 maxima
%S1 = mean(S2(:)) + (4.3-offset_ratio)*sigma0;  % first contact mean aperture = 4.3 sigma 
apt = max(VVA, S1-S2);         % simple truncation %Select the big value between 0 and s1-s2
PRE = 0;
Disp = 0;
TANYZ = 0; 
TANXZ = 0;
UXXYY = 0;
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufa(i,j) = S2(i,j);
else
sufa(i,j)=max(S2(:)).*ones(Ny,Nx);
end
end
end
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufanr(i,j) = S2(i,j);
else
sufanr(i,j)=S1;
end
end
end
elseif distdis == 5
S2 = SurNolte(Nx, Ny, EH, varH, Nsqure, nsq, b, SDS);
% This is added by Bo-Ye Fu
% MMEE = mean(S2(:));
% MMEE = max(max(S2));
% S2 = S2./MMEE.*EH.*QQQQQ;
MMHH = max(max(S2))-min(min(S2));
S2 = (S2-min(min(S2)))./MMHH.*EH.*QQQQQ;
% S2NS = min(S2)*ones(Ny,Nx);
S2NS = zeros(Ny,Nx);
for IR = 1:Ny
    DXXX = sqrt((Ny/2).^2-(Ny/2-IR).^2);
    S2NS(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX))) = S2(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX)));   
end
S2 = S2NS;
%%
if mss == 1
sigma0 = mean(S2(:));
elseif mss == 2
sigma0 = sqrt(var(S2(:)));   % standard deviation of uncompressed aperature
end
D0 =  max(S2(:));
S1 = max(S2(:)) - offset_ratio*D0; % first contact at S2 maxima
apt = max(VVA, S1-S2);         % simple truncation %Select the big value between 0 and s1-s2
PRE = 0;
Disp = 0;
TANYZ = 0; 
TANXZ = 0;
UXXYY = 0;
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufa(i,j) = S2(i,j);
else
sufa(i,j)=S1;
end
end
end
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufanr(i,j) = S2(i,j);
else
sufanr(i,j)=S1;
end
end
end
elseif distdis == 6
    S2 = TESTSURF(Nx, Ny, EH);
elseif distdis == 7
%     SSSS2 = load('S2real.txt');
S2 = load('S2real.txt');
%     S2 = SSSS2';
if mss == 1
sigma0 = mean(S2(:));
elseif mss == 2
sigma0 = sqrt(var(S2(:)));   % standard deviation of uncompressed aperature
end
D0 =  max(S2(:));
S1 = max(S2(:)) - offset_ratio*D0; % first contact at S2 maxima
apt = max(VVA, S1-S2);         % simple truncation %Select the big value between 0 and s1-s2
PRE = 0;
Disp = 0;
TANYZ = 0; 
TANXZ = 0;
UXXYY = 0;
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufa(i,j) = S2(i,j);
else
sufa(i,j)=S1;
end
end
end
end
for i = 1:Ny
for j = 1:Nx
if S1>=S2(i,j)
sufanr(i,j) = S2(i,j);
else
sufanr(i,j)=S1;
end
end
end
sufaup = (max(S2(:)) - offset_ratio*max(S2(:))).*ones(Ny,Nx);
DJDD = NaN;
DJDDJ = NaN;
if RJJJ == 1
EREAL = E.*S2./max(S2(:));
vvmureal = vvmu.*S2./max(S2(:));
else
    EREAL = E.*ones(Ny,Nx);
    vvmureal = vvmu.*ones(Ny,Nx);
end

save S2.txt S2 -ascii
save S2real.txt S2 -ascii
save EREAL.txt EREAL -ascii
save vvmureal.txt vvmureal -ascii
else%This is added by Bo-Ye Fu
%%
%Added by Bo-Ye Fu

S2 = load('S2.txt');
%S2 = S0;
%%
if mss == 1
sigma0 = mean(S2(:));
elseif mss == 2
sigma0 = sqrt(var(S2(:)));   % standard deviation of uncompressed aperature
end
%S1 = max(S2(:)) - offset_ratio*sigma0; % first contact at S2 maxima
%apt = max(0, S1-S2);         % simple truncation %Select the big value between 0 and s1-s2
[apt, sufa, sufanr, sufaup, PRE, Disp, S1, DJDD, DJDDJ, UXXYY, TANYZ, TANXZ] = DISCPREA(Lx, Ly, EH, varH, offset_ratio, Disp0, KKQS, Pressure, VVA, muuu, NMAX);
str = 'Same as the last one';
end
%%
Clx_frac = Lx/CLx;

%pore_vol = sum(sum(apt.*hx.*hy));

fname_apt = sprintf('Apt_N%d_L%d_CL%d_var%.1f_off%.1f_dist%d.mat', Nx, Lx, Clx_frac, var_S, offset_ratio*(K-1), dist);
save(fname_apt,'Nx','Ny','Lx','Ly','CLx','CLy','KX2','KY2','var_S','offset_ratio','sigma0','S1','S2','apt');
fname_APT = sprintf('APTNumber_%d_Pressure%d_Exp%d_Var%d.txt', KKQS, Pressure, EH/1e-06, varH/1e-06);
save(fname_APT,'apt','-ascii');
end
